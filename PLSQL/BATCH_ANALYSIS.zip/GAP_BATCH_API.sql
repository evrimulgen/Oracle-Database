CREATE OR REPLACE PACKAGE        GAP_BATCH_API AS

   LP_BATCH_INIT_STATUS       CONSTANT       GAP_RIS_BATCH_FLOW_STAGE_T.STATUS%TYPE     := 'Request-Sent';
   LP_BATCH_RESP_STATUS       CONSTANT       GAP_RIS_BATCH_FLOW_STAGE_T.STATUS%TYPE     := 'Response-Received';
   LP_BATCH_FAIL_STATUS       CONSTANT       GAP_RIS_BATCH_FLOW_STAGE_T.STATUS%TYPE     := 'Request-Failed';

   LP_JOB_COMP_STATUS         CONSTANT       GAP_RIS_BATCH_JOB_STAGE_T.STATUS%TYPE      := 'Job-Complete';
   LP_JOB_FAIL_STATUS         CONSTANT       GAP_RIS_BATCH_JOB_STAGE_T.STATUS%TYPE      := 'Job-Failed';

   LP_JOB_SCAN_STATUS         CONSTANT       GAP_RIS_BATCH_JOB_STAGE_T.SCAN_STATUS%TYPE := 'Job-Scanned';

   LP_BATCH_RUN_ID            NUMBER;
   ------------------------------------------------------------------------------------------------
   --called by oracle
   PROCEDURE SUBSCRIBE(I_batch_blob      IN    BLOB,
                       O_error_message   OUT   VARCHAR2);
   ------------------------------------------------------------------------------------------------
   FUNCTION PUBLISH(I_cawa_gen        IN    NUMBER,
                    I_cawa_qual       IN    VARCHAR2,
                    I_cawa_flow       IN    VARCHAR2,
                    I_cawa_job        IN    VARCHAR2,
                    I_jos_process     IN    VARCHAR2,
                    O_error_message   OUT   VARCHAR2)
   RETURN BOOLEAN;
   ------------------------------------------------------------------------------------------------
   FUNCTION WATCHER(I_message_family   IN    VARCHAR2,
                    I_activity_name    IN    VARCHAR2,
                    I_cawa_gen         IN    NUMBER,
                    O_error_message    OUT   VARCHAR2)
   RETURN BOOLEAN;
   ------------------------------------------------------------------------------------------------
   FUNCTION WATCH_FAILURE(I_cawa_gen         IN    NUMBER,
                          I_message_family   IN    VARCHAR2,
                          O_error_message    OUT   VARCHAR2)
   RETURN BOOLEAN;
   ------------------------------------------------------------------------------------------------
   FUNCTION PUBLISH_RELEASE_EXTERNAL_JOB(I_cawa_gen         IN    NUMBER,
                                         I_cawa_qual        IN    VARCHAR2,
                                         I_cawa_flow        IN    VARCHAR2,
                                         I_cawa_job         IN    VARCHAR2,
                                         I_message_family   IN    VARCHAR2,
                                         I_pom_ext_job      IN    VARCHAR2,
                                         O_error_message    OUT   VARCHAR2)
   RETURN BOOLEAN;
   ------------------------------------------------------------------------------------------------
END GAP_BATCH_API;
/


CREATE OR REPLACE PACKAGE BODY        GAP_BATCH_API
AS
/* *********************************************************************************************************
* TYPE         : Package Body
* NAME         : GAP_BATCH_API
* PURPOSE      : This package handles all batch related integration between JOS/POAM and CAWA
*
* Date          Ver    Author    Description
* ====          ===    ======    ===========
* 26-MAR-2017   0.1    Infosys   Initial Version
*
***********************************************************************************************************/
   FUNCTION GET_BATCH_RUN_ID(I_cawa_gen       IN  NUMBER,
                             I_jos_process    IN  VARCHAR2,
                             O_batch_run_id   OUT NUMBER,
                             O_error_message  OUT VARCHAR2)
   RETURN BOOLEAN
   IS

      L_program_name          VARCHAR2(200)  := 'GAP_BATCH_API.GET_BATCH_RUN_ID';

      CURSOR C_get_batch_run_id
      IS
         SELECT batch_run_id
           FROM gap_ris_batch_flow_stage_t stg
          WHERE stg.cawa_gen_id = I_cawa_gen
            AND stg.status      = LP_BATCH_RESP_STATUS --'Response-Received' basically check the status of those jobs for which valid response received from Oracle.
            AND stg.jos_process = I_jos_process
            AND ROWNUM < 2;
   BEGIN
   ---
      OPEN  C_get_batch_run_id;
      FETCH C_get_batch_run_id INTO O_batch_run_id;

         IF C_get_batch_run_id%NOTFOUND
         THEN
         ---
            O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                                  ' CAWA Gen ID ' ||I_cawa_gen||' does not exists in gap_ris_batch_flow_stage_t table',
                                                  L_program_name,
                                                  NULL);
            RETURN FALSE;
         ---
         END IF;

      CLOSE C_get_batch_run_id;

      RETURN TRUE;
   ---
   EXCEPTION
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
   END GET_BATCH_RUN_ID;
   /* *********************************************************************************************************
   * Function          : WATCH_FAILURE
   * Purpose           : This function watches the failures in a particular EOD cycle
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION WATCH_FAILURE(I_cawa_gen       IN  NUMBER,
                          I_message_family IN  VARCHAR2,
                          O_error_message  OUT VARCHAR2)
   RETURN BOOLEAN
   IS
      L_program_name          VARCHAR2(200)  := 'GAP_BATCH_API.WATCH_FAILURE';
      L_failed_activity_check VARCHAR2(1);
      L_mark                  VARCHAR2(100);
      L_jos_process           ris_consumer_config.service_name%type;

      CUSTOM_EXCEPTION        EXCEPTION;

      CURSOR C_check_failures
      IS
       SELECT 'E'
         FROM gap_ris_batch_job_stage_t jstg --ords_metadata
        WHERE jstg.batch_run_id  = LP_BATCH_RUN_ID
          AND jstg.status        = LP_JOB_FAIL_STATUS --'Job-Failed'
          AND jstg.scan_status   is null
          AND rownum < 2;

      CURSOR C_get_jos_process
      IS
         SELECT service_name
           FROM ris_consumer_config
          WHERE message_type   = 'BATCH'
            AND message_family = I_message_family;

   BEGIN
   ---

      L_mark := 'Fetch C_get_jos_process';
      OPEN  C_get_jos_process;
      FETCH C_get_jos_process INTO L_jos_process;
      CLOSE C_get_jos_process;


      L_mark := 'GET_BATCH_RUN_ID';
      IF GET_BATCH_RUN_ID(I_cawa_gen,
                          L_jos_process,
                          LP_BATCH_RUN_ID,
                          O_error_message) = FALSE
      THEN
      ---
         RAISE CUSTOM_EXCEPTION;
      ---
      END IF;

      L_mark := 'Check for Activity failures';
      OPEN  C_check_failures;
      FETCH C_check_failures INTO L_failed_activity_check;
      CLOSE C_check_failures;

      IF L_failed_activity_check = 'E'
      THEN
         O_error_message := 'Failed jobs found in gap_ris_batch_job_stage_t table';
         RAISE CUSTOM_EXCEPTION;
      END IF;

      ---
      RETURN TRUE;
      ---

   EXCEPTION
      WHEN CUSTOM_EXCEPTION
      THEN
      ---

         UPDATE gap_ris_batch_job_stage_t jstg
            SET jstg.scan_status = LP_JOB_SCAN_STATUS,
                jstg.last_update_datetime = sysdate
          WHERE jstg.batch_run_id  = LP_BATCH_RUN_ID
            AND jstg.scan_status   is null;

         COMMIT;

         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               O_error_message,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
   END WATCH_FAILURE;
   /* *********************************************************************************************************
   * Function          : WATCHER
   * Purpose           : This function watches the completion of JOB/FLOW in RIS layer
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  : I_jos_process   - JOS process name
   *                     I_activity_name - JOS Activity name
   *                     I_cawa_gen      - CAWA generation number
   * Output Parameters : o_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION WATCHER(I_message_family IN  VARCHAR2,
                    I_activity_name  IN  VARCHAR2,
                    I_cawa_gen       IN  NUMBER,
                    O_error_message  OUT VARCHAR2)
   RETURN BOOLEAN
   IS
      L_program_name          VARCHAR2(200)                                   := 'GAP_BATCH_API.WATCHER';
      L_activity_status_check VARCHAR2(1);
      L_failed_activity_check VARCHAR2(1);
      L_process_check         VARCHAR2(1);
      L_max_attempt           NUMBER(4);
      L_sleep_time            NUMBER(4);
      L_mark                  VARCHAR2(100);
      L_plsql_batch_name      VARCHAR2(100)                                   := 'GAP_BATCH_API';
      L_jos_process           ris_consumer_config.service_name%type;

      CUSTOM_EXCEPTION        EXCEPTION;


      CURSOR C_get_batch_config
      IS
       SELECT TO_NUMBER(cd_val_txt),
              TO_NUMBER(attribute1)
         FROM intf_cnfg_parm_t intf
        WHERE intf.pgm_nm      = L_plsql_batch_name
          AND intf.cd_nm       = I_message_family
          AND intf.cnfg_typ_cd = I_activity_name;

      CURSOR C_check_activity_status
      IS
       SELECT 'S'
         FROM gap_ris_batch_job_stage_t jstg
        WHERE jstg.batch_run_id  = LP_BATCH_RUN_ID
          AND jstg.jos_activity  = I_activity_name
          AND jstg.status        = LP_JOB_COMP_STATUS; --'Job-Complete'

      CURSOR C_check_failures
      IS
       SELECT 'E'
         FROM gap_ris_batch_job_stage_t jstg
        WHERE jstg.batch_run_id  = LP_BATCH_RUN_ID
          AND jstg.status        = LP_JOB_FAIL_STATUS --'Job-Failed'
          AND jstg.scan_status   is null
          AND rownum < 2;

      CURSOR C_get_jos_process
      IS
         SELECT service_name
           FROM ris_consumer_config
          WHERE message_type   = 'BATCH'
            AND message_family = I_message_family; ---'NIGHTLY_PROCESS' for e.g. 

   BEGIN
   ---

      L_mark := 'Fetch C_get_jos_process';
      OPEN  C_get_jos_process;
      FETCH C_get_jos_process INTO L_jos_process; --'MERCH_DUMMY_START_NIGHT_BATCH_PROCESS'
      CLOSE C_get_jos_process;

      L_mark := 'Get batch config';
      OPEN  C_get_batch_config;
      FETCH C_get_batch_config INTO L_max_attempt, L_sleep_time;

      IF C_get_batch_config%NOTFOUND
      THEN
      ---
          O_error_message := 'Missing Batch Configuration';
          RAISE CUSTOM_EXCEPTION;
      ---
      END IF;

      CLOSE C_get_batch_config;

      L_mark := 'GET_BATCH_RUN_ID';
      IF GET_BATCH_RUN_ID(I_cawa_gen, -- both cawa genid and jos process needed for batch id 
                          L_jos_process,
                          LP_BATCH_RUN_ID,
                          O_error_message) = FALSE
      THEN
      ---
         RAISE CUSTOM_EXCEPTION;
      ---
      END IF;

      BEGIN
      ---
         FOR i IN 1..L_max_attempt
         LOOP
         ---
            L_activity_status_check := 'S';

            L_mark := 'Check for Process completion status';
            OPEN  C_check_activity_status;
            FETCH C_check_activity_status INTO L_activity_status_check;

               IF C_check_activity_status%FOUND --if completed then exit 
               THEN
               ---
                  CLOSE C_check_activity_status;
                  EXIT;
               ---
               END IF;

            CLOSE C_check_activity_status;
			---if not found to be in completed status then execute below code 
            L_mark := 'Check for Activity failures';
            OPEN  C_check_failures;
            FETCH C_check_failures INTO L_failed_activity_check;

               IF C_check_failures%FOUND
               THEN
               ---
                  CLOSE C_check_failures;
                  EXIT;
               ---
               END IF;

            CLOSE C_check_failures;

            L_activity_status_check := 'E';

            smt_util.sleep (L_sleep_time);
         ---
         END LOOP;
      ---
      END;

      IF L_failed_activity_check = 'E'
      THEN
         O_error_message := 'Failed activity found in gap_ris_batch_job_stage_t table';
         RAISE CUSTOM_EXCEPTION;
      END IF;

      IF L_activity_status_check = 'E'
      THEN
         O_error_message := 'Activity status not updated to'||LP_JOB_COMP_STATUS||'Job-Complete in JOB STG table after checking for '||L_max_attempt*L_sleep_time||'Seconds';
         RAISE CUSTOM_EXCEPTION;
      END IF;

      ---
      RETURN TRUE;
      ---

   EXCEPTION
      WHEN CUSTOM_EXCEPTION
      THEN
      ---
         UPDATE gap_ris_batch_job_stage_t jstg
            SET jstg.scan_status = LP_JOB_SCAN_STATUS,
                jstg.last_update_datetime = sysdate
          WHERE jstg.batch_run_id  = LP_BATCH_RUN_ID
            AND jstg.scan_status   is null;

         COMMIT;

         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               O_error_message,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
   END WATCHER;
   /* *********************************************************************************************************
   * Function          : VALIDATE_SUB
   * Purpose           : Validates JOS/POAM input to RIS layer
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  : I_processs_name     - JOS process name
   *                     I_activity_name     - JOS Activity name
   *                     I_correlation_id    - CAWA generation number
   *                     I_batch_flow_status - batch flow status
   *                     I_job_status        - job status
   * Output Parameters : o_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION VALIDATE_SUB(I_activity_name      IN  VARCHAR2,
                         I_job_status         IN  VARCHAR2,
                         O_error_message      OUT VARCHAR2)
   RETURN BOOLEAN IS

      L_check        VARCHAR2(1);
      L_program_name VARCHAR2(200) := 'GAP_BATCH_API.VALIDATE_SUB';

      L_status       gap_ris_batch_flow_stage_t.status%type;

      CURSOR C_check_job_complete
      IS
         SELECT 'Y'
           FROM gap_ris_batch_job_stage_t jstg
          WHERE jstg.batch_run_id = LP_BATCH_RUN_ID
            AND jstg.jos_activity = I_activity_name
            AND jstg.status       = LP_JOB_COMP_STATUS;

   BEGIN
   ---
      OPEN  C_check_job_complete;
      FETCH C_check_job_complete INTO L_check;

         IF C_check_job_complete%FOUND
         THEN
         ---
            O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                                  L_program_name,
                                                  I_activity_name||' activity already marked completed in job staging table',
                                                  NULL);
            RETURN FALSE;
         ---
         END IF;

      CLOSE C_check_job_complete;

      RETURN TRUE;
   ---
   EXCEPTION
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
   ---
   END VALIDATE_SUB;
   /* *********************************************************************************************************
   * Function          : PROCESS_SUB
   * Purpose           : Processes JOS/POAM input into RIS layer
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  : I_jos_process         - JOS process name
                         I_jos_process_id      - JOS process id
   *                     I_jos_activity        - JOS Activity name
   *                     I_jos_activity_id     - JOS activity id
   *                     I_jos_correlation_id  - CAWA generation number
   *                     I_batch_flow_status - batch flow status
   *                     I_job_status        - job status
   * Output Parameters : o_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION PROCESS_SUB(I_jos_activity       IN  VARCHAR2,
                        I_jos_activity_id    IN  VARCHAR2,
                        I_job_status         IN  VARCHAR2,
                        I_request_string     IN  CLOB,
                        O_error_message      OUT VARCHAR2)
   RETURN BOOLEAN IS

      L_program_name       VARCHAR2(200)                               := 'GAP_BATCH_API.PROCESS_SUB';
      L_batch_flow_status  gap_ris_batch_flow_stage_t.status%TYPE;
      L_cawa_flow          gap_ris_batch_flow_stage_t.cawa_flow%TYPE;

	  L_sysdate            DATE := SYSDATE;
	  L_vdate              DATE;

      CURSOR C_get_prev_vdate
      IS
         SELECT max(vdate)
           FROM ris_vdate_change_log;

   BEGIN
   ---

	  --
      IF L_vdate IS NULL
      THEN
        --
        OPEN  C_get_prev_vdate;
        FETCH C_get_prev_vdate INTO L_vdate;

        IF C_get_prev_vdate%NOTFOUND
        THEN
        ---
            O_error_message := 'Missing Data in ris_vdate_change_log table';
            CLOSE C_get_prev_vdate;
            RETURN FALSE;
        ---
        END IF;

        CLOSE C_get_prev_vdate;
        --
      END IF;
      --

      IF I_jos_activity = 'DTESYS_JOB' AND I_job_status = LP_JOB_COMP_STATUS
      THEN
      --
         -- UPDATE end time for prev vdate
         UPDATE ris_vdate_change_log
            SET end_time = L_sysdate
          WHERE vdate = L_vdate;

         -- Insert new record for current vdate
         INSERT INTO ris_vdate_change_log (vdate,
                                           start_time,
                                           end_time)
               VALUES(L_vdate+1,
                      L_sysdate,
                      null);
      --
      END IF;
     --- Insert into batch Stage table 
      INSERT INTO gap_ris_batch_job_stage_t (batch_run_id,
                                             cawa_gen_id,
                                             cawa_flow,
                                             jos_process,
                                             jos_process_id,
                                             jos_activity,
                                             jos_activity_id,
                                             status,
                                             create_datetime,
                                             last_update_datetime,
                                             last_update_id,
                                             request_string)
           SELECT LP_BATCH_RUN_ID,
                  bstg.cawa_gen_id,
                  bstg.cawa_flow,
                  bstg.jos_process,
                  bstg.jos_process_id,
                  I_jos_activity,
                  I_jos_activity_id,
                  I_job_status,
                  sysdate,
                  sysdate,
                  user,
                  I_request_string
             FROM gap_ris_batch_flow_stage_t bstg
            WHERE bstg.batch_run_id = LP_BATCH_RUN_ID;

      RETURN TRUE;
   ---
   EXCEPTION
      WHEN OTHERS
      THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
   END PROCESS_SUB;
   /* *********************************************************************************************************
   * Function          : SUBSCRIBE
   * Purpose           : Wrapper function to validate/process JOS/POAM input
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  : I_batch_blob    - Input object from JOS/POAM
   * Output Parameters : o_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   PROCEDURE SUBSCRIBE(I_batch_blob    IN  BLOB,
                       O_error_message OUT VARCHAR2)
   IS
   --
      L_program_name          VARCHAR2(200)        := 'GAP_BATCH_API.SUBSCRIBE';
      L_error_code            VARCHAR2(50);
      L_mark                  VARCHAR2(100);
      O_batch_clob            CLOB;

      L_jos_process           gap_ris_batch_flow_stage_t.jos_process%type;
      L_jos_process_id        gap_ris_batch_flow_stage_t.jos_process_id%type;
      L_cawa_gen_id           gap_ris_batch_flow_stage_t.cawa_gen_id%type;
      L_json_status           gap_ris_batch_job_stage_t.status%type;
      L_status                gap_ris_batch_job_stage_t.status%type;
      L_jos_activity          gap_ris_batch_job_stage_t.jos_activity%type;
      L_jos_activity_id       gap_ris_batch_job_stage_t.jos_activity_id%type;

      CUSTOM_EXCEPTION        EXCEPTION;

      PARSE_EXCEPTION   EXCEPTION;
      PRAGMA exception_init(PARSE_EXCEPTION, -20987);

   BEGIN

      -- Convert BLOB input to CLOB
      IF RIS_ORDS_LIBRARY.CONV_BLOB_TO_CLOB(O_error_message,
                                            I_batch_blob,
                                            O_batch_clob) = FALSE
      THEN
      --
         L_error_code := 'ERROR_WHILE_CONVERTING_CLOB';
         RAISE CUSTOM_EXCEPTION;
      --
      END IF;
      --

      L_mark := 'APEX_JSON.PARSE';
      -- Parse order JSON message
      APEX_JSON.PARSE(O_batch_clob);
      --

      L_jos_process     := APEX_JSON.get_varchar2(p_path => 'processName');
      L_jos_process_id  := APEX_JSON.get_varchar2(p_path => 'processExceutionId');
      L_jos_activity    := APEX_JSON.get_varchar2(p_path => 'activityName');
      L_jos_activity_id := APEX_JSON.get_varchar2(p_path => 'activityExecutionId');
      L_cawa_gen_id     := APEX_JSON.get_varchar2(p_path => 'correlationId');
      L_json_status     := APEX_JSON.get_varchar2(p_path => 'activityStatus');

      IF L_json_status = 'ACTIVITY_COMPLETED'
      THEN
         L_status := LP_JOB_COMP_STATUS;
      ELSE
         L_status := LP_JOB_FAIL_STATUS;
      END IF;

      L_mark := 'GET_BATCH_RUN_ID';
      IF GET_BATCH_RUN_ID(L_cawa_gen_id,
                          L_jos_process,
                          LP_BATCH_RUN_ID,
                          O_error_message) = FALSE
      THEN
      --
         L_error_code := 'VALIDATION_ERROR';
         RAISE CUSTOM_EXCEPTION;
      --
      END IF;

      L_mark := 'VALIDATE_SUB';
      IF VALIDATE_SUB(L_jos_activity,
                      L_status,
                      O_error_message) = FALSE
      THEN
      --
         L_error_code := 'VALIDATION_ERROR';
         RAISE CUSTOM_EXCEPTION;
      --
      END IF;

      L_mark := 'PROCESS_SUB';
      IF PROCESS_SUB(L_jos_activity,
                     L_jos_activity_id,
                     L_status,
                     O_batch_clob,
                     O_error_message) = FALSE
      THEN
      ---
         L_error_code := 'JSON_PROCESS_ERROR';
         RAISE CUSTOM_EXCEPTION;
      ---
      END IF;

      ---
      COMMIT;
      ---
      RETURN ;

   EXCEPTION
      WHEN CUSTOM_EXCEPTION
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('CUSTOM_EXCEPTION',
                                               L_error_code||O_error_message,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
           --Store the request string
           INSERT INTO gap_ris_batch_job_stage_t (batch_run_id,
                                                  cawa_gen_id,
                                                  cawa_flow,
                                                  error_message,
                                                  status,
                                                  last_update_datetime,
                                                  last_update_id,
                                                  request_string)
           SELECT -1,
                  -1,
                  'NA',
                  O_error_message,
                  LP_JOB_FAIL_STATUS,
                  sysdate,
                  user,
                  O_batch_clob
             FROM dual;
            --
            COMMIT;
            --
            RETURN ;
            --
      WHEN PARSE_EXCEPTION
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PARSE_EXCEPTION',
                                               'Error while parsing Input JSON',
                                               L_program_name,
                                               null);
         --Store the request string
           INSERT INTO gap_ris_batch_job_stage_t (batch_run_id,
                                                  cawa_gen_id,
                                                  cawa_flow,
                                                  error_message,
                                                  status,
                                                  last_update_datetime,
                                                  last_update_id,
                                                  request_string)
           SELECT -1,
                  -1,
                  'NA',
                  O_error_message,
                  LP_JOB_FAIL_STATUS,
                  sysdate,
                  user,
                  O_batch_clob
             FROM dual;
            --
            COMMIT;
            --
            RETURN ;
            --
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM||'at'||L_mark,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         --Store the request string
           INSERT INTO gap_ris_batch_job_stage_t (batch_run_id,
                                                  cawa_gen_id,
                                                  cawa_flow,
                                                  error_message,
                                                  status,
                                                  last_update_datetime,
                                                  last_update_id,
                                                  request_string)
           SELECT -1,
                  -1,
                  'NA',
                  O_error_message,
                  LP_JOB_FAIL_STATUS,
                  sysdate,
                  user,
                  O_batch_clob
             FROM dual;
            --
            COMMIT;
            --
            RETURN ;
            --
   END SUBSCRIBE;
   /* *********************************************************************************************************
   * Function          : POPULATE_BATCH_STG
   * Purpose           : Function to populate batch staging table
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  :
   *                     I_cawa_gen            - CAWA generation number
   *                     I_cawa_qual           - CAWA qualifier id
   *                     I_cawa_flow           - CAWA flow name
   *                     I_cawa_job            - CAWA job name
   *                     I_jos_process         - JOS process name
   *                     I_call_status         - job status
   * Output Parameters : L_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION POPULATE_BATCH_STG(I_cawa_gen      IN  NUMBER,
                               I_cawa_qual     IN  VARCHAR2,
                               I_cawa_flow     IN  VARCHAR2,
                               I_cawa_job      IN  VARCHAR2,
                               I_jos_process   IN  VARCHAR2,
                               I_call_status   IN  BOOLEAN,
                               L_error_message OUT VARCHAR2)
   RETURN BOOLEAN IS
   ---

      L_program_name    VARCHAR2(200)  := 'POPULATE_BATCH_STG';
      L_check           VARCHAR2(1)    := 'N';
      L_rowid           rowid;
      L_table           varchar(50)    := 'gap_ris_batch_flow_stage_t';

      VALIDATE_REQUEST  EXCEPTION;

      CURSOR C_check_request
      IS
         SELECT 'Y'
           FROM gap_ris_batch_flow_stage_t bstg,
                ris_consumer_config cnfg
          WHERE bstg.cawa_gen_id     = I_cawa_gen
            AND bstg.cawa_qualifier  = I_cawa_qual
            AND bstg.cawa_flow       = I_cawa_flow
            AND bstg.jos_process     = cnfg.service_name
            AND bstg.status          = LP_BATCH_RESP_STATUS --Response-Received
            AND cnfg.message_type    = 'BATCH'
            AND cnfg.message_family  = I_jos_process;

   BEGIN
      ---

      OPEN  C_check_request;
      FETCH C_check_request INTO L_check;
      CLOSE C_check_request;

      IF L_check = 'Y'
      THEN
         RAISE VALIDATE_REQUEST;
      END IF;

      SELECT gap_batch_run_seq.nextval INTO LP_BATCH_RUN_ID FROM dual;

      INSERT INTO gap_ris_batch_flow_stage_t (batch_run_id,
                                              cawa_gen_id, --this comes from command line of shell 
                                              cawa_qualifier,
                                              cawa_flow,
                                              cawa_job,
                                              status,
                                              jos_process,--this comes from command line of shell
                                              create_datetime,
                                              update_id
                                              )
           SELECT LP_BATCH_RUN_ID,
                  I_cawa_gen,
                  I_cawa_qual,
                  I_cawa_flow,
                  I_cawa_job,
                  LP_BATCH_INIT_STATUS,
                  cnfg.service_name,
                  sysdate,
                  user
             FROM ris_consumer_config cnfg
            WHERE cnfg.message_type = 'BATCH'
              AND cnfg.message_family = I_jos_process;

      ---
      COMMIT;
      ---
      RETURN TRUE;
      ---

   EXCEPTION
      WHEN VALIDATE_REQUEST
      THEN
      ---
         L_error_message := SQL_LIB.CREATE_MSG('INVALID_REQUEST',
                                               'Request already initiated in JOS/POAM, please refer to batch stage table',
                                               L_program_name,
                                               null);
         RETURN FALSE;
      WHEN OTHERS
      THEN
      ---
         L_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
   END POPULATE_BATCH_STG;
   /* *********************************************************************************************************
   * Function          : INVOKE_JOS_SERVICE
   * Purpose           : Function to invoke JOS service for triggering batch
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  :
   *                     I_cawa_gen            - CAWA generation number
   *                     I_jos_process         - JOS process name
   * Output Parameters : O_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION INVOKE_JOS_SERVICE(I_cawa_gen       IN  NUMBER,
                               I_jos_process    IN  VARCHAR2,
                               O_error_message  OUT VARCHAR2)
   RETURN BOOLEAN IS

      L_program_name    VARCHAR2(200)                                      := 'INVOKE_JOS_SERVICE';
      L_grant_type      VARCHAR2(50)                                       := 'client_credentials';
      L_response        CLOB;
      L_token           CLOB;
      L_mark            VARCHAR2(250);
      L_caller_id       VARCHAR(5)                                         := 'CAWA';

      L_processname     gap_ris_batch_flow_stage_t.jos_process%type;
      L_exec_id         gap_ris_batch_flow_stage_t.jos_process_id%type;
      L_url             VARCHAR2(4000);
      L_user            ris_sec_config.keystore_name%type;
      L_password        VARCHAR2(1000);
      L_auth_url        ris_sec_config.keystore_path%type;
      L_client_id       ris_sec_config.private_key_alias%type;
      L_client_secret   VARCHAR2(1000);
      L_access_tocken   VARCHAR2(1000);
      L_wallet_path     VARCHAR2(1000);
      L_wallet_pwd      VARCHAR2(1000);
      L_jos_process     VARCHAR2(1000);
      L_api_key         VARCHAR2(1000);
      L_port_name       RIS_SEC_CONFIG.PORT_NAME%TYPE;
      L_http_host       VARCHAR2(1000);
      L_config_id       RIS_CONSUMER_CONFIG.CONFIG_ID%TYPE := NULL;
      L_action          ris_sec_config.action%type;
      L_wls_uri         ris_sec_config.wls_uri%type;


      PARSE_EXCEPTION   EXCEPTION;
      PRAGMA exception_init(PARSE_EXCEPTION, -20987);

      CURSOR C_get_web_url
      IS
         SELECT rcc.service_name               AS jos_process, --'MERCH_DUMMY_START_NIGHT_BATCH_PROCESS'
                rcc.config_id                  AS config_id --2007
           FROM ris_consumer_config rcc
          WHERE message_type     = 'BATCH'
            AND message_family   = I_jos_process; -- take the example of NIGHTLY_PROCESS

      CURSOR C_parse_responses
      IS
         SELECT APEX_JSON.get_varchar2(p_path => 'processName'),
                APEX_JSON.get_varchar2(p_path => 'executionId')
           FROM dual;

   BEGIN
   ---

      L_mark := 'C_get_web_url Cursor';
      OPEN  C_get_web_url;
      FETCH C_get_web_url INTO L_jos_process,
                               L_config_id;

      IF C_get_web_url%NOTFOUND
      THEN
         CLOSE C_get_web_url;
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config for, '||I_jos_process,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;
    --Dimessins
      CLOSE C_get_web_url;

      IF GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(O_error_message,
                                                    L_config_id,
                                                    L_url,
                                                    L_action,
                                                    L_wls_uri,
                                                    L_user,
                                                    L_password,
                                                    L_client_id,
                                                    L_client_secret,
                                                    L_auth_url,
                                                    L_wallet_path,
                                                    L_wallet_pwd,
                                                    L_http_host,
                                                    L_port_name,
                                                    L_api_key
                                                    ) = FALSE THEN
         RETURN FALSE;
      END IF;

      -- Appending cawa gen id with L_url
      L_url := L_url||'?processParameters=callerId='||L_caller_id||',correlationId='||I_cawa_gen;

      UPDATE gap_ris_batch_flow_stage_t bstg
         SET bstg.request_url       = L_url
       WHERE bstg.batch_run_id = LP_BATCH_RUN_ID;




      IF L_auth_url IS NULL -- for MERCH_DUMMY_START_NIGHT_BATCH_PROCESS it's NULL 
      THEN
      ---
         L_mark := 'Basic Authentication';
         L_response := apex_web_service.make_rest_request(p_url         => L_url,
                                                          p_http_method => 'POST', ---send the request
                                                          P_username    => L_user,
                                                          P_password    => L_password,
                                                          p_wallet_path => L_wallet_path,
                                                          p_wallet_pwd  => L_wallet_pwd);
      ELSE
      ---
         L_mark := 'Oauth Toekn Retrieval';

         -- Set headers
		 ----delete before setting the headers 
		 apex_web_service.g_request_headers.delete(); --added by me 
		 
         apex_web_service.g_request_headers(1).name  := 'Content-Type';
         apex_web_service.g_request_headers(1).value := 'application/x-www-form-urlencoded';

         -- Get tocken
         L_token := apex_web_service.make_rest_request(p_url          => L_auth_url,
                                                       p_http_method  => 'POST',
                                                       p_username     => L_client_id,
                                                       p_password     => L_client_secret,
                                                       p_parm_name    => apex_util.string_to_table('grant_type'),
                                                       p_parm_value   => apex_util.string_to_table(L_grant_type),
                                                       p_wallet_path  => L_wallet_path,
                                                       p_wallet_pwd   => L_wallet_pwd);

         APEX_JSON.parse(L_token);

         L_access_tocken := apex_json.get_varchar2 (p_path => 'access_token');

         L_mark := 'Oauth Authentication';
         apex_web_service.g_request_headers(1).name  := 'Authorization';
         apex_web_service.g_request_headers(1).value := 'Bearer ' || L_access_tocken;

         L_response := apex_web_service.make_rest_request(p_url         => l_url,
                                                          p_http_method => 'POST',
                                                          p_wallet_path => L_wallet_path,
                                                          p_wallet_pwd  => L_wallet_pwd);
      ---
      END IF;

      L_mark := 'Parse L_response';

      APEX_JSON.parse(L_response); --parse the response 

      OPEN  C_parse_responses;
      FETCH C_parse_responses INTO L_processname,L_exec_id;
      CLOSE C_parse_responses;

      IF L_processname IS NULL OR
         L_exec_id     IS NULL
      THEN
      ---
         RAISE PARSE_EXCEPTION;
      ---
      END IF;



      UPDATE gap_ris_batch_flow_stage_t bstg
         SET bstg.jos_process_id       = L_exec_id,
             bstg.status               = LP_BATCH_RESP_STATUS,
             bstg.last_update_datetime = sysdate,
             bstg.ws_response          = L_response
       WHERE bstg.batch_run_id         = LP_BATCH_RUN_ID;

      RETURN TRUE;

   EXCEPTION
      WHEN PARSE_EXCEPTION
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PARSE_ERROR',
                                               'Error while parsing JSON response' ||' at '||L_mark,
                                               L_program_name,
                                               null);

         UPDATE gap_ris_batch_flow_stage_t bstg
            SET bstg.error_message   = O_error_message,
                bstg.status          = LP_BATCH_FAIL_STATUS,
                bstg.create_datetime = sysdate,
                bstg.ws_response     = L_response
       WHERE bstg.batch_run_id = LP_BATCH_RUN_ID;

         RETURN FALSE;
      ---
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM ||' at '||L_mark,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));

         UPDATE gap_ris_batch_flow_stage_t bstg
            SET bstg.error_message   = O_error_message,
                bstg.status          = LP_BATCH_FAIL_STATUS,
                bstg.create_datetime = sysdate,
                bstg.ws_response     = L_response
       WHERE bstg.batch_run_id = LP_BATCH_RUN_ID;

         RETURN FALSE;
      ---
   END INVOKE_JOS_SERVICE;
   /* *********************************************************************************************************
   * Function          : INVOKE_JOS_SERVICE
   * Purpose           : Function to invoke JOS service for triggering batch
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  :
   *                     I_cawa_gen            - CAWA generation number
   *                     I_jos_process         - JOS process name
   * Output Parameters : O_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 26-MAR-2017   0.1    Infosys   Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION PUBLISH(I_cawa_gen       IN  NUMBER,
                    I_cawa_qual      IN  VARCHAR2,
                    I_cawa_flow      IN  VARCHAR2,
                    I_cawa_job       IN  VARCHAR2,
                    I_jos_process    IN  VARCHAR2,
                    O_error_message  OUT VARCHAR2)
   RETURN BOOLEAN IS

      L_program_name          VARCHAR2(200)                 := 'GAP_BATCH_API.PUBLISH';
      L_error_message         VARCHAR2(2000);
      L_mark                  VARCHAR2(100);
      L_call_status           BOOLEAN                       := TRUE;

      FATAL_EXCEPTION         EXCEPTION;
      SERVICE_EXCEPTION       EXCEPTION;

   BEGIN

      L_mark := 'Validate Input Parameters';
      IF I_cawa_gen  IS NULL OR
         I_cawa_qual IS NULL OR
         I_cawa_flow IS NULL OR
         I_cawa_job  IS NULL OR
         I_jos_process IS NULL
      THEN
         L_error_message := 'Missing Mandatory Input Parameters';
         RAISE FATAL_EXCEPTION;
      END IF;

      L_mark := 'Call POPULATE_BATCH_STG';
      IF POPULATE_BATCH_STG(I_cawa_gen,
                            I_cawa_qual,
                            I_cawa_flow,
                            I_cawa_job,
                            I_jos_process,
                            L_call_status,
                            L_error_message) = FALSE
      THEN
         RAISE FATAL_EXCEPTION;
      END IF;

      L_mark := 'Call INVOKE_JOS_SERVICE';
      IF INVOKE_JOS_SERVICE(I_cawa_gen,
                            I_jos_process,
                            L_error_message) = FALSE
      THEN
         RAISE SERVICE_EXCEPTION;
      END IF;

      ---
      COMMIT;
      RETURN TRUE;
      ---

   EXCEPTION
      WHEN FATAL_EXCEPTION
      THEN
      ---
         O_error_message := L_error_message;
         ROLLBACK;
         RETURN FALSE;
      WHEN SERVICE_EXCEPTION
      THEN
      ---
         O_error_message := L_error_message;
         COMMIT;
         RETURN FALSE;
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         ROLLBACK;
         RETURN FALSE;
   END PUBLISH;
   ------------------------------------------------------------------------------------------------
  /* **********************************************************************************************
   * Function          : PUBLISH_RELEASE_EXTERNAL_JOB
   * Purpose           : Function to make service call to release external dependency in POM
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Input Parameters  : I_cawa_gen            - CAWA generation number
   *                     I_cawa_qual           - CAWA Qualifier
   *                     I_cawa_flow           - CAWA Flow name
   *                     I_cawa_job            - CAWA Job name
   *                     I_message_family      - Message family
   * Output Parameters : O_error_message - error message
   *
   * Date          Ver    Author    Description
   * ====          ===    ======    ===========
   * 11-SEP-2018   0.1    Infosys   Initial Version
   ***********************************************************************************************/

   FUNCTION PUBLISH_RELEASE_EXTERNAL_JOB(I_cawa_gen         IN    NUMBER,
                                         I_cawa_qual        IN    VARCHAR2,
                                         I_cawa_flow        IN    VARCHAR2,
                                         I_cawa_job         IN    VARCHAR2,
                                         I_message_family   IN    VARCHAR2,
                                         I_pom_ext_job      IN    VARCHAR2,
                                         O_error_message    OUT   VARCHAR2)
   RETURN BOOLEAN IS

      L_program_name      VARCHAR2(200)        := 'GAP_BATCH_API.PUBLISH_RELEASE_EXTERNAL_JOB';
      L_mark              VARCHAR2(100);
      L_value             VARCHAR2(10);
      L_status            VARCHAR2(20);
      L_response          CLOB;
      L_call_status       BOOLEAN              := TRUE;
      --
      L_url               VARCHAR2(4000);
      L_user              ris_sec_config.keystore_name%type;
      L_password          VARCHAR2(1000);
      L_auth_url          ris_sec_config.keystore_path%type;
      L_client_id         ris_sec_config.private_key_alias%type;
      L_jos_process       ris_consumer_config.service_name%type;
      L_client_secret     VARCHAR2(1000);
      L_access_tocken     VARCHAR2(1000);
      L_wallet_path       VARCHAR2(1000);
      L_wallet_pwd        VARCHAR2(1000);
      L_ext_jos_process   VARCHAR2(1000);
      L_api_key         VARCHAR2(1000);
      L_port_name       RIS_SEC_CONFIG.PORT_NAME%TYPE;
      L_http_host       VARCHAR2(1000);
      L_config_id       RIS_CONSUMER_CONFIG.CONFIG_ID%TYPE := NULL;
      L_action            ris_sec_config.action%type;
      L_wls_uri           ris_sec_config.wls_uri%type;

      PARSE_EXCEPTION     EXCEPTION;
      CUSTOM_EXCEPTION    EXCEPTION;

      CURSOR C_get_web_url
      IS
         SELECT rcc.service_name        AS jos_process,
                rcc.config_id           AS config_id
           FROM ris_consumer_config rcc
          WHERE rcc.message_type     = 'BATCH'
            AND rcc.message_family   = I_pom_ext_job;

      CURSOR C_get_jos_process
      IS
         SELECT service_name
           FROM ris_consumer_config
          WHERE message_type   = 'BATCH'
            AND message_family = I_message_family;

      CURSOR C_parse_responses
      IS
         SELECT APEX_JSON.get_varchar2(p_path => 'value')
           FROM dual;

   BEGIN

      L_mark := 'Validate Input Parameters';
      IF I_cawa_gen       IS NULL OR
         I_cawa_qual      IS NULL OR
         I_cawa_flow      IS NULL OR
         I_cawa_job       IS NULL OR
         I_message_family IS NULL OR
         I_pom_ext_job    IS NULL
      THEN
         O_error_message := 'Missing Mandatory Input Parameters';
         RAISE CUSTOM_EXCEPTION;
      END IF;

      L_mark := 'Fetch C_get_jos_process';
       OPEN C_get_jos_process;
      FETCH C_get_jos_process INTO L_jos_process;
      CLOSE C_get_jos_process;

      L_mark := 'GET_BATCH_RUN_ID';
      IF GET_BATCH_RUN_ID(I_cawa_gen,
                          L_jos_process,
                          LP_BATCH_RUN_ID,
                          O_error_message) = FALSE
      THEN
         O_error_message := 'No request found for JOS process: '||L_jos_process|| ' and CAWA Gen ID: ' || I_cawa_gen;
         RAISE CUSTOM_EXCEPTION;
      END IF;

      L_mark := 'Insert into JOB table';
      INSERT INTO GAP_RIS_BATCH_JOB_STAGE_T (batch_run_id        ,
                                             cawa_gen_id         ,
                                             cawa_flow           ,
                                             jos_process         ,
                                             jos_process_id      ,
                                             jos_activity        ,
                                             jos_activity_id     ,
                                             status              ,
                                             create_datetime     ,
                                             last_update_datetime,
                                             last_update_id      ,
                                             request_string
                                             )
                                      SELECT LP_BATCH_RUN_ID    ,
                                             bstg.cawa_gen_id   ,
                                             bstg.cawa_flow     ,
                                             bstg.jos_process   ,
                                             bstg.jos_process_id,
                                             I_pom_ext_job      ,
                                             NULL               ,
                                             NULL               ,
                                             SYSDATE            ,
                                             SYSDATE            ,
                                             USER               ,
                                             NULL
                                        FROM gap_ris_batch_flow_stage_t bstg
                                       WHERE bstg.batch_run_id = LP_BATCH_RUN_ID;

      L_mark := 'C_get_web_url Cursor';
       OPEN C_get_web_url;
      FETCH C_get_web_url INTO L_ext_jos_process,
                               L_config_id;

      IF C_get_web_url%NOTFOUND
      THEN
         CLOSE C_get_web_url;
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config for, '||I_pom_ext_job,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;

      CLOSE C_get_web_url;

      IF GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(O_error_message,
                                                    L_config_id,
                                                    L_url,
                                                    L_action,
                                                    L_wls_uri,
                                                    L_user,
                                                    L_password,
                                                    L_client_id,
                                                    L_client_secret,
                                                    L_auth_url,
                                                    L_wallet_path,
                                                    L_wallet_pwd,
                                                    L_http_host,
                                                    L_port_name,
                                                    L_api_key
                                                    ) = FALSE THEN
         RETURN FALSE;
      END IF;

      -- Request Headers
      APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).name  := 'Accept-Version';
      APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).value := '16.0';

      APEX_WEB_SERVICE.G_REQUEST_HEADERS(2).name  := 'Content-Type';
      APEX_WEB_SERVICE.G_REQUEST_HEADERS(2).value := 'application/json';

      IF L_auth_url IS NULL
      THEN
         L_mark := 'Basic Authentication';
         --
         L_response := APEX_WEB_SERVICE.MAKE_REST_REQUEST(p_url         => L_url,
                                                          p_http_method => 'POST',
                                                          P_username    => L_user,
                                                          P_password    => L_password,
                                                          p_wallet_path => L_wallet_path,
                                                          p_wallet_pwd  => L_wallet_pwd);
      END IF;

      L_mark := 'Parse L_response';
      --
      APEX_JSON.parse(L_response);

       OPEN C_parse_responses;
      FETCH C_parse_responses INTO L_value;
      CLOSE C_parse_responses;

      IF L_value IS NULL
      THEN
         L_status := LP_JOB_FAIL_STATUS;
         RAISE PARSE_EXCEPTION;
      END IF;

      IF L_value = 'true'
      THEN
         L_status := LP_JOB_COMP_STATUS;
      ELSE
         L_status := LP_JOB_FAIL_STATUS;
      END IF;

      UPDATE gap_ris_batch_job_stage_t bstg
         SET bstg.status               = L_status,
             bstg.last_update_datetime = sysdate,
             bstg.request_string       = L_response
       WHERE bstg.batch_run_id         = LP_BATCH_RUN_ID
         AND bstg.jos_activity         = I_pom_ext_job;

      COMMIT;

      IF L_status = LP_JOB_COMP_STATUS
      THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;

   EXCEPTION
      WHEN CUSTOM_EXCEPTION
      THEN
         UPDATE gap_ris_batch_job_stage_t bstg
            SET bstg.status               = LP_JOB_FAIL_STATUS,
                bstg.error_message        = O_error_message,
                bstg.last_update_datetime = sysdate
          WHERE bstg.batch_run_id         = LP_BATCH_RUN_ID
            AND bstg.jos_activity         = I_pom_ext_job;

         RETURN FALSE;

      WHEN PARSE_EXCEPTION
      THEN
      --
         O_error_message := SQL_LIB.CREATE_MSG('PARSE_ERROR',
                                               'Error while parsing JSON response' ||' at '||L_mark,
                                               L_program_name,
                                               null);

         UPDATE gap_ris_batch_job_stage_t bstg
            SET bstg.status               = LP_JOB_FAIL_STATUS,
                bstg.error_message        = O_error_message,
                bstg.last_update_datetime = sysdate
          WHERE bstg.batch_run_id         = LP_BATCH_RUN_ID
            AND bstg.jos_activity         = I_pom_ext_job;

         RETURN FALSE;
      --
      WHEN OTHERS
      THEN
      ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM ||' at '||L_mark,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));

         UPDATE gap_ris_batch_job_stage_t bstg
            SET bstg.status               = LP_JOB_FAIL_STATUS,
                bstg.error_message        = O_error_message,
                bstg.last_update_datetime = sysdate,
                bstg.request_string       = L_response
          WHERE bstg.batch_run_id         = LP_BATCH_RUN_ID
            AND bstg.jos_activity         = I_pom_ext_job;

         RETURN FALSE;
      ---
   END PUBLISH_RELEASE_EXTERNAL_JOB;
   ------------------------------------------------------------------------------------------------
END GAP_BATCH_API;
/
