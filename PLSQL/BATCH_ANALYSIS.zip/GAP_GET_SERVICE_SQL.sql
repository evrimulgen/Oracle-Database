CREATE OR REPLACE PACKAGE        GAP_GET_SERVICE_SQL
IS

FUNCTION  GAP_GET_SERVICE_CONFIG(  O_error_message    IN OUT    VARCHAR2,
                                   I_config_id        IN        NUMBER,
                                   O_url              OUT       VARCHAR2,
                                   O_action           OUT       VARCHAR2,
                                   O_wls_uri          OUT       VARCHAR2,
                                   O_username         OUT       VARCHAR2,
                                   O_password         OUT       VARCHAR2,
                                   O_client_id        OUT       VARCHAR2,
                                   O_client_secret    OUT       VARCHAR2,
                                   O_auth_url         OUT       VARCHAR2,
                                   O_wallet_path      OUT       VARCHAR2,
                                   O_wallet_password  OUT       VARCHAR2,
                                   O_server           OUT       VARCHAR2,
                                   O_port_name        OUT       VARCHAR2,
                                   O_sys_account      OUT       VARCHAR2
                                   )
RETURN BOOLEAN;

END GAP_GET_SERVICE_SQL;
/


CREATE OR REPLACE PACKAGE BODY        GAP_GET_SERVICE_SQL
IS

FUNCTION  GAP_GET_SERVICE_CONFIG(  O_error_message    IN OUT    VARCHAR2,
                                   I_config_id        IN        NUMBER,
                                   O_url              OUT       VARCHAR2,
                                   O_action           OUT       VARCHAR2,
                                   O_wls_uri          OUT       VARCHAR2,
                                   O_username         OUT       VARCHAR2,
                                   O_password         OUT       VARCHAR2,
                                   O_client_id        OUT       VARCHAR2,
                                   O_client_secret    OUT       VARCHAR2,
                                   O_auth_url         OUT       VARCHAR2,
                                   O_wallet_path      OUT       VARCHAR2,
                                   O_wallet_password  OUT       VARCHAR2,
                                   O_server           OUT       VARCHAR2,
                                   O_port_name        OUT       VARCHAR2,
                                   O_sys_account      OUT       VARCHAR2
                                   )
RETURN BOOLEAN
IS
   -- Variable Declaration
   L_program              VARCHAR2(50)   := 'RISGAP.GAP_GET_SERVICE_CONFIG';
   L_mark                 VARCHAR2(1000);
   --
   CURSOR C_GET_SERVICE_CONFIG
   IS
     SELECT rsc.url,
            rsc.action,
            rsc.wls_uri,
            rsc.private_key_alias username,
            sys.utl_raw.cast_to_varchar2(rsc.private_key_alias_passwd) password,
            keystore_name                                                                   AS client_id,
            sys.utl_raw.cast_to_varchar2(keystore_passwd)                                   AS client_secret,
            keystore_path                                                                   AS auth_url,
            wallet_path                                                                     AS wallet_path,
            sys.utl_raw.cast_to_varchar2(wallet_password)                                   AS wallet_pwd,
            server                                                                          AS https_host,
            port_name                                                                       AS port_name,
            sys.utl_raw.cast_to_varchar2(sys_account)                                       AS x_api_key
       FROM ris_sec_config rsc
      WHERE config_id         = I_config_id;


BEGIN
   --
   L_mark := 'Calling C_GET_SERVICE_CONFIG';
   --
   OPEN C_GET_SERVICE_CONFIG;
   FETCH C_GET_SERVICE_CONFIG INTO O_url,
                                   O_action,
                                   O_wls_uri,
                                   O_username,
                                   O_password,
                                   O_client_id,
                                   O_client_secret,
                                   O_auth_url,
                                   O_wallet_path,
                                   O_wallet_password,
                                   O_server,
                                   O_port_name,
                                   O_sys_account;

     IF C_GET_SERVICE_CONFIG%NOTFOUND THEN
     CLOSE C_GET_SERVICE_CONFIG;
      O_error_message := SQL_LIB.CREATE_MSG('NO_SERVICE_CONFIG',
                                            NULL,
                                            NULL,
                                            NULL);
      RETURN FALSE;
   END IF;

   CLOSE C_GET_SERVICE_CONFIG;

   RETURN TRUE;

EXCEPTION
   when OTHERS then
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program,
                                            TO_CHAR(SQLCODE));
   RETURN FALSE;
END GAP_GET_SERVICE_CONFIG;

END GAP_GET_SERVICE_SQL;
/
