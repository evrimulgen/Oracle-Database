CREATE OR REPLACE PACKAGE        RIS_APEX_SERVICE
IS
    --
    L_vdate                 DATE                        := SYSDATE;
    REST_SERVICE_TYPE       CONSTANT    VARCHAR2(10)    := 'REST';
    SOAP_SERVICE_TYPE       CONSTANT    VARCHAR2(10)    := 'SOAP';
    APEX_GET_SERVICE        CONSTANT    VARCHAR2(10)    := 'GET';
    APEX_POST_SERVICE       CONSTANT    VARCHAR2(10)    := 'POST';
    --
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  CHECK_JSON_IN_RESPONSE
-- Purpose      :
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION CHECK_JSON_IN_RESPONSE(O_error_message   IN OUT NOCOPY VARCHAR2,
                                I_response        IN OUT CLOB)
RETURN BOOLEAN;


    /* *********************************************************************************************************
* Function          : POST_SOAP_REQUEST
* Purpose           :
* DESC              :

*
* Date            Ver    Author                 Description
* ====            ===    ======                 ===========
* 23-FEB-2017     0.0    Pradeep G,             Initial Version
*
***********************************************************************************************************/
FUNCTION POST_SOAP_REQUEST(O_error_message       IN OUT         VARCHAR2,
                           O_response            IN OUT            CLOB,
                           I_message_id          IN             NUMBER,
                           I_instance_id         IN             NUMBER DEFAULT 1)
    RETURN BOOLEAN;

/* *********************************************************************************************************
* Function          : GET_REST_RESPONSE
* Purpose           :
* DESC              :
    I_url_param is the parameters to be appended afetr the urlencoded
    --I_parm_name is the parameter names. For Rest calls, it is of format param1:param2:param3..
    --I_parm_value is the parameter name values.For Rest calls, it is of format param_value1:param_value2:param_value3..
    I_http_method is the http_method like GET or POST
    I_service_url  is the url to be used in case of urls generated dynamically from external systems
    Rest of the parameters are self explanatory
*
* Date            Ver    Author                 Description
* ====            ===    ======                 ===========
* 04-April-2017   0.0    Sobu                   Initial Version
*
***********************************************************************************************************/
FUNCTION GET_REST_RESPONSE(O_error_message       IN OUT         VARCHAR2,
                     O_response            OUT            CLOB,
                     I_url_param           IN             VARCHAR2,
                    -- I_parm_name           IN             VARCHAR2,
                    -- I_parm_value          IN             VARCHAR2,
                     I_http_method         IN             VARCHAR2,
                     I_instance_id         IN             VARCHAR2,
                     I_message_type        IN             VARCHAR2,
                     I_message_family      IN             VARCHAR2,
                     I_service_url         IN             VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN;
/* ******************************************************************************************************
* Function          : PUBLISH_RIB4EXT
* Purpose           : Function is used to publish the message to RIB4EXT
*
* Return Parameter  : TRUE for Success and FALSE for Failure
* Output Parameters : o_error_message - error message
*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 24-FEB-2018   1.0    INFOSYS Rajeev Naik    Initial Version
*
********************************************************************************************************** */
FUNCTION  PUBLISH_RIB4EXT(O_error_message IN OUT VARCHAR2,
                          I_Message_Id    IN     NUMBER)
  RETURN BOOLEAN;
/* ******************************************************************************************************
* Function          : POST_REST_REQUEST
* Purpose           : Function is used to post the REST request to RMS
*
* Return Parameter  : TRUE for Success and FALSE for Failure
* Output Parameters : o_error_message - error message
*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 20-Jun-2018   1.0    INFOSYS Rajeev Naik    Initial Version
*
********************************************************************************************************** */
FUNCTION POST_REST_REQUEST(O_error_message          IN OUT         VARCHAR2,
                           O_response               OUT            CLOB,
                           I_message_id             IN             NUMBER)
    RETURN BOOLEAN;
/* ******************************************************************************************************
* Function          : POST_REST_REQUEST
* Purpose           : Function is used to post the REST request to systems other than RMS,
*                     it bypasses RIS layer and directly call to rest services.
*                     Currently support OAUTH 2 authentication mode.
*
*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 23-Jul-2019   1.0    INFOSYS                Initial Version
*
********************************************************************************************************** */
FUNCTION POST_REST_REQUEST(O_error_message       IN    OUT      VARCHAR2,
                           O_response                  OUT      CLOB,
                           I_request_payload     IN             CLOB,
                           I_instance_id         IN             VARCHAR2,
                           I_message_type        IN             VARCHAR2,
                           I_message_family      IN             VARCHAR2)

      RETURN BOOLEAN;

-----------------------------------------------------------------------------------------------------------
END RIS_APEX_SERVICE;
/


CREATE OR REPLACE PACKAGE BODY        RIS_APEX_SERVICE
   IS

   STATUS_YES             CONSTANT       VARCHAR2(2)             := 'Y';
   STATUS_NO              CONSTANT       VARCHAR2(2)             := 'Y';

   --Stylesheet to remove the namespaces
   l_xsl_ns            XMLTYPE         := XMLTYPE('<?xml version="1.0" encoding="utf-8"?>
                                       <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
                                        <xsl:output method="xml" indent="yes"/>

                                        <xsl:template match="*">
                                          <xsl:element name="{local-name(.)}">
                                           <xsl:apply-templates select="@* | node()"/>
                                          </xsl:element>
                                        </xsl:template>
                                        <xsl:template match="@*">
                                          <xsl:attribute name="{local-name(.)}">
                                           <xsl:value-of select="."/>
                                          </xsl:attribute>
                                        </xsl:template>
                                       </xsl:stylesheet>');


   -----------------------------------------------------------------------------------------------------------------------------
   -- Function Name:  CHECK_JSON_IN_RESPONSE
   -- Purpose      :  parse json (Would get deprecated once APEX_JSON gets deprecated)
   -----------------------------------------------------------------------------------------------------------------------------
   FUNCTION CHECK_JSON_IN_RESPONSE(O_error_message   IN OUT NOCOPY VARCHAR2,
                           I_response        IN OUT CLOB)
   RETURN BOOLEAN IS
      --
      L_program_name       VARCHAR2(200)                    := 'RIS_APEX_SERVICE.CHECK_JSON_IN_RESPONSE';
      --
   BEGIN
      --

      IF nvl(dbms_lob.getlength(TRIM(I_response)),0) = 0 THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                      'JSON_RESPONSE_IS_NULL',
                                      L_program_name,
                                      NULL);
         RETURN FALSE;
      END IF;
      --
      IF I_response IS NOT JSON THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                      'RESPONSE_IS_NOT_IN_JSON_FORMAT',
                                      L_program_name,
                                      NULL);
         RETURN FALSE;
      END IF;
      --
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
        O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                    I_response,
                                    L_program_name,
                                    TO_CHAR(SQLCODE));
        RETURN FALSE;

   END CHECK_JSON_IN_RESPONSE;




   /* *********************************************************************************************************
   * Function          : UPDATE_SOAP_RESPONSE_TO_MSGTAB
   * Purpose           :
   * DESC              :
   *
   * Date            Ver    Author                 Description
   * ====            ===    ======                 ===========
   * 16-APR-2018     0.0    Pradeep G              Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION UPDATE_SOAP_RESPONSE_TO_MSGTAB(O_error_message       IN OUT         VARCHAR2,
                                 I_response            IN             CLOB,
                                 I_message_id          IN             NUMBER)
      RETURN BOOLEAN
   IS
      L_program_name          VARCHAR2(200)                     := 'RIS_APEX_SERVICE.POST_SOAP';
      L_mark                  VARCHAR2(200)                     := 'DECLARE';
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      L_mark:= 'UPDATE ris_message_inbound';
      UPDATE ris_message_inbound
         SET service_response = I_response
       WHERE message_id       = I_message_id;
      COMMIT;
      RETURN TRUE;
   EXCEPTION
    WHEN OTHERS
      THEN
      ---
        O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                    SQLERRM ||' at '||L_mark,
                                    L_program_name,
                                    TO_CHAR(SQLCODE));

        RETURN FALSE;
   END UPDATE_SOAP_RESPONSE_TO_MSGTAB;



   /* *********************************************************************************************************
   * Function          : POST_SOAP_REQUEST
   * Purpose           :
   * DESC              :
   *
   * Date            Ver    Author                 Description
   * ====            ===    ======                 ===========
   * 23-Feb-2017     0.0    Pradeep G              Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION POST_SOAP_REQUEST(O_error_message       IN OUT         VARCHAR2,
                        O_response            IN OUT            CLOB,
                        I_message_id          IN             NUMBER,
                        I_instance_id         IN             NUMBER DEFAULT 1)
      RETURN BOOLEAN
   IS
      --
      L_program_name          VARCHAR2(200)                     := 'RIS_APEX_SERVICE.POST_SOAP_REQUEST';
      L_grant_type            VARCHAR2(50)                      := 'client_credentials';
      L_response              CLOB;
      L_token                 CLOB;
      L_mark                  VARCHAR2(250);
      L_url                   VARCHAR2(4000);
      L_user                  ris_sec_config.keystore_name%type;
      L_password              VARCHAR2(1000);
      L_auth_url              ris_sec_config.keystore_path%type;
      L_client_id             ris_sec_config.private_key_alias%type;
      L_client_secret         VARCHAR2(1000);
      L_access_tocken         VARCHAR2(1000);
      L_wallet_path           ris_sec_config.wallet_path%type;
      L_wallet_pwd            VARCHAR2(1000);
      L_https_host            VARCHAR2(1000);
      L_message_type          ris_consumer_config.message_type%TYPE;
      L_message_family        ris_consumer_config.message_family %TYPE;
      L_transaction_type      ris_consumer_config.transaction_type%TYPE;
      L_xml_payload           XMLTYPE;
      L_service_type          ris_consumer_config.service_type%type;
      L_debug_enabled         ris_consumer_config.debug_enabled%type;
      L_start_time            DATE;
      L_transfer_timeout      ris_consumer_config.transfer_timeout%type;
      L_api_key               VARCHAR2(1000);
      L_port_name             ris_sec_config.port_name%TYPE;
      L_http_host             VARCHAR2(1000);
      --
      L_config_id             RISGAP.RIS_SEC_CONFIG.CONFIG_ID%TYPE := NULL;
      --
      L_xml                   XMLTYPE;
      L_envelope              CLOB;
      L_response_wo_ns        XMLTYPE;--to remove namespaces and assign that to this variable
      l_success_msg           VARCHAR2(4000) ;
      L_error_message         VARCHAR2(4000);
      L_action                ris_sec_config.action%type;
      L_wls_uri               ris_sec_config.wls_uri%type;

      CURSOR C_GET_SOAP_HEADER
      IS
         WITH dt AS (SELECT TO_CHAR(SYSTIMESTAMP AT TIME ZONE 'GMT', 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"') create_date,
                            TO_CHAR((SYSTIMESTAMP + interval '4' minute) AT TIME ZONE 'GMT', 'YYYY-MM-DD"T"HH24:MI:SSXFF3"Z"')expire_date
                       FROM DUAL )
         SELECT xmlquery('declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
                          copy $i := $p1 modify (
                            for $j in $i/soapenv:Envelope/soapenv:Header
                            return insert nodes $p2 as last into $j
                          )
                          return $i'
                          passing L_xml_payload as "p1",
                          XMLTYPE('<wsse:Security xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" soapenv = "http://schemas.xmlsoap.org/soap/envelope/" soapenv:mustUnderstand="1">
                                   <wsse:UsernameToken wsu:Id="UsernameToken-D842DA844C19BAA9FA15034420212456">
                                     <wsse:Username>'||L_user||'</wsse:Username>
                                     <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">'||L_password||'</wsse:Password>
                                   </wsse:UsernameToken>
                                   <wsu:Timestamp wsu:Id="TS-9DE03F55554EF5E868151018996669110">
                                     <wsu:Created>'||dt.create_date||'</wsu:Created>
                                     <wsu:Expires>'||dt.expire_date||'</wsu:Expires>
                                   </wsu:Timestamp>
                                 </wsse:Security>') as "p2"
                         returning content
                         ).getClobVal() xml
           FROM dt;

      L_soap_env_header XMLTYPE;

      CURSOR C_get_web_url
      IS SELECT
                rcc.config_id,
                rcc.service_type                                                                AS service_type,
                rcc.debug_enabled                                                               AS debug_enabled,
                --rcc.action                                                                      AS action,
                rim.message_type                                                                AS message_type,
                rim.message_family                                                              AS message_family,
                rim.transaction_type                                                            AS transaction_type,
                rim.xml_payload                                                                 AS xml_payload,
                rcc.transfer_timeout                                                            AS transfer_timeout
           FROM ris_consumer_config rcc,
                ris_message_inbound rim
          WHERE rim.message_type       = rcc.message_type
            AND rim.message_family     = rcc.message_family
            AND rim.instance_id        = rcc.instance_id
            AND rim.message_id         = I_message_id
            AND rim.instance_id        = I_instance_id
            AND nvl(rim.app_id,'NO_APP') = nvl(rcc.app_id,'NO_APP')
            AND nvl(rim.interface_id,'NO_INTF') = nvl(rcc.interface_id,'NO_INTF');
      --
   BEGIN
      ---
      L_mark := 'C_get_web_url Cursor';
      OPEN  C_get_web_url;
      FETCH C_get_web_url INTO
                               L_config_id,
                               L_service_type,
                               L_debug_enabled,
                               --L_action,
                               L_message_type,
                               L_message_family,
                               L_transaction_type,
                               L_xml_payload,
                               L_transfer_timeout;


      IF C_get_web_url%NOTFOUND THEN
         CLOSE C_get_web_url;
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config:instance_id: '||I_instance_id,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;

      CLOSE C_get_web_url;

      IF GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(O_error_message,
                                                    L_config_id,
                                                    L_url,
                                                    L_action,
                                                    L_wls_uri,
                                                    L_user,
                                                    L_password,
                                                    L_client_id,
                                                    L_client_secret,
                                                    L_auth_url,
                                                    L_wallet_path,
                                                    L_wallet_pwd,
                                                    L_http_host,
                                                    L_port_name,
                                                    L_api_key
                                                    ) = FALSE THEN
         RETURN FALSE;
      END IF;

      --
      IF L_debug_enabled = STATUS_YES THEN
         L_start_time := SYSDATE;
      END IF;
      --
      IF L_service_type = RIS_APEX_SERVICE.SOAP_SERVICE_TYPE THEN
         L_mark := 'POST_SOAP';
      IF L_user IS NULL  OR
         L_password IS NULL OR
         L_url IS NULL OR
         L_action IS NULL OR
         L_wallet_path IS NULL OR
         L_wallet_pwd IS NULL THEN
         --
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config for message type: '||L_message_type||' message family: '||L_message_family||' instance_id: '||I_instance_id,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;
         --
       OPEN C_GET_SOAP_HEADER;
      FETCH C_GET_SOAP_HEADER INTO L_envelope;
      CLOSE C_GET_SOAP_HEADER;

         -- Get the XML response from the web service.
         --pr8s9p2 revert commented code to consume the web service

      BEGIN
         L_mark:='Calling APEX_WEB_SERVICE for Request Response';

         L_xml := APEX_WEB_SERVICE.MAKE_REQUEST(p_url          => L_url,
                                                p_action       => L_action,
                                                p_envelope     => L_envelope,
                                                p_wallet_path  => L_wallet_path,
                                                p_wallet_pwd   => L_wallet_pwd,
                                                p_transfer_timeout => L_transfer_timeout);

         L_mark:='Transform XML as CLOB';

         O_response := L_xml.getClobVal();

         -- Display the whole SOAP document returned.
         L_mark:='Store the response back into the table';
         IF UPDATE_SOAP_RESPONSE_TO_MSGTAB(O_error_message,
                                           O_response,
                                           I_message_id) =  FALSE THEN

            RETURN FALSE;
         END IF;

      EXCEPTION
         WHEN OTHERS    THEN
            L_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
            -- For Errors where unable to perse L_xml response
            IF UPDATE_SOAP_RESPONSE_TO_MSGTAB(O_error_message,
                                              L_error_message,
                                              I_message_id) =  FALSE THEN
              RETURN FALSE;
            END IF;

            RETURN FALSE;
      END;
      --

      --remove the namespaces and prefixes to look for success messages.
      --success_message tag can have different prefixes for different message types,
      --hence the need to remove the namespaces and prefixes
      L_response_wo_ns    :=  L_xml.transform(l_xsl_ns);
      --
      --check for the success_message tag value
      l_success_msg       :=  apex_web_service.parse_xml(p_xml => L_response_wo_ns,
                                                         p_xpath => '//success_message/text()');
      --if success message is null then check for error
      IF l_success_msg IS  NULL THEN
         --check for the different error tags faultstring or response
         --if both the above tags are not found then obtain substr if the xml
         O_error_message := COALESCE(APEX_WEB_SERVICE.PARSE_XML(p_xml    =>   L_xml ,
                                                   p_xpath  =>   '//faultstring/text()'
                                                   ),
                              APEX_WEB_SERVICE.PARSE_XML(p_xml    =>   L_xml ,
                                                   p_xpath  =>   '//response/text()'
                                                   ),
                              SUBSTR(L_xml.getStringVal(),3800)
                              );
      END IF;
         --
      IF L_debug_enabled = STATUS_YES THEN
         DBG_SQL.MSG(L_program_name,'SERVICE CALL END: FOR MESSAGE_FAMILY='||L_message_family||', MESSAGE_TYPE='||L_message_type||', TRANSACTION_TYPE='||L_service_type||', ELAPSED TIME IN SEC:'||(SYSDATE-L_start_time)*24*60*60 );
      END IF;
         --
      IF  l_success_msg IS NOT  NULL THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;


      ELSE
          O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                       'INVALID SERVICE_TYPE:'||L_service_type||' FOR MESSAGE_FAMILY='||L_message_family||', MESSAGE_TYPE='||L_message_type||', TRANSACTION_TYPE='||L_service_type,
                                       L_program_name,
                                       TO_CHAR(SQLCODE));

          RETURN FALSE;
      END IF;
      --
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
        ---
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM ||' at '||L_mark,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));

         RETURN FALSE;
   END POST_SOAP_REQUEST;


   /* *********************************************************************************************************
   * Function          : GET_REST_RESPONSE
   * Purpose           :
   * DESC              :
      I_url_param is the parameters to be appended after the url
      --I_parm_name is the parameter names. For Rest calls, it is of format param1:param2:param3..
      --I_parm_value is the parameter name values.For Rest calls, it is of format param_value1:param_value2:param_value3..
      I_http_method is the http_method like GET or POST
      Rest of the parameters are self explanatory
   *
   * Date            Ver    Author                 Description
   * ====            ===    ======                 ===========
   * 01-Feb-2017     0.0    Pradeep G              Initial Version
   *
   ***********************************************************************************************************/
   FUNCTION GET_REST_RESPONSE(O_error_message       IN OUT         VARCHAR2,
                              O_response            OUT            CLOB,
                              I_url_param           IN             VARCHAR2,
                              I_http_method         IN             VARCHAR2,
                              I_instance_id         IN             VARCHAR2,
                              I_message_type        IN             VARCHAR2,
                              I_message_family      IN             VARCHAR2,
                              I_service_url         IN             VARCHAR2 DEFAULT NULL)
   RETURN BOOLEAN IS
      --
      L_program_name          VARCHAR2(200)                     := 'RIS_APEX_SERVICE.GET_REST_RESPONSE';
      L_grant_type            VARCHAR2(50)                      := 'client_credentials';
      L_response              CLOB;
      L_token                 CLOB;
      L_mark                  VARCHAR2(250);
      L_url                   VARCHAR2(4000);
      L_config_url            VARCHAR2(4000);
      L_user                  ris_sec_config.keystore_name%type;
      L_password              VARCHAR2(1000);
      L_auth_url              ris_sec_config.keystore_path%type;
      L_client_id             ris_sec_config.private_key_alias%type;
      L_client_secret         VARCHAR2(1000);
      L_access_tocken         VARCHAR2(1000);
      L_wallet_path           ris_sec_config.wallet_path%type;
      L_wallet_pwd            VARCHAR2(1000);
      L_https_host            VARCHAR2(1000);
      L_service_type          ris_consumer_config.service_type%type;
      L_debug_enabled         ris_consumer_config.debug_enabled%type;
      L_start_time            DATE;
      L_x_api_key             VARCHAR2(1000);
      L_action                ris_sec_config.action%type;
      L_wls_uri               ris_sec_config.wls_uri%type;
      L_wls_uri_debug_ind     ris_consumer_config.wls_uri_debug_ind%type;
      L_wls_timeout           ris_consumer_config.timeout%type;
      L_service_retry_delay   ris_consumer_config.service_retry_delay%type :=1;
      L_max_attempts          ris_consumer_config.max_attempts%type        :=1;
      L_error_message         VARCHAR2(1000);
      L_port_name             VARCHAR2(1000);
      L_fail_ind              VARCHAR2(1)                                  := 'N';
      L_error_exists          VARCHAR2(1)                                  := 'N';
      L_config_id             RISGAP.RIS_SEC_CONFIG.CONFIG_ID%TYPE         := NULL;

      CURSOR C_get_web_url IS
         SELECT
               rcc.config_id        AS config_id,
               rcc.service_type     AS service_type,
               rcc.debug_enabled    AS debug_enabled,
               --wls_uri              AS wls_uri,
               wls_uri_debug_ind    AS wls_uri_debug_ind,
               timeout              AS wls_timeout,
               service_retry_delay  AS service_retry_delay,
               max_attempts         AS max_attempts
          FROM ris_consumer_config rcc
         WHERE rcc.message_type     = I_message_type
           AND rcc.message_family   = I_message_family
           AND rcc.instance_id      = I_instance_id;

      CURSOR C_GET_REVERSE_PROXY IS
         SELECT cd_val_txt search_string,
                attribute1 replacement_string
           FROM intf_cnfg_parm_t intf
          WHERE intf.pgm_nm  =   'REVERSE_PROXY'
            AND intf.cd_nm   =   I_message_family
            AND cnfg_typ_cd  =  'Y';

      L_reverse_proxy_rec C_GET_REVERSE_PROXY%ROWTYPE;

      CURSOR C_CHECK_ERROR_TO_BE_RETRIED(I_response CLOB) IS
         SELECT 'Y'
           FROM intf_cnfg_parm_t intf
          WHERE intf.pgm_nm  =   'RETRY_SERVICE_ERROR'
            AND intf.cd_nm   =   'REST'
            AND cnfg_typ_cd  =   'Y'
            AND lower(I_response)   like '%'||lower(cd_val_txt)||'%';

   BEGIN
      --
      L_mark := 'C_get_web_url Cursor';
      --
      OPEN  C_get_web_url;
      FETCH C_get_web_url INTO L_config_id,
                               L_service_type,
                               L_debug_enabled,
                               --L_wls_uri,
                               L_wls_uri_debug_ind,
                               L_wls_timeout,
                               L_service_retry_delay,
                               L_max_attempts
                               ;
      --
      IF C_get_web_url%NOTFOUND THEN
         CLOSE C_get_web_url;
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config for message type: '||I_message_type||' message family: '||I_message_family||' instance_id: '||I_instance_id,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;

      CLOSE C_get_web_url;
      --
      L_mark := 'Get security details from config';
      --
      IF GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(L_error_message,
                                                    L_config_id,
                                                    L_config_url,
                                                    L_action,
                                                    L_wls_uri,
                                                    L_user,
                                                    L_password,
                                                    L_client_id,
                                                    L_client_secret,
                                                    L_auth_url,
                                                    L_wallet_path,
                                                    L_wallet_pwd,
                                                    L_https_host,
                                                    L_port_name,
                                                    L_x_api_key
                                                    ) = FALSE THEN
         RETURN FALSE;
      END IF;
      --
      L_mark := 'Set URL based on input parameter and URL from sec config';
      --
      IF I_service_url IS NULL THEN
         L_url := L_config_url||I_url_param;
      ELSE
         L_url := I_service_url;
      END IF;
      --
      IF L_debug_enabled = STATUS_YES THEN
          L_start_time := SYSDATE;
      END IF;
      --
      IF L_service_type = REST_SERVICE_TYPE THEN
         --
         FOR j IN 1 .. L_max_attempts -- Record Lock Loop
         LOOP
            --
            L_error_exists := 'N';
            L_fail_ind     := 'N';
            --
            BEGIN
               --
               IF L_auth_url IS NULL THEN
                  --
                  IF L_wls_uri IS NOT NULL THEN
                     --
                     L_mark := 'URI Patch to call OCI Patch';
                     --
                     apex_web_service.g_request_headers(1).name := 'uri';
                     apex_web_service.g_request_headers(1).value := L_url;
                     --
                     IF L_x_api_key IS NOT NULL THEN
                        apex_web_service.g_request_headers(2).name := 'apigee_api_key'; --need to check whether it needs to be x-api-key or x-apikey
                        apex_web_service.g_request_headers(2).value := L_x_api_key; --need to pass the consumer key here
                     END IF;
                     --
                     apex_web_service.g_request_headers(3).name := 'connect_time_out';
                     apex_web_service.g_request_headers(3).value := L_wls_timeout;

                     apex_web_service.g_request_headers(4).name := 'read_time_out';
                     apex_web_service.g_request_headers(4).value := L_wls_timeout;

                     apex_web_service.g_request_headers(5).name := 'debug_mode';
                     apex_web_service.g_request_headers(5).value := L_wls_uri_debug_ind;

                     O_response := apex_web_service.make_rest_request(p_url         => L_wls_uri,
                                                                      p_http_method => I_http_method,
                                                                      p_wallet_path => L_wallet_path,
                                                                      p_wallet_pwd  => L_wallet_pwd);
                  ELSE
                     --
                     L_mark := 'Basic Authentication';
                     --
                     apex_web_service.g_request_headers(1).name := 'Accept';
                     apex_web_service.g_request_headers(1).value := 'application/json';

                     apex_web_service.g_request_headers(2).name  := 'Accept-Version';
                     apex_web_service.g_request_headers(2).value := '16.0';

                     apex_web_service.g_request_headers (3).name := 'Accept-Language';
                     apex_web_service.g_request_headers(3).value := 'en';
                     --
                     IF L_x_api_key IS NOT NULL THEN
                        apex_web_service.g_request_headers(4).name := 'ApiKey'; --need to check whether it needs to be x-api-key or x-apikey
                        apex_web_service.g_request_headers(4).value := L_x_api_key; --need to pass the consumer key here
                     END IF;
                     --
                     O_response := apex_web_service.make_rest_request(p_url    => L_url,
                                                                      p_http_method => I_http_method,
                                                                      P_username    => L_user,
                                                                      P_password    => L_password,
                                                                      p_wallet_path => L_wallet_path,
                                                                      p_wallet_pwd  => L_wallet_pwd,
                                                                      p_https_host  => L_https_host);

                  END IF;
                  --
               ELSE
                  --
                  L_mark := 'Oauth Toekn Retrieval';
                  -- Set headers
                  apex_web_service.g_request_headers(1).name  := 'Content-Type';
                  apex_web_service.g_request_headers(1).value := 'application/x-www-form-urlencoded';
                  -- Get tocken
                  L_token := apex_web_service.make_rest_request(p_url          => L_auth_url,
                                                                p_http_method  => I_http_method,
                                                                p_username     => L_client_id,
                                                                p_password     => L_client_secret,
                                                                p_parm_name    => apex_util.string_to_table('grant_type'),
                                                                p_parm_value   => apex_util.string_to_table(L_grant_type),
                                                                p_wallet_path  => L_wallet_path,
                                                                p_wallet_pwd   => L_wallet_pwd,
                                                                p_https_host   => L_https_host);

                  -- APEX_JSON.parse(L_token);
                  IF RIS_APEX_SERVICE.CHECK_JSON_IN_RESPONSE(O_error_message,
                                                             L_token) = FALSE THEN
                     RETURN FALSE;
                  END IF;
                  --L_access_tocken := apex_json.get_varchar2 (p_path => 'access_token');
                  L_access_tocken := JSON_VALUE(L_token,'$.access_token');
                  L_mark := 'Oauth Authentication';
                  apex_web_service.g_request_headers(1).name  := 'Authorization';
                  apex_web_service.g_request_headers(1).value := 'Bearer ' || L_access_tocken;

                  O_response := apex_web_service.make_rest_request(p_url         => l_url,
                                                                   p_http_method => I_http_method,
                                                                   p_wallet_path => L_wallet_path,
                                                                   p_wallet_pwd  => L_wallet_pwd);

               END IF;--IF L_auth_url IS NULL THEN
               --
            EXCEPTION
            WHEN OTHERS
            THEN
               --
               L_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
               O_response := L_error_message;
               --
               L_fail_ind := 'Y';
               --
               L_mark := 'CALL C_CHECK_ERROR_TO_BE_RETRIED';
               --
               OPEN C_CHECK_ERROR_TO_BE_RETRIED(O_response);
               FETCH C_CHECK_ERROR_TO_BE_RETRIED INTO L_error_exists;
               CLOSE C_CHECK_ERROR_TO_BE_RETRIED;
               --
            END;
            --
            L_mark := 'Check whether retriable error exists';
            --
            IF L_error_exists = 'Y'
            THEN
               --
               L_mark := 'CALL SMT_UTIL.SLEEP';
               --
               SMT_UTIL.SLEEP (L_service_retry_delay);
               --
            ELSE
               --
               EXIT; -- Exit from error retry loop for successfully retried and non retriable errors
               --
            END IF; -- Record Locked
            --
         END LOOP;
         --
      END IF;
      --
      IF L_debug_enabled = STATUS_YES THEN
         DBG_SQL.MSG(L_program_name,'SERVICE CALL END: FOR MESSAGE_FAMILY='||I_message_family||', MESSAGE_TYPE='||I_message_type||', TRANSACTION_TYPE='||L_service_type||', ELAPSED TIME IN SEC:'||(SYSDATE-L_start_time)*24*60*60 );
      END IF;
      --
      IF L_fail_ind = 'Y'
      THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               L_error_message,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      ELSE
         RETURN TRUE;
      END IF;
      --
   EXCEPTION
   WHEN OTHERS
   THEN
      ---
      L_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            L_error_message,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));

      RETURN FALSE;
   END GET_REST_RESPONSE;

   /* ******************************************************************************************************
   * Function          : PUBLISH_RIB4EXT
   * Purpose           : Function is used to publish the message to RIB4EXT
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Output Parameters : o_error_message - error message
   *
   * Date          Ver    Author                 Description
   * ====          ===    ======                 ===========
   * 24-FEB-2018   1.0    INFOSYS Rajeev Naik    Initial Version
   * 06-FEB-2018   1.1    Pradeep G, Infosys     Made code changes for incorporating routing xml logic
   *
   ********************************************************************************************************** */
   FUNCTION PUBLISH_RIB4EXT(O_error_message IN OUT VARCHAR2,
                            I_Message_Id    IN     NUMBER)
   RETURN BOOLEAN
   IS
      --Variable declaration
      L_Create_date        VARCHAR2(100);
      L_Expire_date        VARCHAR2(100);
      L_family             VARCHAR2(100);
      L_type               VARCHAR2(100);
      L_business_obj_id    VARCHAR2(100);
      L_envelope           CLOB;
      L_response_clob      CLOB;
      L_xml                XMLTYPE;
      L_routing_input_xml  XMLTYPE;
      L_routing_xml        XMLTYPE;
      L_root_element       VARCHAR2(200);
      L_routing_txt        CLOB;
      L_instance_id        NUMBER(2);
      L_url                VARCHAR2(200);
      L_user_name          VARCHAR2(100);
      L_password           VARCHAR2(200);
      L_wallet_path        VARCHAR2(500);
      L_wallet_password    VARCHAR2(500);
      LP_program           VARCHAR2(100)  :='RIS_APEX_SERVICE.PUBLISH_RIB4EXT';
      --L_action             VARCHAR2(250)  :='http://www.oracle.com/retail/rib/integration/services/ApplicationMessagePublishingService/v1/ApplicationMessagePublishingPortType/publishMessagesRequest';
      L_mark               VARCHAR2(500);
      L_message            CLOB;
      L_result             VARCHAR2(32767);
      L_intf_id            VARCHAR2(200);
      L_error_message      VARCHAR2(4000);
      L_transfer_timeout   ris_consumer_config.transfer_timeout%TYPE;

      L_auth_url              ris_sec_config.keystore_path%type;
      L_client_id             ris_sec_config.private_key_alias%type;
      L_client_secret         VARCHAR2(1000);
      L_http_host            VARCHAR2(1000);
      L_port_name             VARCHAR2(1000);
      L_x_api_key             VARCHAR2(1000);
      L_action                ris_sec_config.action%type;
      L_wls_uri               ris_sec_config.wls_uri%type;

      L_config_id          RISGAP.RIS_SEC_CONFIG.CONFIG_ID%TYPE := NULL;
      L_xslt_add_ns        XMLTYPE :=   XMLTYPE('<xsl:stylesheet
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:v11="http://www.oracle.com/retail/integration/rib/ApplicationMessages/v11"
  version="1.0">

<xsl:template match="@* | text() | comment() | processing-instruction()">
  <xsl:copy/>
</xsl:template>


<xsl:template match="*">
  <xsl:element name="v11:{local-name()}">
    <xsl:apply-templates select="@* | node()"/>
  </xsl:element>
</xsl:template>

<xsl:template match="Body">
  <xsl:apply-templates/>
</xsl:template>

</xsl:stylesheet>');

   L_xslt_add_ns_to_child        XMLTYPE :=   XMLTYPE('<xsl:stylesheet version="1.0"
 xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
 xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
 xmlns:v1="http://www.oracle.com/retail/rib/integration/services/ApplicationMessagePublishingService/v1"
 xmlns:v11="http://www.oracle.com/retail/integration/rib/ApplicationMessages/v1"
 xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
 xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
 <xsl:output method="xml" cdata-section-elements="v11:payloadXml"/>
<xsl:template match="*">
    <xsl:choose>
        <xsl:when test="ancestor-or-self::ApplicationMessageRoutingInfo">
            <xsl:element name="v11:{local-name()}">
                <xsl:apply-templates select="node()|@*"/>
            </xsl:element>
        </xsl:when>
        <xsl:otherwise>
            <xsl:copy>
                <xsl:apply-templates select="node()|@*"/>
            </xsl:copy>
        </xsl:otherwise>
    </xsl:choose>
</xsl:template>
<xsl:template match="@*" priority="1">  <!-- see below -->
  <xsl:copy>
    <xsl:apply-templates select="@*" />
  </xsl:copy>
</xsl:template>


</xsl:stylesheet>');
      --
      CURSOR C_Get_message_details
      IS
         SELECT rmi.message_family,
                rmi.message_type,
                rmi.business_object_id,
                rmi.xml_payload,
                rmi.instance_id,
                rmi.interface_id,
                rcc.config_id,
                rcc.transfer_timeout,
                --rcc.action,
                rmi.routing_xml_payload
           FROM ris_message_inbound rmi,
                ris_consumer_config rcc
          WHERE message_id                      = I_Message_Id
            AND rcc.message_family              = rmi.message_family
            AND rcc.message_type                = rmi.message_type
            AND rmi.instance_id                 = rcc.instance_id
            AND nvl(rmi.app_id,'NO_APP')        = nvl(rcc.app_id,'NO_APP')
            AND nvl(rmi.interface_id,'NO_INTF') = nvl(rcc.interface_id,'NO_INTF');

      CURSOR C_get_time
      IS
         SELECT TO_CHAR(SYSTIMESTAMP AT TIME ZONE 'GMT', 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"') create_date,
                TO_CHAR((SYSTIMESTAMP + interval '5' minute) AT TIME ZONE 'GMT', 'YYYY-MM-DD"T"HH24:MI:SSXFF3"Z"')expire_date
           FROM DUAL;

   BEGIN
      --
      L_MARK := 'CURSOR : C_Get_message_details';
      --
       OPEN C_Get_message_details;
      FETCH C_Get_message_details INTO L_family,
                                       L_type,
                                       L_business_obj_id,
                                       L_xml,
                                       L_instance_id,
                                       L_intf_id,
                                       L_config_id,
                                       L_transfer_timeout,
                                       --L_action,
                                       L_routing_input_xml;
      CLOSE C_Get_message_details;
      --
      IF L_business_obj_id IS NULL
      THEN
         O_error_message:='Business_Object_ID is null for the message_id-'||I_Message_Id;
         RETURN FALSE;
      END IF;

      IF L_xml IS NULL
      THEN
         O_error_message:='XML_PAYLOAD is null for the message_id-'||I_Message_Id;
         RETURN FALSE;
      END IF;
      L_mark:='Transforming XMLTYPE to Clob type';
      --
      L_message :=L_xml.getClobVal();
      --
      L_mark:='Envoleping Clob data into CDATA';
      --
      L_message:='<![CDATA['||L_message||']]>';

      L_mark :='Calling the function to get the credentials.';

      IF NOT GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(O_error_message,
                                                        L_config_id,
                                                        L_url,
                                                        L_action,
                                                        L_wls_uri,
                                                        L_user_name,
                                                        L_password,
                                                        L_client_id,
                                                        L_client_secret,
                                                        L_auth_url,
                                                        L_wallet_path,
                                                        L_wallet_password,
                                                        L_http_host,
                                                        L_port_name,
                                                        L_x_api_key) THEN
         RETURN FALSE;
      END IF;

      IF L_url IS NULL
      THEN
         O_error_message:='URL is not configured for the family -'||L_family ||' and for message_type -'||L_type;
         RETURN FALSE;
      END IF;

      IF L_action IS NULL
      THEN
         O_error_message:='SOAP Action is not configured for the family -'||L_family ||' and for message_type -'||L_type;
         RETURN FALSE;
      END IF;

      IF L_user_name IS NULL
      THEN
         O_error_message:='User_name is not configured for the family -'||L_family ||' and for message_type -'||L_type;
         RETURN FALSE;
      END IF;

      IF L_wallet_path IS NULL
      THEN
         O_error_message:='Wallet_path is not configured for the family -'||L_family ||' and for message_type -'||L_type;
         RETURN FALSE;
      END IF;

      --
      L_mark:='Cursor : C_get_time';
      --
      OPEN C_get_time;
      FETCH C_get_time INTO L_Create_date,L_Expire_date;
      CLOSE C_get_time;

      --
       L_mark:='call L_routing_input_xml.getClobVal()';
       IF L_routing_input_xml IS NOT NULL THEN
            L_root_element := L_routing_input_xml.getRootElement();
            IF NVL(L_root_element,'NA') <> 'ApplicationMessageRoutingInfo' THEN
                L_routing_txt:= L_routing_input_xml.EXTRACT('/*/ApplicationMessageRoutingInfo').getClobVal();
            ELSE
                L_routing_txt := L_routing_input_xml.getClobVal();
            END IF;


       END IF;
      --
      L_mark:='Forming Final message for RIB4EXT';
      --
      L_envelope := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v1="http://www.oracle.com/retail/rib/integration/services/ApplicationMessagePublishingService/v1" xmlns:v11="http://www.oracle.com/retail/integration/rib/ApplicationMessages/v1">
                  <soapenv:Header><wsse:Security soapenv:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"><wsse:UsernameToken wsu:Id="UsernameToken-D842DA844C19BAA9FA15034420212657"><wsse:Username>'||L_user_name||'</wsse:Username><wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">'||L_password||'</wsse:Password></wsse:UsernameToken><wsu:Timestamp wsu:Id="TS-9DE03F55554EF5E868151018996669110"><wsu:Created>'||L_create_date||'</wsu:Created><wsu:Expires>'||L_expire_date||'</wsu:Expires></wsu:Timestamp></wsse:Security></soapenv:Header>
                  <soapenv:Body>
                  <v1:publishMessages>
                  <v11:ApplicationMessages>
                  <v11:ApplicationMessage>
                  <v11:family>'||L_family||'</v11:family>
                  <v11:type>'||L_type||'</v11:type>
                  <v11:businessObjectId>'||L_business_obj_id||'</v11:businessObjectId>'||L_routing_txt||
                  '<v11:payloadXml>'||L_message||'</v11:payloadXml>
                  </v11:ApplicationMessage>
                  </v11:ApplicationMessages>
                  </v1:publishMessages>
                  </soapenv:Body>
                  </soapenv:Envelope>';
      --
       L_mark:='call XMLTYPE(L_envelope).transform()';
       IF L_routing_input_xml IS NOT NULL THEN
           L_envelope := XMLTYPE(L_envelope).transform(L_xslt_add_ns_to_child).getClobVal();
       END IF;
      --
      L_mark:='Calling the RIB4EXT';
      --
      BEGIN
         L_mark:='Calling APEX_WEB_SERVICE for RIB4EXT';

         L_xml := APEX_WEB_SERVICE.MAKE_REQUEST(p_url              => L_url,
                                                p_action           => L_action,
                                                p_envelope         => L_envelope,
                                                p_wallet_path      => L_wallet_path,
                                                p_wallet_pwd       => L_wallet_password,
                                                p_transfer_timeout => L_transfer_timeout);

         L_mark:='Transform XML as CLOB';

         L_response_clob := L_xml.getClobVal();

         L_mark:='Store the response back into the table';

         IF UPDATE_SOAP_RESPONSE_TO_MSGTAB(O_error_message,
                                           L_response_clob,
                                           I_message_id) =  FALSE THEN

            RETURN FALSE;
         END IF;

      EXCEPTION
         WHEN OTHERS THEN
           L_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || LP_program;
           -- For Errors where unable to perse L_xml response
           IF UPDATE_SOAP_RESPONSE_TO_MSGTAB(O_error_message,
                                    L_error_message,
                                    I_message_id) =  FALSE THEN

             RETURN FALSE;
           END IF;

           RETURN FALSE;
      END;
      --
      L_mark:='Reading the response';
      --
      O_error_message := APEX_WEB_SERVICE.PARSE_XML(p_xml   => L_xml,
                                   p_xpath => '//return/text()',
                                   p_ns    => 'xmlns:ns0="http://www.oracle.com/retail/rib/integration/services/ApplicationMessagePublishingService/v1');
      --
      --If return text is not present in response then reading the Error message
      IF O_error_message is NULL THEN
         O_error_message := APEX_WEB_SERVICE.PARSE_XML(L_xml,
                                          '//ns0:shortErrorMessage/text()',
                                          'xmlns:ns0="http://www.oracle.com/retail/integration/services/exception/v1"');
         IF O_error_message IS NULL
         THEN
         O_error_message:=SUBSTR(L_xml.getStringVal(),1,500);
         END IF;

         RETURN FALSE;

      END IF;

      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS
       THEN
          O_error_message :=
            SQL_LIB.CREATE_MSG ('PACKAGE_ERROR',
                           'ERROR: Unexpected Error'|| SQLERRM||'-'|| L_mark,
                            LP_program,
                            TO_CHAR (SQLCODE));
         RETURN FALSE;
   END PUBLISH_RIB4EXT;

   /* ******************************************************************************************************
   * Function          : POST_REST_REQUEST
   * Purpose           : Function is used to post the REST request to RMS
   *
   * Return Parameter  : TRUE for Success and FALSE for Failure
   * Output Parameters : o_error_message - error message
   *
   * Date          Ver    Author                 Description
   * ====          ===    ======                 ===========
   * 20-Jun-2018   1.0    INFOSYS Rajeev Naik    Initial Version
   *
   ********************************************************************************************************** */
   FUNCTION POST_REST_REQUEST(O_error_message          IN OUT         VARCHAR2,
                        O_response               OUT            CLOB,
                        I_message_id             IN             NUMBER)
      RETURN BOOLEAN
   IS
      --VARIABLE DECLARATIONS
      L_program_name          VARCHAR2(200)                     := 'RIS_APEX_SERVICE.POST_REST_REQUEST';
      L_response              CLOB;
      L_token                 CLOB;
      L_mark                  VARCHAR2(250);
      L_url                   VARCHAR2(4000);
      L_user                  ris_sec_config.keystore_name%type;
      L_password              VARCHAR2(1000);
      L_auth_url              ris_sec_config.keystore_path%type;
      L_client_id             ris_sec_config.private_key_alias%type;
      L_client_secret         VARCHAR2(1000);
      L_access_tocken         VARCHAR2(1000);
      L_wallet_path           ris_sec_config.wallet_path%type;
      L_wallet_pwd            VARCHAR2(1000);
      L_https_host            VARCHAR2(1000);
      L_service_type          ris_consumer_config.service_type%type;
      L_debug_enabled         ris_consumer_config.debug_enabled%type;
      L_start_time            DATE;
      L_message_body          CLOB;
      L_message_family        VARCHAR2(50);
      L_message_type          VARCHAR2(50);
      L_instance_id           NUMBER(10);
      L_port_name             VARCHAR2(1000);
      L_x_api_key             VARCHAR2(1000);
      L_config_id             RISGAP.RIS_SEC_CONFIG.CONFIG_ID%TYPE := NULL;
      L_action                ris_sec_config.action%type;
      L_wls_uri               ris_sec_config.wls_uri%type;
      --
      CURSOR C_get_web_url
      IS
       SELECT
              cnfg.config_id,
              cnfg.service_type                                                  AS service_type,
              cnfg.debug_enabled                                                 AS debug_enabled,
              stg.raw_payload                                                    AS message_body,
              stg.message_family                                                 AS message_family,
              stg.message_type                                                   AS message_type,
              stg.instance_id                                                    AS instance_id
         FROM ris_consumer_config cnfg,
              ris_message_inbound stg
        WHERE cnfg.message_type     = stg.message_type
          AND cnfg.message_family   = stg.message_family
          AND cnfg.instance_id      = stg.instance_id
          AND stg.message_id        = I_message_id;

   BEGIN
      ---

      L_mark := 'C_get_web_url Cursor';
      OPEN  C_get_web_url;
      FETCH C_get_web_url INTO L_config_id,
                               L_service_type,
                               L_debug_enabled,
                               L_message_body,
                               L_message_family,
                               L_message_type,
                               L_instance_id;
        --
      IF C_get_web_url%NOTFOUND
      THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config for message type: '||L_message_type||' message family: '||L_message_family||' instance_id: '||L_instance_id,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;

      CLOSE C_get_web_url;
      --
      L_mark :='Calling the function to get the credentials.';

      IF NOT GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(O_error_message,
                                                        L_config_id,
                                                        L_url,
                                                        L_action,
                                                        L_wls_uri,
                                                        L_user,
                                                        L_password,
                                                        L_client_id,
                                                        L_client_secret,
                                                        L_auth_url,
                                                        L_wallet_path,
                                                        L_wallet_pwd,
                                                        L_https_host,
                                                        L_port_name,
                                                        L_x_api_key) THEN
         RETURN FALSE;
      END IF;
      --
      IF L_debug_enabled = STATUS_YES THEN
         L_start_time := SYSDATE;
      END IF;
      --
      IF L_service_type = REST_SERVICE_TYPE THEN
          ---
         L_mark := 'Basic Authentication';
         apex_web_service.g_request_headers(1).name := 'Accept';
         apex_web_service.g_request_headers(1).value := 'application/json';

         apex_web_service.g_request_headers(2).name  := 'Accept-Version';
         apex_web_service.g_request_headers(2).value := '16.0';

         apex_web_service.g_request_headers (3).name := 'Accept-Language';
         apex_web_service.g_request_headers(3).value := 'en';

         apex_web_service.g_request_headers(4).name := 'Content-Type';
         apex_web_service.g_request_headers(4).value := 'application/json';

         O_response := apex_web_service.make_rest_request(p_url         => L_url,
                                                          p_http_method => 'POST',
                                                          p_wallet_path => L_wallet_path,
                                                          p_wallet_pwd  => L_wallet_pwd,
                                                          P_username    => L_user,
                                                          P_password    => L_password,
                                                          p_body        => L_message_body);

      END IF;
        --
      L_mark :='Updating the response back ris_message_inbound table';
        --
      IF UPDATE_SOAP_RESPONSE_TO_MSGTAB(O_error_message,
                                        O_response,
                                        I_message_id) =  FALSE THEN

         RETURN FALSE;
      END IF;

      IF L_debug_enabled = STATUS_YES THEN
         DBG_SQL.MSG(L_program_name,'SERVICE CALL END: FOR MESSAGE_FAMILY='||L_message_family||', MESSAGE_TYPE='||L_message_type||', TRANSACTION_TYPE='||L_service_type||', ELAPSED TIME IN SEC:'||(SYSDATE-L_start_time)*24*60*60 );
      END IF;
        --

      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM || '@' || L_mark,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;

   END POST_REST_REQUEST;

   /* ******************************************************************************************************
   * Function          : POST_REST_REQUEST
   * Purpose           : Function is used to post the REST request to systems other than RMS,
   *                     it bypasses RIS layer and directly call to rest services.
   *                     Currently support OAUTH 2 authentication mode.
   *
   *
   * Date          Ver    Author                 Description
   * ====          ===    ======                 ===========
   * 23-Jul-2019   1.0    INFOSYS                Initial Version
   *
   ********************************************************************************************************** */
   FUNCTION POST_REST_REQUEST(O_error_message       IN    OUT      VARCHAR2,
                              O_response                  OUT      CLOB,
                              I_request_payload     IN             CLOB,
                              I_instance_id         IN             VARCHAR2,
                              I_message_type        IN             VARCHAR2,
                              I_message_family      IN             VARCHAR2)
      RETURN BOOLEAN
   IS
      --VARIABLE DECLARATIONS
      L_program_name          VARCHAR2(200)                     := 'RIS_APEX_SERVICE.POST_REST_REQUEST';
      L_response              CLOB;
      L_token                 CLOB;
      L_mark                  VARCHAR2(250);
      L_url                   VARCHAR2(4000);
      L_user                  ris_sec_config.keystore_name%type;
      L_password              VARCHAR2(1000);
      L_auth_url              ris_sec_config.keystore_path%type;
      L_client_id             ris_sec_config.private_key_alias%type;
      L_client_secret         VARCHAR2(1000);
      L_access_tocken         VARCHAR2(1000);
      L_wallet_path           ris_sec_config.wallet_path%type;
      L_wallet_pwd            VARCHAR2(1000);
      L_https_host            VARCHAR2(1000);
      L_service_type          ris_consumer_config.service_type%type;
      L_debug_enabled         ris_consumer_config.debug_enabled%type;
      L_start_time            DATE;
      L_message_body          CLOB;
      L_message_family        VARCHAR2(50);
      L_message_type          VARCHAR2(50);
      L_instance_id           NUMBER(10);
      L_port_name             VARCHAR2(1000);
      L_x_api_key             VARCHAR2(1000);
      L_config_id             RISGAP.RIS_SEC_CONFIG.CONFIG_ID%TYPE := NULL;
      L_action                ris_sec_config.action%type;
      L_wls_uri               ris_sec_config.wls_uri%type;
      L_fail_ind              VARCHAR2(1)                                  := 'N';
      L_error_exists          VARCHAR2(1)                                  := 'N';
      L_service_retry_delay   ris_consumer_config.service_retry_delay%type :=1;
      L_max_attempts          ris_consumer_config.max_attempts%type        :=1;
      L_expires_in            date                                         := NULL;
      --
      CURSOR C_get_web_url
      IS
         SELECT  cnfg.config_id,
                 cnfg.service_type    AS service_type,
                 cnfg.debug_enabled   AS debug_enabled,
                 service_retry_delay  AS service_retry_delay,
                 max_attempts         AS max_attempts
           FROM ris_consumer_config cnfg
          WHERE cnfg.message_type     = I_message_type
            AND cnfg.message_family   = I_message_family
            AND cnfg.instance_id      = I_instance_id;

      CURSOR C_CHECK_ERROR_TO_BE_RETRIED(I_response CLOB) IS
         SELECT 'Y'
           FROM intf_cnfg_parm_t intf
          WHERE intf.pgm_nm  =   'RETRY_SERVICE_ERROR'
            AND intf.cd_nm   =   'REST'
            AND cnfg_typ_cd  =   'Y'
            AND lower(I_response)   like '%'||lower(cd_val_txt)||'%';

   BEGIN
      ---
      L_mark := 'Check mandatory inputs';
      IF I_message_family  IS NULL OR
         I_message_type    IS NULL OR
         I_instance_id     IS NULL OR
         I_request_payload IS NULL
       THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                                 'Missing mandatory inputs - ' || L_mark,
                                                 L_program_name,
                                                 TO_CHAR(SQLCODE));
      END IF;


      L_mark := 'Open cursor C_get_web_url 2';
      OPEN  C_get_web_url;
      FETCH C_get_web_url INTO L_config_id,
                               L_service_type,
                               L_debug_enabled,
                               L_service_retry_delay,
                               L_max_attempts;

      L_message_family  := I_message_family;
      L_message_type    := I_message_type;
      L_instance_id     := I_instance_id;

      IF L_debug_enabled = STATUS_YES THEN
         DBG_SQL.MSG(L_program_name,'config_id :'|| L_config_id);
      END IF;
        --
      IF C_get_web_url%NOTFOUND
      THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               'Missing configuration in ris_consumer_config for message type: '||L_message_type||' message family: '||L_message_family||' instance_id: '||L_instance_id,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;
      END IF;

      CLOSE C_get_web_url;
      --
      L_mark :='Calling function gap_get_service_sql to get the credentials.';

      IF NOT GAP_GET_SERVICE_SQL.GAP_GET_SERVICE_CONFIG(O_error_message,
                                                        L_config_id,
                                                        L_url,
                                                        L_action,
                                                        L_wls_uri,
                                                        L_user,
                                                        L_password,
                                                        L_client_id,
                                                        L_client_secret,
                                                        L_auth_url,
                                                        L_wallet_path,
                                                        L_wallet_pwd,
                                                        L_https_host,
                                                        L_port_name,
                                                        L_x_api_key) THEN
         RETURN FALSE;
      END IF;
      --
      IF L_debug_enabled = STATUS_YES THEN
         L_start_time := SYSDATE;
      END IF;
      --

      IF L_service_type = REST_SERVICE_TYPE THEN

         FOR j IN 1 .. L_max_attempts -- Record Lock Loop
         LOOP
            --
            L_error_exists := 'N';
            L_fail_ind     := 'N';
            --
            BEGIN
               ---
               IF L_debug_enabled = STATUS_YES THEN
                  DBG_SQL.MSG(L_program_name,'OAUTH_GET_LAST_TOKEN :'|| APEX_WEB_SERVICE.OAUTH_GET_LAST_TOKEN);
               END IF;

               IF APEX_WEB_SERVICE.OAUTH_GET_LAST_TOKEN is null
               THEN

                  APEX_WEB_SERVICE.g_request_headers.delete();

                  APEX_WEB_SERVICE.OAUTH_AUTHENTICATE(p_token_url     => L_auth_url,
                                                      p_client_id     => L_client_id,
                                                      p_client_secret => L_client_secret,
                                                      p_wallet_path   => L_wallet_path,
                                                      p_wallet_pwd    => L_wallet_pwd);
                  --
                  L_mark := 'USE_NEW_TOKEN';
                  --
                  --L_expires_in := APEX_WEB_SERVICE.g_oauth_token.expires;
                  L_token      := APEX_WEB_SERVICE.g_oauth_token.token;

                  IF L_debug_enabled = STATUS_YES THEN
                     DBG_SQL.MSG(L_program_name,'OAUTH_GET_LAST_TOKEN :'|| L_token);
                     DBG_SQL.MSG(L_program_name,'OAUTH_GET_LAST_TOKEN :'|| L_expires_in);
                  END IF;

                  APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).name  := 'Authorization';
                  APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).value := 'Bearer '||L_token;
                  --
                  APEX_WEB_SERVICE.g_request_headers(2).name := 'Content-Type';
                  APEX_WEB_SERVICE.g_request_headers(2).value := 'application/json';

               END IF;
               --

               O_response := APEX_WEB_SERVICE.make_rest_request(p_url         => L_url,
                                                                p_http_method => 'POST',
                                                                p_wallet_path => L_wallet_path,
                                                                p_wallet_pwd  => L_wallet_pwd,
                                                                p_body        => I_request_payload);
         EXCEPTION
            WHEN OTHERS
            THEN
               --
               O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
               O_response := O_error_message;
               --
               L_fail_ind := 'Y';
               --
               L_mark := 'CALL C_CHECK_ERROR_TO_BE_RETRIED';
               --
               OPEN C_CHECK_ERROR_TO_BE_RETRIED(O_response);
               FETCH C_CHECK_ERROR_TO_BE_RETRIED INTO L_error_exists;
               CLOSE C_CHECK_ERROR_TO_BE_RETRIED;
               --
            END;
            --
            L_mark := 'Check whether retriable error exists';
            --
            IF L_error_exists = 'Y'
            THEN
               --
               L_mark := 'CALL SMT_UTIL.SLEEP';
               --
               SMT_UTIL.SLEEP (L_service_retry_delay);
               --
            ELSE
               --
               EXIT; -- Exit from error retry loop for successfully retried and non retriable errors
               --
            END IF; -- Record Locked
            --
         END LOOP;

      END IF;

      IF L_debug_enabled = STATUS_YES THEN
         DBG_SQL.MSG(L_program_name,'SERVICE CALL END: FOR MESSAGE_FAMILY='||L_message_family||', MESSAGE_TYPE='||L_message_type||', TRANSACTION_TYPE='||L_service_type||', ELAPSED TIME IN SEC:'||(SYSDATE-L_start_time)*24*60*60 );
      END IF;
        --

      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                               SQLERRM || '@' || L_mark,
                                               L_program_name,
                                               TO_CHAR(SQLCODE));
         RETURN FALSE;

   END POST_REST_REQUEST;
----------------------------------------------------------------------------------------------------
END RIS_APEX_SERVICE;
/
