CREATE OR REPLACE PACKAGE         RIS_BUILD_XML AS


----------------------------------------------------------------------------
   -- PACKAGE VARIABLES
----------------------------------------------------------------------------
    --XOrder
    LP_xorder_cre_type         CONSTANT      VARCHAR2(15)   := 'XOrderCre';
    LP_xorder_mod_type         CONSTANT      VARCHAR2(15)   := 'XOrderMod';
    LP_xorder_del_type         CONSTANT      VARCHAR2(15)   := 'XOrderDel';

    LP_xorder_dtl_cre_type     CONSTANT      VARCHAR2(15)   := 'XOrderDtlCre';
    LP_xorder_dtl_mod_type     CONSTANT      VARCHAR2(15)   := 'XOrderDtlMod';
    LP_xorder_dtl_del_type     CONSTANT      VARCHAR2(15)   := 'XOrderDtlDel';
    LP_xorder_family           CONSTANT      VARCHAR2(15)   := 'XOrder';

    --XItem
    LP_xitem_cre_type         CONSTANT      VARCHAR2(15)    := 'XItemCre';
    LP_xitem_mod_type         CONSTANT      VARCHAR2(15)    := 'XItemMod';
    LP_xitem_del_type         CONSTANT      VARCHAR2(15)    := 'XItemDel';
    LP_xitem_sup_cre_type     CONSTANT      VARCHAR2(15)    := 'XItemSupCre';
    LP_xitem_sup_cnt_cre_type CONSTANT      VARCHAR2(15)    := 'XItemSupCtyCre';
    LP_xitem_reclass          CONSTANT      VARCHAR2(15)    := 'XItemReclass';
    LP_xitem_family           CONSTANT      VARCHAR2(15)    := 'XItem';

    --XAlloc
    LP_xalloc_family           CONSTANT      VARCHAR2(15)   := 'XAlloc';
    LP_xalloc_cre_type         CONSTANT      VARCHAR2(15)   := 'XAllocCre';
    LP_xalloc_dtl_cre_type     CONSTANT      VARCHAR2(15)   := 'XAllocDtlCre';

    --XCostChange
    LP_xcost_change_mod_type   CONSTANT      VARCHAR2(15)   := 'XCostChgMod';
    LP_xcost_change_family     CONSTANT      VARCHAR2(15)   := 'XCostChg';

    --XReclass
    LP_xreclass_type           CONSTANT      VARCHAR2(15)   := 'XItemRclsCre';
    LP_xreclass_family         CONSTANT      VARCHAR2(15)   := 'XItem';
    LP_xreclassref_type        CONSTANT      VARCHAR2(15)   := 'XItemRclsDel';
    LP_xreclass_dtl_del_type   CONSTANT      VARCHAR2(15)   := 'XItemRclsDtlDel';

    --XCostChange
    LP_xdiffgrpdtl_cre_type    CONSTANT      VARCHAR2(15)   := 'XDiffGrpDtlCre';
    LP_xdiffid_cre_type        CONSTANT      VARCHAR2(15)   := 'XDiffIdCre';
    LP_xdiffid_mod_type        CONSTANT      VARCHAR2(15)   := 'XDiffIdMod';
    LP_xdiffid_family          CONSTANT      VARCHAR2(15)   := 'XDiffId';

    --XTsf
    LP_xtsf_family           CONSTANT      VARCHAR2(15)     := 'XTsf';
    LP_xtsf_cre_type         CONSTANT      VARCHAR2(15)     := 'XTsfCre';

     --Inv_adj
     LP_Invadj_family        CONSTANT      VARCHAR2(25)     :='invadjust';
     L_Invadj_Cre_type       CONSTANT      VARCHAR2(25)     :='invadjustcre';

     --DIFF
     L_xdiffgrpdtldel       CONSTANT      VARCHAR2(25)      :='xdiffgrpdtldel';
     L_xdiffiddel           CONSTANT      VARCHAR2(25)      :='xdiffiddel';

     --Recieving
     L_receiving_family     CONSTANT       VARCHAR2(25)     :='receiving';
     L_receiptcre           CONSTANT       VARCHAR2(25)     :='receiptcre';

     --ASNOut
    LP_asnout_family       CONSTANT      VARCHAR2(15)       := 'ASNOut';
    LP_asnout_cre_type     CONSTANT      VARCHAR2(15)       := 'ASNOutCre';

    --CurRate
    LP_currate_family       CONSTANT      VARCHAR2(15)      := 'currate';
    LP_curratecre_type     CONSTANT      VARCHAR2(15)       := 'currratecre';

    --Xstore
    L_Xstore_Family        CONSTANT        VARCHAR2(25)     :='xstore';
    L_XStoreCre            CONSTANT        VARCHAR2(25)     :='XStoreCre';
    L_XStoreMod            CONSTANT        VARCHAR2(25)     :='XStoreMod';
    L_XStoreDel            CONSTANT        VARCHAR2(25)     :='XStoreDel';
    L_XStoreWTCre          CONSTANT        VARCHAR2(25)     :='XStoreWTCre';
    L_XStoreWTDel          CONSTANT        VARCHAR2(25)     :='XStoreWTDel';
    L_addr_mod_type        CONSTANT        VARCHAR2(15)     :='xstoreaddrmod';

    --Cost Change
    L_Costchnage_Family    CONSTANT        VARCHAR2(25)     :='Avcost';
    L_CostMod              CONSTANT        VARCHAR2(25)     :='AvcostMod';

     --OrgHr
    L_xorghr_family         CONSTANT       VARCHAR2(25)       :='XOrgHr';
    L_xorghrcre             CONSTANT       VARCHAR2(25)       :='XOrgHrCre';
    L_xorghrmod             CONSTANT       VARCHAR2(25)       :='XOrgHrMod';
    L_xorghrdel             CONSTANT       VARCHAR2(25)       :='XOrgHrDel';

    --XItemLoc
    L_XItemLoc_Family       CONSTANT       VARCHAR2(25)       :='XItemLoc';
    L_XItemLocCre           CONSTANT       VARCHAR2(25)       :='XItemLocCre';
/* **********************************************************************************************************************
* FUNCTION          :   BUILD
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/
----------------------------------------------------------------------------
FUNCTION BUILD(O_error_message   IN OUT   VARCHAR2,
               O_xml_payload     OUT      XMLTYPE,
               I_message         IN       RIB_OBJECT,
               I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN;
----------------------------------------------------------------------------

END RIS_BUILD_XML;
/


CREATE OR REPLACE PACKAGE BODY        RIS_BUILD_XML AS
/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XRECLASS_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* Abhijith              22-Apr-2018          1.0
************************************************************************************************************************/
FUNCTION  BUILD_XRECLASS_REC(O_error_message   IN OUT   VARCHAR2,
                             O_xml_payload     OUT      XMLTYPE,
                             I_message         IN       RIB_OBJECT,
                             I_message_type    IN       VARCHAR2)
   RETURN BOOLEAN IS

   PROGRAM_ERROR           EXCEPTION;
   L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XRECLASS_REC';
   L_message               "RIB_XItemRclsDesc_REC";
   L_mark                  VARCHAR2(100);

   CURSOR C_RECLASS_CREATE_XML
   IS
      SELECT XMLELEMENT ("soapenv:Envelope",
             XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/'                                      AS "xmlns:soapenv",
                           'http://www.oracle.com/retail/rms/integration/services/ItemManagementService/v1' AS "xmlns:v1",
                           'http://www.oracle.com/retail/integration/base/bo/XItemRclsDesc/v1'              AS "xmlns:v11",
                           'http://www.oracle.com/retail/integration/base/bo/XItemRclsDtl/v1'               AS "xmlns:v12"
                          ),
             XMLELEMENT ("soapenv:Header"),
             XMLELEMENT ("soapenv:Body",
                XMLELEMENT("v1:createItemReclass",
                XMLELEMENT("v11:XItemRclsDesc",
                              XMLFOREST(L_message.reclass_no AS "v11:reclass_no",
                                        L_message.reclass_desc AS "v11:reclass_desc",
                                        to_char(L_message.reclass_date,'YYYY-MM-DD"T"HH24:MI:SS') AS "v11:reclass_date",
                                        L_message.to_dept AS "v11:to_dept",
                                        L_message.to_class AS "v11:to_class",
                                        L_message.to_subclass AS "v11:to_subclass"
                                        ),
                                       (SELECT XMLAGG (
                                               XMLELEMENT ("v12:XItemRclsDtl",
                                                           XMLFOREST (item AS "v12:item")
                                                           )
                                                      )
                                          FROM TABLE(cast(L_message.XItemRclsDtl_TBL as "RIB_XItemRclsDtl_TBL"))
                                       )
                          )
                          )
                        )
                        )xml_message
        FROM  DUAL;

BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XItemRclsDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_RECLASS_CREATE_XML';
    --
    OPEN C_RECLASS_CREATE_XML;
    FETCH C_RECLASS_CREATE_XML INTO O_xml_payload;
    CLOSE C_RECLASS_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XRECLASS_REC;


/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XRECLASS_DTL_DEL_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* Pradeep G,Infosys     19-Jun-2018          1.0
************************************************************************************************************************/
FUNCTION  BUILD_XRECLASS_DTL_DEL_REC(O_error_message   IN OUT   VARCHAR2,
                                     O_xml_payload     OUT      XMLTYPE,
                                     I_message         IN       RIB_OBJECT,
                                     I_message_type    IN       VARCHAR2)
   RETURN BOOLEAN IS

   PROGRAM_ERROR           EXCEPTION;
   L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XRECLASS_DTL_DEL_REC';
   L_message               "RIB_XItemRclsRef_REC";
   L_mark                  VARCHAR2(100);

   CURSOR C_RECLASS_DTL_DEL_XML
   IS
      SELECT XMLELEMENT ("soapenv:Envelope",
             XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/'                                      AS "xmlns:soapenv",
                           'http://www.oracle.com/retail/rms/integration/services/ItemManagementService/v1' AS "xmlns:v1",
                           'http://www.oracle.com/retail/integration/base/bo/XItemRclsRef/v1'               AS "xmlns:v11",
                           'http://www.oracle.com/retail/integration/base/bo/XItemRclsDtl/v1'               AS "xmlns:v12"
                          ),
             XMLELEMENT ("soapenv:Header"),
             XMLELEMENT ("soapenv:Body",
                XMLELEMENT("v1:deleteItemReclassDetail",
                XMLELEMENT("v11:XItemRclsRef",
                              XMLFOREST(L_message.reclass_no AS "v11:reclass_no",
                                        to_char(L_message.reclass_date,'YYYY-MM-DD"T"HH24:MI:SS') AS "v11:reclass_date",
                                        L_message.purge_all_ind AS "v11:purge_all_ind"
                                        ),
                                       (SELECT XMLAGG (
                                               XMLELEMENT ("v12:XItemRclsDtl",
                                                           XMLFOREST (item AS "v12:item")
                                                           )
                                                      )
                                          FROM TABLE(cast(L_message.XItemRclsDtl_TBL as "RIB_XItemRclsDtl_TBL"))
                                       )
                          )
                          )
                        )
                        )xml_message
        FROM  DUAL;

BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XItemRclsRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_RECLASS_DTL_DEL_XML';
    --
    OPEN C_RECLASS_DTL_DEL_XML;
    FETCH C_RECLASS_DTL_DEL_XML INTO O_xml_payload;
    CLOSE C_RECLASS_DTL_DEL_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XRECLASS_DTL_DEL_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XRECLASSREF_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* Abhijith              22-Apr-2018          1.0
****************************************************************************************************************************/
/*FUNCTION  BUILD_XRECLASSREF_REC(O_error_message   IN OUT   VARCHAR2,
                                O_xml_payload     OUT      XMLTYPE,
                                I_message         IN       RIB_OBJECT,
                                I_message_type    IN       VARCHAR2)
   RETURN BOOLEAN IS

   PROGRAM_ERROR           EXCEPTION;
   L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_XRECLASSREF_REC';
   L_message               RIB_XItemRclsRef_REC;
   L_mark                  VARCHAR2(100);
   L_count                 NUMBER(10);

   CURSOR C_CREATE_XML
   IS
      SELECT XMLELEMENT ("soapenv:Envelope",
             XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/' AS "xmlns:soapenv",
                          'http://www.oracle.com/retail/rms/integration/services/ItemManagementService/v1' AS "xmlns:v1",
                          'http://www.oracle.com/retail/integration/base/bo/XItemRclsRef/v1' AS "xmlns:v11"
                           ),
             XMLELEMENT ("soapenv:Header"),
             XMLELEMENT ("soapenv:Body",
                XMLELEMENT("v1:deleteReclass",
                   XMLELEMENT("v11:collection_size",1),
                      XMLELEMENT("v12:XItemRclsRef",
                         XMLELEMENT("v12:item" ,L_message.item)
                                )
                          )
                        )
                        )xml_message
        FROM  DUAL;
BEGIN

    L_message := TREAT(I_MESSAGE AS RIB_XItemRclsRef_REC);
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --

    --
    OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XRECLASSREF_REC;*/
/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XTSF_REC
* PURPOSE           :
* AUTHOR                  DATE                 VER
* -------                 -----------          ----  ------------------------------
* INFOSYS, Rajeev Naik    16-NOV-2017         1.0
************************************************************************************************************************/
FUNCTION  BUILD_XTSF_REC(O_error_message   IN OUT   VARCHAR2,
                                O_xml_payload     OUT      XMLTYPE,
                                I_message         IN       RIB_OBJECT,
                                I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XTSF_REC';
    L_message               "RIB_XTsfDesc_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
      /*  SELECT XMLELEMENT ("XTsfDesc",
                XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XTsfDesc/v1' as"xmlns"),
                XMLELEMENT("delivery_date" , to_char(L_message.delivery_date,'YYYY-MM-DD"T"HH24:MI:SS') ),
                XMLELEMENT("freight_code" ,nvl(L_message.freight_code,'N')),
                XMLELEMENT("from_loc" ,L_message.from_loc),
                XMLELEMENT("from_loc_type" ,L_message.from_loc_type),
                XMLELEMENT("to_loc" ,L_message.to_loc),
                XMLELEMENT("to_loc_type" ,L_message.to_loc_type),
                XMLELEMENT("tsf_no" ,L_message.tsf_no),
                XMLELEMENT("tsf_type" ,L_message.tsf_type),
                (SELECT
                XMLAGG(
                XMLELEMENT ("XTsfDtl",
                             XMLFOREST (item         as "item")
                            ,XMLFOREST (tsf_qty    as "tsf_qty")
                            )
                       )FROM TABLE(cast(L_message.XTsfDtl_TBL  AS "RIB_XTsfDtl_TBL")  ) d
               )
                            )
                            FROM DUAL;*/

       SELECT XMLELEMENT ("soapenv:Envelope",
              XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/' AS "xmlns:soapenv",
                          'http://www.oracle.com/retail/rms/integration/services/TransferManagementService/v1' AS "xmlns:v1",
                          'http://www.oracle.com/retail/integration/base/bo/XTsfColDesc/v1' AS "xmlns:v11",
                          'http://www.oracle.com/retail/integration/base/bo/XTsfDesc/v1' AS "xmlns:v12"
                      ),
              XMLELEMENT ("soapenv:Header"),
                  XMLELEMENT("soapenv:Body",
                  XMLELEMENT("v1:createXTsfColDesc",
                  XMLELEMENT("v11:XTsfColDesc",
                  XMLELEMENT("v11:collection_size",1),
                  XMLELEMENT("v12:XTsfDesc",
                              XMLELEMENT("v12:tsf_no",         L_message.tsf_no),
                              XMLELEMENT("v12:from_loc_type",  L_message.from_loc_type),
                              XMLELEMENT("v12:from_loc",       L_message.from_loc),
                              XMLELEMENT("v12:to_loc_type",    L_message.to_loc_type),
                              XMLELEMENT("v12:to_loc",         L_message.to_loc),
                              XMLELEMENT("v12:delivery_date",  to_char(L_message.delivery_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                              XMLELEMENT("v12:freight_code",   nvl(L_message.freight_code,'N')),
                              XMLELEMENT("v11:tsf_type",       L_message.tsf_type),
                              (SELECT XMLAGG (
                                     XMLELEMENT ("v12:XTsfDtl",
                                                               XMLFOREST (item                AS "v12:item",
                                                                          tsf_qty           AS "v12:tsf_qty"
                                                                          )
                                                 )
                                              )
                                     FROM TABLE(cast(L_message.XTsfDtl_TBL  AS "RIB_XTsfDtl_TBL")) dt
                                  )
                              )

                  )
                  )
                      )
                      )
        FROM  dual;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XTsfDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XTSF_REC;
/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XDIFFIDDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/

FUNCTION  BUILD_XDIFFIDDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                O_xml_payload     OUT      XMLTYPE,
                                I_message         IN       RIB_OBJECT,
                                I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XDIFFIDDESC_REC';
    L_message               "RIB_XDiffIDDesc_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
         SELECT
                            XMLELEMENT("soapenv:Envelope",
                             xmlattributes
                                          (  'http://schemas.xmlsoap.org/soap/envelope/'                                                AS "xmlns:soapenv",
                                             'http://www.oracle.com/retail/rms/integration/services/DiffManagementService/v1'           AS "xmlns:v1",
                                             'http://www.oracle.com/retail/integration/base/bo/XDiffIDColDesc/v1'                       AS "xmlns:v11",
                                             'http://www.oracle.com/retail/integration/base/bo/XDiffIDDesc/v1'                          AS "xmlns:v12"
                                          ),
                             XMLELEMENT("soapenv:Header"),
                             XMLELEMENT("soapenv:Body",
                                         XMLELEMENT( EVALNAME DECODE(I_message_type,
                                                                     LP_xdiffid_cre_type,'v1:createDiffId',
                                                                     LP_xdiffid_mod_type,'v1:modifyDiffId'),
                                                     XMLELEMENT("v11:XDiffIDColDesc",
                                                                XMLELEMENT("v11:collection_size", 1),
                                                                XMLELEMENT ("v12:XDiffIDDesc",
                                                                            XMLELEMENT("v12:diff_id", L_message.diff_id),
                                                                            XMLELEMENT("v12:diff_type",L_message.diff_type),
                                                                            XMLELEMENT("v12:diff_desc", L_message.diff_desc)
                                                                           )
                                                               )
                                                   )--XMLELEMENT( "createDiffId",
                                       )--"soapenv:Body",
                           )--"soapenv:Envelope"
            FROM DUAL;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XDiffIDDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XDIFFIDDESC_REC;



/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XDIFFGRPDETDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/
FUNCTION  BUILD_XDIFFGRPDETDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                    O_xml_payload     OUT      XMLTYPE,
                                    I_message         IN       RIB_OBJECT,
                                    I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XDIFFGRPDETDESC_REC';
    L_message               "RIB_XDiffGrpDesc_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
     SELECT XMLELEMENT("soapenv:Envelope",
                             xmlattributes
                                          (  'http://schemas.xmlsoap.org/soap/envelope/'                                                    AS "xmlns:soapenv",
                                             'http://www.oracle.com/retail/rms/integration/services/DiffManagementService/v1'               AS "xmlns:v1",
                                             'http://www.oracle.com/retail/integration/base/bo/XDiffGrpColDesc/v1'                          AS "xmlns:v11",
                                             'http://www.oracle.com/retail/integration/base/bo/XDiffGrpDesc/v1'                             AS "xmlns:v12"
                                          ),
                             XMLELEMENT("soapenv:Header"),
                             XMLELEMENT("soapenv:Body",
                                         XMLELEMENT( "v1:createDiffGrpDtl",
                                                   XMLELEMENT("v11:XDiffGrpColDesc",
                                                              XMLELEMENT("v11:collection_size", 1),
                                                              XMLELEMENT ("v12:XDiffGrpDesc",
                                                                          XMLELEMENT("v12:diff_group_id", L_message.diff_group_id),
                                                                          XMLELEMENT("v12:diff_group_type",L_message.diff_group_type),
                                                                          XMLELEMENT("v12:diff_group_desc", L_message.diff_group_desc),
                                                                          (SELECT XMLELEMENT ("v12:XDiffGrpDtl",
                                                                                                       XMLFOREST (diff_id              AS "v12:diff_id"
                                                                                                                 )
                                                                                             )
                                                                             FROM TABLE(cast(L_message.XDiffGrpDtl_TBL as "RIB_XDiffGrpDtl_TBL")) d
                                                                          )
                                                                         )
                                                             )
                                                   )--XMLELEMENT( "createDiffGrpDtl",
                                       )--"soapenv:Body",
                           )--"soapenv:Envelope"
          FROM DUAL;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XDiffGrpDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XDIFFGRPDETDESC_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XCOSTCHGDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/
FUNCTION  BUILD_XCOSTCHGDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                 O_xml_payload     OUT      XMLTYPE,
                                 I_message         IN       RIB_OBJECT,
                                 I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XCOSTCHGDESC_REC';
    L_message               "RIB_XCostChgColDesc_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
          SELECT XMLELEMENT("soapenv:Envelope",
                             xmlattributes
                                          (  'http://schemas.xmlsoap.org/soap/envelope/'                                                    AS "xmlns:soapenv",
                                             'http://www.oracle.com/retail/rms/integration/services/CostChangeService/v1'                   AS "xmlns:v1",
                                             'http://www.oracle.com/retail/integration/base/bo/XCostChgColDesc/v1'                          AS "xmlns:v11",
                                             'http://www.oracle.com/retail/integration/base/bo/XCostChgDesc/v1'                             AS "xmlns:v12",
                                             'http://www.oracle.com/retail/integration/base/bo/CustFlexAttriVo/v1'                          AS "xmlns:v13"
                                          ),
                             XMLELEMENT("soapenv:Header"),
                             XMLELEMENT("soapenv:Body",
                                         XMLELEMENT( "v1:createXCostChgColDesc",
                                                      XMLELEMENT("v11:XCostChgColDesc",
                                                                 XMLELEMENT("v11:collection_size", L_message.collection_size),
                                                                 (SELECT XMLAGG(XMLELEMENT ("v12:XCostChgDesc",
                                                                                           XMLELEMENT("v12:item", item),
                                                                                           XMLELEMENT("v12:supplier",supplier),
                                                                                           XMLELEMENT("v12:origin_country_id", origin_country_id),
                                                                                           XMLELEMENT("v12:unit_cost",unit_cost),
                                                                                           XMLELEMENT("v12:recalc_ord_ind", recalc_ord_ind),
                                                                                           XMLELEMENT("v12:currency_code",currency_code)
                                                                                          )
                                                                               ) FROM TABLE(cast(L_message.XCostChgDesc_TBL AS "RIB_XCostChgDesc_TBL"))
                                                                 )
                                                                )
                                                    )--XMLELEMENT( EVALNAME
                                       )--"soapenv:Body",
                           )--"soapenv:Envelope"
          FROM DUAL;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XCostChgColDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XCOSTCHGDESC_REC;


/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XORDERREF_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/
FUNCTION  BUILD_XORDERREF_REC(O_error_message   IN OUT   VARCHAR2,
                              O_xml_payload     OUT      XMLTYPE,
                              I_message         IN       RIB_OBJECT,
                              I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XORDERREF_REC';
    L_message               "RIB_XOrderRef_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
          SELECT XMLELEMENT("soapenv:Envelope",
                            XMLATTRIBUTES
                                         (  'http://schemas.xmlsoap.org/soap/envelope/'                                                 AS "xmlns:soapenv",
                                            'http://www.oracle.com/retail/rms/integration/services/PurchaseOrderManagementService/v1'   AS "xmlns:v1",
                                            'http://www.oracle.com/retail/integration/base/bo/XOrderColRef/v1'                          AS "xmlns:v11",
                                            'http://www.oracle.com/retail/integration/base/bo/XOrderRef/v1'                             AS "xmlns:v12"
                                         ),
                            XMLELEMENT("soapenv:Header"),
                            XMLELEMENT("soapenv:Body",
                                       XMLELEMENT( EVALNAME DECODE(I_message_type,
                                                                   LP_xorder_dtl_del_type,'v1:deleteDetail'
                                                                   ),
                                                   XMLELEMENT("v11:XOrderColRef",
                                                              XMLELEMENT("v11:collection_size", 1),
                                                              XMLELEMENT ("v12:XOrderRef",
                                                                          XMLELEMENT("v12:order_no", L_message.order_no),
                                                                          (SELECT XMLAGG (
                                                                                          XMLELEMENT ("v12:XOrderDtlRef",
                                                                                                       XMLFOREST (item              AS "v12:item",
                                                                                                                  location          AS "v12:location",
                                                                                                                  ref_item          AS "v12:ref_item"
                                                                                                                 )
                                                                                                     )
                                                                                         )
                                                                             FROM TABLE(cast(L_message.XORDERDTLREF_TBL as "RIB_XOrderDtlRef_TBL")) d
                                                                          ),
                                                                          XMLELEMENT("v12:attempt_rms_load",L_message.attempt_rms_load)
                                                                         )
                                                             )
                                                 )--XMLELEMENT( EVALNAME
                                      )--"soapenv:Body"
                           )--"soapenv:Envelope"
            FROM DUAL;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XOrderRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XORDERREF_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_ITEMDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/
FUNCTION  BUILD_ITEMDESC_REC(O_error_message   IN OUT   VARCHAR2,
                             O_xml_payload     OUT      XMLTYPE,
                             I_message         IN       RIB_OBJECT,
                             I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML_COPY.BUILD_ITEMDESC_REC';
    L_message               "RIB_XItemDesc_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
        SELECT XMLELEMENT("soapenv:Envelope",
                          xmlattributes
                                       (  'http://schemas.xmlsoap.org/soap/envelope/' as "xmlns:soapenv",
                                          'http://www.oracle.com/retail/rms/integration/services/ItemManagementService/v1' as "xmlns:v1",
                                          'http://www.oracle.com/retail/integration/base/bo/XItemColDesc/v1' as "xmlns:v11",
                                          'http://www.oracle.com/retail/integration/base/bo/XItemDesc/v1' as "xmlns:v12",
                                          'http://www.oracle.com/retail/integration/base/bo/LocOfXItemDesc/v1' as "xmlns:v13",
                                          'http://www.oracle.com/retail/integration/localization/bo/BrXItemDesc/v1' as "xmlns:v14",
                                          'http://www.oracle.com/retail/integration/base/bo/NameValPairRBO/v1' as "xmlns:v15",
                                          'http://www.oracle.com/retail/integration/custom/bo/EOfBrXItemDesc/v1' as "xmlns:v16",
                                          'http://www.oracle.com/retail/integration/base/bo/CustFlexAttriVo/v1' as "xmlns:v17",
                                          'http://www.oracle.com/retail/integration/base/bo/XItmSupCtyMfrDesc/v1' as "xmlns:v18"
                                       ),
                          XMLELEMENT("soapenv:Header"),
                          XMLELEMENT("soapenv:Body",
                                       XMLELEMENT(EVALNAME DECODE(I_message_type,
                                                                  LP_xitem_cre_type,'v1:createItem',
                                                                  LP_xitem_sup_cre_type,'v1:createSupplier',
                                                                  LP_xitem_sup_cnt_cre_type,'v1:createSupplierCountry',
                                                                  LP_xitem_mod_type,'v1:modifyItem'),
                                                   XMLELEMENT( "v11:XItemColDesc",
                                                               XMLELEMENT("v11:collection_size", 1),
                                                               XMLELEMENT ("v12:XItemDesc",
                                                                            XMLFOREST (L_message.item                    AS "v12:item",
                                                                                       L_message.item_parent             AS "v12:item_parent",
                                                                                       L_message.item_grandparent        AS "v12:item_grandparent",
                                                                                       L_message.pack_ind                AS "v12:pack_ind",
                                                                                       L_message.item_level              AS "v12:item_level",
                                                                                       L_message.tran_level              AS "v12:tran_level",
                                                                                       L_message.diff_1                  AS "v12:diff_1",
                                                                                       L_message.diff_2                  AS "v12:diff_2",
                                                                                       L_message.diff_3                  AS "v12:diff_3",
                                                                                       L_message.diff_4                  AS "v12:diff_4",
                                                                                       L_message.dept                    AS "v12:dept",
                                                                                       L_message.class                   AS "v12:class",
                                                                                       L_message.subclass                AS "v12:subclass",
                                                                                       L_message.item_desc               AS "v12:item_desc",
                                                                                       L_message.iscloc_hier_level       AS "v12:iscloc_hier_level",
                                                                                       L_message.izp_hier_level          AS "v12:izp_hier_level",
                                                                                       L_message.short_desc              AS "v12:short_desc",
                                                                                       L_message.cost_zone_group_id      AS "v12:cost_zone_group_id",
                                                                                       L_message.standard_uom            AS "v12:standard_uom",
                                                                                       L_message.store_ord_mult          AS "v12:store_ord_mult",
                                                                                       L_message.forecast_ind            AS "v12:forecast_ind",
                                                                                       L_message.simple_pack_ind         AS "v12:simple_pack_ind",
                                                                                       L_message.contains_inner_ind      AS "v12:contains_inner_ind",
                                                                                       L_message.sellable_ind            AS "v12:sellable_ind",
                                                                                       L_message.orderable_ind           AS "v12:orderable_ind",
                                                                                       L_message.pack_type               AS "v12:pack_type",
                                                                                       L_message.order_as_type           AS "v12:order_as_type",
                                                                                       L_message.comments                AS "v12:comments",
                                                                                       to_char(SYSDATE,'YYYY-MM-DD"T"HH24:MI:SS')         AS "v12:create_datetime"
                                                                                       ),
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemCtryDesc",
                                                                                                        XMLFOREST (country_id                                 AS "v12:country_id"
                                                                                                                  ),
                                                                                                        XMLELEMENT ("v13:LocOfXItemCtryDesc",
                                                                                                                    (SELECT XMLAGG ( XMLELEMENT ("v14:BrXItemCtryDesc",
                                                                                                                                                XMLFOREST(service_ind             AS "v14:service_ind",
                                                                                                                                                          origin_code             AS "v14:origin_code",
                                                                                                                                                          classification_id       AS "v14:classification_id",
                                                                                                                                                          ncm_char_code           AS "v14:ncm_char_code",
                                                                                                                                                          ex_ipi                  AS "v14:ex_ipi",
                                                                                                                                                          pauta_code              AS "v14:pauta_code",
                                                                                                                                                          service_code            AS "v14:service_code",
                                                                                                                                                          federal_service         AS "v14:federal_service",
                                                                                                                                                          state_of_manufacture    AS "v14:state_of_manufacture",
                                                                                                                                                          pharma_list_type        AS "v14:pharma_list_type"
                                                                                                                                                         ),
                                                                                                                                                (SELECT XMLAGG ( XMLELEMENT ("v15:NameValPairRBO",
                                                                                                                                                                             XMLFOREST(a2.name  AS "v15:name",
                                                                                                                                                                                       a2.value AS "v15:value"
                                                                                                                                                                                      )
                                                                                                                                                                             )
                                                                                                                                                                )
                                                                                                                                                   FROM  TABLE(cast(a1.NameValPairRBO_TBL AS "RIB_NameValPairRBO_TBL")) a2
                                                                                                                                                ),
                                                                                                                                                 XMLFOREST(a1.EOfBrXItemCtryDesc    AS "v16:EOfBrXItemCtryDesc")
                                                                                                                                                )
                                                                                                                                   )
                                                                                                                      FROM  TABLE(cast(d.LocOfXItemCtryDesc.BrXItemCtryDesc_TBL AS "RIB_BrXItemCtryDesc_TBL")) a1
                                                                                                                      )
                                                                                                                   )
                                                                                                      )
                                                                                          )
                                                                              FROM TABLE(cast(L_message.XItemCtryDesc_TBL as "RIB_XItemCtryDesc_TBL")) d
                                                                           ),
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemSupDesc",
                                                                                                       XMLFOREST(supplier             AS "v12:supplier",
                                                                                                                 primary_supp_ind     AS "v12:primary_supp_ind",
                                                                                                                 vpn                  AS "v12:vpn",
                                                                                                                 supp_label           AS "v12:supp_label"
                                                                                                                 ),
                                                                                                        (SELECT XMLAGG (
                                                                                                                        XMLELEMENT ("v12:XItemSupCtyDesc",
                                                                                                                                    XMLFOREST(origin_country_id     AS "v12:origin_country_id",
                                                                                                                                              primary_country_ind   AS "v12:primary_country_ind",
                                                                                                                                              unit_cost             AS "v12:unit_cost"
                                                                                                                                             ),
                                                                                                                                    (SELECT XMLAGG (XMLELEMENT ("v12:XItemCostDesc",
                                                                                                                                                                XMLFOREST (delivery_country_id      AS "v12:delivery_country_id",
                                                                                                                                                                           primary_dlvy_ctry_ind    AS "v12:primary_dlvy_ctry_ind",
                                                                                                                                                                           nic_static_ind           AS "v12:nic_static_ind",
                                                                                                                                                                           base_cost                AS "v12:base_cost",
                                                                                                                                                                           negotiated_item_cost     AS "v12:negotiated_item_cost"
                                                                                                                                                                           ),
                                                                                                                                                                XMLELEMENT ("v13:LocOfXItemCostDesc",
                                                                                                                                                                            (SELECT XMLAGG ( XMLELEMENT ("v14:BrXItemCostDesc",
                                                                                                                                                                                                         XMLFOREST(b4.EOfBrXItemCostDesc    AS "v16:EOfBrXItemCostDesc"
                                                                                                                                                                                                                  )
                                                                                                                                                                                                        )
                                                                                                                                                                                           )
                                                                                                                                                                               FROM  TABLE(cast(b3.LocOfXItemCostDesc.BrXItemCostDesc_TBL AS "RIB_BrXItemCostDesc_TBL")) b4
                                                                                                                                                                            )
                                                                                                                                                                           )
                                                                                                                                                               )
                                                                                                                                                   )
                                                                                                                                       FROM TABLE(cast(b1.XItemCostDesc_TBL  as "RIB_XItemCostDesc_TBL")) b3
                                                                                                                                    ),
                                                                                                                                    (SELECT XMLAGG (XMLELEMENT ("v12:XISCLocDesc",
                                                                                                                                                                XMLFOREST (hier_id                  AS "v12:hier_id",
                                                                                                                                                                           unit_cost                AS "v12:unit_cost",
                                                                                                                                                                           negotiated_item_cost     AS "v12:negotiated_item_cost",
                                                                                                                                                                           primary_loc_ind          AS "v12:primary_loc_ind",
                                                                                                                                                                           pickup_lead_time         AS "v12:pickup_lead_time",
                                                                                                                                                                           round_lvl                AS "v12:round_lvl",
                                                                                                                                                                           round_to_case_pct        AS "v12:round_to_case_pct",
                                                                                                                                                                           round_to_layer_pct       AS "v12:round_to_layer_pct",
                                                                                                                                                                           round_to_pallet_pct      AS "v12:round_to_pallet_pct",
                                                                                                                                                                           round_to_inner_pct       AS "v12:round_to_inner_pct",
                                                                                                                                                                           supp_hier_lvl_1          AS "v12:supp_hier_lvl_1",
                                                                                                                                                                           supp_hier_lvl_2          AS "v12:supp_hier_lvl_2",
                                                                                                                                                                           supp_hier_lvl_3          AS "v12:supp_hier_lvl_3"
                                                                                                                                                                           ),
                                                                                                                                                                XMLELEMENT ("v13:LocOfXISCLocDesc",
                                                                                                                                                                            (SELECT XMLAGG ( XMLELEMENT ("v14:BrXISCLocDesc",
                                                                                                                                                                                                         XMLFOREST(b6.EOfBrXISCLocDesc  AS "v16:EOfBrXISCLocDesc"
                                                                                                                                                                                                                  )
                                                                                                                                                                                                        )
                                                                                                                                                                                           )
                                                                                                                                                                               FROM  TABLE(cast(b5.LocOfXISCLocDesc.BrXISCLocDesc_TBL AS "RIB_BrXISCLocDesc_TBL")) b6
                                                                                                                                                                            )
                                                                                                                                                                           )
                                                                                                                                                               )
                                                                                                                                                   )
                                                                                                                                       FROM TABLE(cast(b1.XISCLocDesc_TBL  as "RIB_XISCLocDesc_TBL")) b5
                                                                                                                                    ),
                                                                                                                                    XMLFOREST(lead_time             AS "v12:lead_time",
                                                                                                                                              pickup_lead_time      AS "v12:pickup_lead_time",
                                                                                                                                              min_order_qty         AS "v12:min_order_qty",
                                                                                                                                              max_order_qty         AS "v12:max_order_qty",
                                                                                                                                              supp_hier_lvl_1       AS "v12:supp_hier_lvl_1",
                                                                                                                                              supp_hier_lvl_2       AS "v12:supp_hier_lvl_2",
                                                                                                                                              supp_hier_lvl_3       AS "v12:supp_hier_lvl_3",
                                                                                                                                              default_uop           AS "v12:default_uop",
                                                                                                                                              supp_pack_size        AS "v12:supp_pack_size",
                                                                                                                                              inner_pack_size       AS "v12:inner_pack_size",
                                                                                                                                              ti                    AS "v12:ti",
                                                                                                                                              hi                    AS "v12:hi"
                                                                                                                                             ),
                                                                                                                                    (SELECT XMLAGG (XMLELEMENT ("v12:XISCDimDesc",
                                                                                                                                                                XMLFOREST (dim_object            AS "v12:dim_object",
                                                                                                                                                                           tare_weight           AS "v12:tare_weight",
                                                                                                                                                                           tare_type             AS "v12:tare_type",
                                                                                                                                                                           lwh_uom               AS "v12:lwh_uom",
                                                                                                                                                                           length                AS "v12:length",
                                                                                                                                                                           width                 AS "v12:width",
                                                                                                                                                                           dim_height            AS "v12:dim_height",
                                                                                                                                                                           liquid_volume         AS "v12:liquid_volume",
                                                                                                                                                                           liquid_volume_uom     AS "v12:liquid_volume_uom",
                                                                                                                                                                           stat_cube             AS "v12:stat_cube",
                                                                                                                                                                           weight_uom            AS "v12:weight_uom",
                                                                                                                                                                           weight                AS "v12:weight",
                                                                                                                                                                           net_weight            AS "v12:net_weight",
                                                                                                                                                                           presentation_method   AS "v12:presentation_method"
                                                                                                                                                                           ),
                                                                                                                                                                           XMLELEMENT ("v13:LocOfXISCDimDesc",
                                                                                                                                                                                       (SELECT XMLAGG ( XMLELEMENT ("v14:BrXISCDimDesc",
                                                                                                                                                                                                                    XMLFOREST(b8.EOfBrXISCDimDesc   AS "v16:EOfBrXISCDimDesc"
                                                                                                                                                                                                                             )
                                                                                                                                                                                                                   )
                                                                                                                                                                                                      )
                                                                                                                                                                                          FROM  TABLE(cast(b2.LocOfXISCDimDesc.BrXISCDimDesc_TBL AS "RIB_BrXISCDimDesc_TBL")) b8
                                                                                                                                                                                       )
                                                                                                                                                                                     )

                                                                                                                                                               )
                                                                                                                                                   )
                                                                                                                                       FROM TABLE(cast(b1.XISCDIMDESC_TBL  as "RIB_XISCDimDesc_TBL")) b2
                                                                                                                                    ),
                                                                                                                                    XMLFOREST(cost_uom              AS "v12:cost_uom",
                                                                                                                                              tolerance_type        AS "v12:tolerance_type",
                                                                                                                                              min_tolerance         AS "v12:min_tolerance",
                                                                                                                                              max_tolerance         AS "v12:max_tolerance",
                                                                                                                                              supp_hier_type_1      AS "v12:supp_hier_type_1",
                                                                                                                                              supp_hier_type_2      AS "v12:supp_hier_type_2",
                                                                                                                                              supp_hier_type_3      AS "v12:supp_hier_type_3",
                                                                                                                                              round_lvl             AS "v12:round_lvl",
                                                                                                                                              round_to_inner_pct    AS "v12:round_to_inner_pct",
                                                                                                                                              round_to_case_pct     AS "v12:round_to_case_pct",
                                                                                                                                              round_to_layer_pct    AS "v12:round_to_layer_pct",
                                                                                                                                              round_to_pallet_pct   AS "v12:round_to_pallet_pct",
                                                                                                                                              packing_method        AS "v12:packing_method"
                                                                                                                                             ),
                                                                                                                                   (SELECT XMLAGG ( XMLELEMENT ("v17:CustFlexAttriVo",
                                                                                                                                                                XMLFOREST(b20.name   AS "v17:name",
                                                                                                                                                                          b20.value   AS "v17:value",
                                                                                                                                                                          to_char(b20.value_date,'YYYY-MM-DD"T"HH24:MI:SS')    AS "v17:value_date"
                                                                                                                                                                         )
                                                                                                                                                               )
                                                                                                                                                  )
                                                                                                                                      FROM  TABLE(cast(b1.CustFlexAttriVo_TBL AS "RIB_CustFlexAttriVo_TBL")) b20
                                                                                                                                   )
                                                                                                                                   --LocOfXItemSupCtyDesc
                                                                                                                                        --BrXItemSupCtyDesc
                                                                                                                                            --EOfBrXItemSupCtyDesc
                                                                                                                                   )
                                                                                                                        )
                                                                                                           FROM TABLE(cast(d2.XITEMSUPCTYDESC_TBL as "RIB_XItemSupCtyDesc_TBL")) b1
                                                                                                        ),
                                                                                                       XMLFOREST(consignment_rate           AS "v12:consignment_rate",
                                                                                                                 to_char(supp_discontinue_date,'YYYY-MM-DD"T"HH24:MI:SS')      AS "v12:supp_discontinue_date",
                                                                                                                 direct_ship_ind            AS "v12:direct_ship_ind",
                                                                                                                 pallet_name                AS "v12:pallet_name",
                                                                                                                 case_name                  AS "v12:case_name",
                                                                                                                 inner_name                 AS "v12:inner_name"
                                                                                                                ),
                                                                                                       (SELECT XMLAGG (XMLELEMENT ("v18:XItmSupCtyMfrDesc",
                                                                                                                                   XMLFOREST (manufacturer_ctry_id              AS "v18:manufacturer_ctry_id",
                                                                                                                                              primary_manufacturer_ctry_ind     AS "v18:primary_manufacturer_ctry_ind"
                                                                                                                                             )
                                                                                                                                  )
                                                                                                                      )
                                                                                                          FROM TABLE(cast(d2.XITMSUPCTYMFRDESC_TBL as "RIB_XItmSupCtyMfrDesc_TBL")) d1
                                                                                                       ),
                                                                                                       XMLFOREST(primary_case_size  AS "v12:primary_case_size",
                                                                                                                 supp_diff_1        AS "v12:supp_diff_1",
                                                                                                                 supp_diff_2        AS "v12:supp_diff_2",
                                                                                                                 supp_diff_3        AS "v12:supp_diff_3",
                                                                                                                 supp_diff_4        AS "v12:supp_diff_4",
                                                                                                                 concession_rate    AS "v12:concession_rate"
                                                                                                                ),
                                                                                                       (SELECT XMLAGG (XMLELEMENT ("v17:CustFlexAttriVo",
                                                                                                                                   XMLFOREST (c1.name       AS "v17:name",
                                                                                                                                              c1.value      AS "v17:value",
                                                                                                                                              to_char(c1.value_date,'YYYY-MM-DD"T"HH24:MI:SS') AS "v17:value_date"
                                                                                                                                             )
                                                                                                                                  )
                                                                                                                      )
                                                                                                          FROM TABLE(cast(L_message.CustFlexAttriVo_TBL as "RIB_CustFlexAttriVo_TBL")) c1)--CustFlexAttriVo
                                                                                                        ,
                                                                                                       XMLELEMENT ("v13:LocOfXItemSupDesc",
                                                                                                                   (SELECT XMLAGG (XMLELEMENT ("v14:BrXItemSupDesc",
                                                                                                                                   XMLFOREST (origin_code              AS "v14:origin_code"
                                                                                                                                             )
                                                                                                                                   --EOfBrXItemSupDesc
                                                                                                                                  )
                                                                                                                      )
                                                                                                          FROM TABLE(cast(d2.LocOfXItemSupDesc.BrXItemSupDesc_TBL as "RIB_BrXItemSupDesc_TBL")) c10)
                                                                                                          )--LocOfXItemSupDesc
                                                                                                           ,
                                                                                                       (SELECT XMLAGG (XMLELEMENT ("v12:LangOfXItemSupDesc",
                                                                                                                                   XMLFOREST (lang              AS "v12:lang",
                                                                                                                                              supp_diff_1       AS "v12:supp_diff_1",
                                                                                                                                              supp_diff_2       AS "v12:supp_diff_2",
                                                                                                                                              supp_diff_3       AS "v12:supp_diff_3",
                                                                                                                                              supp_diff_4       AS "v12:supp_diff_4",
                                                                                                                                              supp_label        AS "v12:supp_label"                                                                                                                                             )
                                                                                                                                   --EOfBrXItemSupDesc
                                                                                                                                  )
                                                                                                                      )
                                                                                                          FROM TABLE(cast(d2.LangOfXItemSupDesc_TBL as "RIB_LangOfXItemSupDesc_TBL")) c11
                                                                                                        ) --LangOfXItemSupDesc

                                                                                                      )
                                                                                                      )
                                                                                          FROM TABLE(cast(L_message.XItemSupDesc_TBL as "RIB_XItemSupDesc_TBL")) d2),
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemBOMDesc",
                                                                                                        XMLFOREST (component_item                                   AS "v12:component_item",
                                                                                                                   pack_qty                                         AS "v12:pack_qty"
                                                                                                                   --LocOfXItemBOMDesc
                                                                                                                        --BrXItemBOMDesc
                                                                                                                            --EOfBrXItemBOMDesc
                                                                                                                  )
                                                                                                        --LocOfXItemBOMDesc
                                                                                                       )
                                                                                           )
                                                                              FROM TABLE(cast(L_message.XItemBOMDesc_TBL as "RIB_XItemBOMDesc_TBL")) f
                                                                           ),--XItemBOMDesc
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemVATDesc",
                                                                                                        XMLFOREST (vat_type                                   AS "v12:vat_type",
                                                                                                                   vat_region                                 AS "v12:vat_region",
                                                                                                                   vat_code                                   AS "v12:vat_code",
                                                                                                                   to_char(active_date,'YYYY-MM-DD"T"HH24:MI:SS')                                AS "v12:active_date",
                                                                                                                   reverse_vat_ind                            AS "v12:reverse_vat_ind"
                                                                                                                   --LocOfXItemBOMDesc
                                                                                                                        --BrXItemBOMDesc
                                                                                                                            --EOfBrXItemBOMDesc
                                                                                                                  )
                                                                                                       )
                                                                                           )
                                                                              FROM TABLE(cast(L_message.XItemVATDesc_TBL as "RIB_XItemVATDesc_TBL")) g
                                                                           ),-- XItemVATDesc
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XIZPDesc",
                                                                                                        XMLFOREST (hier_id              AS "v12:hier_id",
                                                                                                                   base_retail_ind      AS "v12:base_retail_ind",
                                                                                                                   selling_unit_retail  AS "v12:selling_unit_retail",
                                                                                                                   selling_uom          AS "v12:selling_uom",
                                                                                                                   multi_selling_uom    AS "v12:multi_selling_uom",
                                                                                                                   country_id           AS "v12:country_id",
                                                                                                                   currency_code        AS "v12:currency_code",
                                                                                                                   multi_units          AS "v12:multi_units",
                                                                                                                   multi_unit_retail    AS "v12:multi_unit_retail"
                                                                                                                   --LocOfXIZPDesc
                                                                                                                        --BrXIZPDesc
                                                                                                                            --EOfBrXIZPDesc
                                                                                                                  )
                                                                                                        )
                                                                                          )
                                                                              FROM TABLE(cast(L_message.XIZPDesc_TBL as "RIB_XIZPDesc_TBL")) g
                                                                           ),--XIZPDesc
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemUDADtl",
                                                                                                        XMLFOREST (uda_id               AS "v12:uda_id",
                                                                                                                   display_type         AS "v12:display_type",
                                                                                                                   to_char(uda_date,'YYYY-MM-DD"T"HH24:MI:SS')             AS "v12:uda_date",
                                                                                                                   uda_value            AS "v12:uda_value",
                                                                                                                   uda_text             AS "v12:uda_text",
                                                                                                                   to_char(create_datetime,'YYYY-MM-DD"T"HH24:MI:SS')      AS "v12:create_datetime",
                                                                                                                   to_char(last_update_datetime,'YYYY-MM-DD"T"HH24:MI:SS') AS "v12:last_update_datetime",
                                                                                                                   last_update_id       AS "v12:last_update_id"
                                                                                                                   --LocOfXItemUDADtl
                                                                                                                        --BrXItemUDADtl
                                                                                                                            --EOfBrXItemUDADtl
                                                                                                                  )
                                                                                                     )
                                                                                          )
                                                                              FROM TABLE(cast(L_message.XItemUDADtl_TBL as "RIB_XItemUDADtl_TBL")) h
                                                                           ),--XItemUDADtl
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemSeason",
                                                                                                        XMLFOREST (season_id            AS "v12:season_id",
                                                                                                                   phase_id             AS "v12:phase_id",
                                                                                                                   item_season_seq_no   AS "v12:item_season_seq_no",
                                                                                                                   diff_id              AS "v12:diff_id",
                                                                                                                   to_char(create_datetime,'YYYY-MM-DD"T"HH24:MI:SS')      AS "v12:create_datetime",
                                                                                                                   to_char(last_update_datetime,'YYYY-MM-DD"T"HH24:MI:SS') AS "v12:last_update_datetime",
                                                                                                                   last_update_id       AS "v12:last_update_id",
                                                                                                                   color                AS "v12:color"
                                                                                                                   --LocOfXItemSeason
                                                                                                                        --BrXItemSeason
                                                                                                                            --EOfBrXItemSeason
                                                                                                                  )
                                                                                                     )
                                                                                          )
                                                                              FROM TABLE(cast(L_message.XItemSeason_TBL as "RIB_XItemSeason_TBL")) h
                                                                           ),--XItemSeason
                                                                           (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v12:XItemImage",
                                                                                                        XMLFOREST (image_name           AS "v12:image_name",
                                                                                                                   image_addr           AS "v12:image_addr",
                                                                                                                   image_desc           AS "v12:image_desc",
                                                                                                                   to_char(create_datetime,'YYYY-MM-DD"T"HH24:MI:SS')      AS "v12:create_datetime",
                                                                                                                   to_char(last_update_datetime,'YYYY-MM-DD"T"HH24:MI:SS')  AS "v12:last_update_datetime",
                                                                                                                   last_update_id       AS "v12:last_update_id",
                                                                                                                   --LocOfXItemImage
                                                                                                                        --BrXItemImage
                                                                                                                            --EOfBrXItemImage
                                                                                                                   image_type           AS "v12:image_type",
                                                                                                                   primary_ind          AS "v12:primary_ind",
                                                                                                                   display_priority     AS "v12:display_priority"
                                                                                                                  )
                                                                                                     )
                                                                                          )
                                                                              FROM TABLE(cast(L_message.XItemImage_TBL as "RIB_XItemImage_TBL")) h
                                                                           ),--XItemImage
                                                                           XMLFOREST(L_message.status                  AS "v12:status",
                                                                                     L_message.uom_conv_factor         AS "v12:uom_conv_factor",
                                                                                     L_message.package_size            AS "v12:package_size",
                                                                                     L_message.handling_temp           AS "v12:handling_temp",
                                                                                     L_message.handling_sensitivity    AS "v12:handling_sensitivity",
                                                                                     L_message.mfg_rec_retail          AS "v12:mfg_rec_retail",
                                                                                     L_message.waste_type              AS "v12:waste_type",
                                                                                     L_message.waste_pct               AS "v12:waste_pct",
                                                                                     L_message.item_number_type        AS "v12:item_number_type",
                                                                                     L_message.catch_weight_ind        AS "v12:catch_weight_ind",
                                                                                     L_message.const_dimen_ind         AS "v12:const_dimen_ind",
                                                                                     L_message.gift_wrap_ind           AS "v12:gift_wrap_ind",
                                                                                     L_message.ship_alone_ind          AS "v12:ship_alone_ind",
                                                                                     L_message.ext_source_system       AS "v12:ext_source_system",
                                                                                     L_message.size_group1             AS "v12:size_group1",
                                                                                     L_message.size_group2             AS "v12:size_group2",
                                                                                     L_message.size1                   AS "v12:size1",
                                                                                     L_message.size2                   AS "v12:size2",
                                                                                     L_message.color                   AS "v12:color",
                                                                                     L_message.system_ind              AS "v12:system_ind",
                                                                                     L_message.upc_supplement          AS "v12:upc_supplement",
                                                                                     L_message.upc_type                AS "v12:upc_type",
                                                                                     L_message.primary_upc_ind         AS "v12:primary_upc_ind",
                                                                                     L_message.primary_repl_ind        AS "v12:primary_repl_ind",
                                                                                     L_message.item_aggregate_ind      AS "v12:item_aggregate_ind",
                                                                                     L_message.diff_1_aggregate_ind    AS "v12:diff_1_aggregate_ind",
                                                                                     L_message.diff_2_aggregate_ind    AS "v12:diff_2_aggregate_ind",
                                                                                     L_message.diff_3_aggregate_ind    AS "v12:diff_3_aggregate_ind",
                                                                                     L_message.diff_4_aggregate_ind    AS "v12:diff_4_aggregate_ind",
                                                                                     L_message.perishable_ind          AS "v12:perishable_ind",
                                                                                     L_message.notional_pack_ind       AS "v12:notional_pack_ind",
                                                                                     L_message.soh_inquiry_at_pack_ind  AS "v12:soh_inquiry_at_pack_ind",
                                                                                     L_message.aip_case_type           AS "v12:aip_case_type",
                                                                                     L_message.order_type              AS "v12:order_type",
                                                                                     L_message.sale_type               AS "v12:sale_type",
                                                                                     L_message.catch_weight_uom        AS "v12:catch_weight_uom",
                                                                                     L_message.deposit_item_type       AS "v12:deposit_item_type",
                                                                                     L_message.inventory_ind           AS "v12:inventory_ind",
                                                                                     L_message.item_xform_ind          AS "v12:item_xform_ind",
                                                                                     L_message.container_item          AS "v12:container_item",
                                                                                     L_message.package_uom             AS "v12:package_uom",
                                                                                     L_message.format_id               AS "v12:format_id",
                                                                                     L_message.prefix                  AS "v12:prefix",
                                                                                     L_message.brand                   AS "v12:brand",
                                                                                     L_message.product_classification  AS "v12:product_classification",
                                                                                     L_message.item_desc_secondary     AS "v12:item_desc_secondary",
                                                                                     L_message.desc_up                 AS "v12:desc_up",
                                                                                     L_message.merchandise_ind         AS "v12:merchandise_ind",
                                                                                     L_message.original_retail         AS "v12:original_retail",
                                                                                     L_message.retail_label_type       AS "v12:retail_label_type",
                                                                                     L_message.retail_label_value      AS "v12:retail_label_value",
                                                                                     L_message.default_waste_pct       AS "v12:default_waste_pct",
                                                                                     L_message.item_service_level      AS "v12:item_service_level",
                                                                                     L_message.check_uda_ind           AS "v12:check_uda_ind",
                                                                                     L_message.deposit_in_price_per_uom  AS "v12:deposit_in_price_per_uom",
                                                                                     L_message.attempt_rms_load        AS "v12:attempt_rms_load"),
                                                                            (SELECT XMLAGG (
                                                                                           XMLELEMENT ("v17:CustFlexAttriVo",
                                                                                                        XMLFOREST (name           AS "v17:name",
                                                                                                                   value          AS "v17:value",
                                                                                                                   to_char(value_date,'YYYY-MM-DD"T"HH24:MI:SS')        AS "v17:value_date"
                                                                                                                  )
                                                                                                     )
                                                                                          )
                                                                              FROM TABLE(cast(L_message.CustFlexAttriVo_TBL as "RIB_CustFlexAttriVo_TBL")) h
                                                                           )--CustFlexAttriVo
                                                                            --LocOfXItemDesc
                                                                                --BrXItemDesc
                                                                            --LangOfXItemDesc
                                                                            --XItemHTSDesc
                                                                          )
                                                             )
                         )--XMLELEMENT(EVALNAME
                         )--XMLELEMENT("soapenv:Body"
                         )--XMLELEMENT("soapenv:Envelope"
          FROM DUAL;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XItemDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_ITEMDESC_REC;


/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XORDERDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Pradeep,G    16-NOV-2017         1.0
************************************************************************************************************************/
FUNCTION  BUILD_XORDERDESC_REC(O_error_message   IN OUT   VARCHAR2,
                               O_xml_payload     OUT      XMLTYPE,
                               I_message         IN       RIB_OBJECT,
                               I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR    EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XORDERDESC_REC';
    L_message               "RIB_XOrderDesc_REC";
    L_mark                  VARCHAR2(100);
    CURSOR C_CREATE_XML
    IS
        SELECT XMLELEMENT("soapenv:Envelope",
                          xmlattributes
                                       (  'http://schemas.xmlsoap.org/soap/envelope/'                                                 AS "xmlns:soapenv",
                                          'http://www.oracle.com/retail/rms/integration/services/PurchaseOrderManagementService/v1'   AS "xmlns:v1",
                                          'http://www.oracle.com/retail/integration/base/bo/XOrderColDesc/v1'                         AS "xmlns:v11",
                                          'http://www.oracle.com/retail/integration/base/bo/XOrderDesc/v1'                            AS "xmlns:v12",
                                          'http://www.oracle.com/retail/integration/base/bo/CustFlexAttriVo/v1'                       AS "xmlns:v13"
                                       ),
                          XMLELEMENT("soapenv:Header"),
                          XMLELEMENT("soapenv:Body",
                                      XMLELEMENT( EVALNAME DECODE(I_message_type,
                                                                  LP_xorder_cre_type,'v1:createXOrderColDesc',
                                                                  LP_xorder_mod_type,'v1:modifyHeader',
                                                                  LP_xorder_dtl_cre_type,'v1:createDetail',
                                                                  LP_xorder_dtl_mod_type,'v1:modifyDetail'),
                                                  XMLELEMENT( "v11:XOrderColDesc",
                                                              XMLELEMENT("v11:collection_size", 1),
                                                              XMLELEMENT ("v12:XOrderDesc",
                                                                           XMLFOREST (L_message.order_no                                                AS "v12:order_no",
                                                                                      L_message.supplier                                                AS "v12:supplier",
                                                                                      L_message.currency_code                                           AS "v12:currency_code",
                                                                                      L_message.terms                                                   AS "v12:terms",
                                                                                      to_char(L_message.not_before_date,'YYYY-MM-DD"T"HH24:MI:SS')      AS "v12:not_before_date",
                                                                                      to_char(L_message.not_after_date,'YYYY-MM-DD"T"HH24:MI:SS')       AS "v12:not_after_date",
                                                                                      to_char(L_message.otb_eow_date,'YYYY-MM-DD"T"HH24:MI:SS')         AS "v12:otb_eow_date",
                                                                                      L_message.dept                                                    AS "v12:dept",
                                                                                      L_message.status                                                  AS "v12:status",
                                                                                      L_message.exchange_rate                                           AS "v12:exchange_rate",
                                                                                      L_message.include_on_ord_ind                                      AS "v12:include_on_ord_ind",
                                                                                      to_char(L_message.written_date,'YYYY-MM-DD"T"HH24:MI:SS')         AS "v12:written_date"
                                                                                     ),
                                                                          (SELECT XMLAGG (
                                                                                          XMLELEMENT ("v12:XOrderDtl",
                                                                                                       XMLFOREST (item                                             AS "v12:item",
                                                                                                                  location                                         AS "v12:location",
                                                                                                                  unit_cost                                        AS "v12:unit_cost",
                                                                                                                  ref_item                                         AS "v12:ref_item",
                                                                                                                  origin_country_id                                AS "v12:origin_country_id",
                                                                                                                  supp_pack_size                                   AS "v12:supp_pack_size",
                                                                                                                  qty_ordered                                      AS "v12:qty_ordered",
                                                                                                                  location_type                                    AS "v12:location_type",
                                                                                                                  cancel_ind                                       AS "v12:cancel_ind",
                                                                                                                  reinstate_ind                                    AS "v12:reinstate_ind",
                                                                                                                  to_char(delivery_date,'YYYY-MM-DD"T"HH24:MI:SS') AS "v12:delivery_date"
                                                                                                                  --CustFlexAttriVo
                                                                                                                 )
                                                                                                     )
                                                                                         )
                                                                             FROM TABLE(cast(L_message.XORDERDTL_TBL as "RIB_XOrderDtl_TBL")) d
                                                                          ),
                                                                          (SELECT XMLAGG (
                                                                                          XMLELEMENT ("v12:XOrdSkuDtl",
                                                                                                       XMLFOREST (item                                             AS "v12:item"
                                                                                                                 )
                                                                                                     )
                                                                                         )
                                                                             FROM TABLE(cast(L_message.XORDERDTL_TBL as "RIB_XOrderDtl_TBL")) d
                                                                          ),
                                                                          XMLFOREST (L_message.orig_ind             AS "v12:orig_ind",
                                                                                     L_message.edi_po_ind           AS "v12:edi_po_ind",
                                                                                     L_message.pre_mark_ind         AS "v12:pre_mark_ind",
                                                                                     L_message.user_id              AS "v12:user_id",
                                                                                     L_message.comment_desc         AS "v12:comment_desc",
                                                                                     L_message.attempt_rms_load     AS "v12:attempt_rms_load"
                                                                                    )
                                                                          --CustFlexAttriVo
                                                                         )
                                                            )
                                                )--XMLELEMENT( EVALNAME
                                    )--"soapenv:Body",
                         )--"soapenv:Envelope"
          FROM DUAL;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XOrderDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XORDERDESC_REC;


/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XALLOCDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS            16-NOV-2018         1.0
************************************************************************************************************************/
FUNCTION  BUILD_XALLOCDESC_REC(O_error_message   IN OUT   VARCHAR2,
                               O_xml_payload     OUT      XMLTYPE,
                               I_message         IN       RIB_OBJECT,
                               I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XALLOCDESC_REC';
    L_message               "RIB_XAllocDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_ALLOC_CREATE_XML
    IS
       SELECT XMLELEMENT ("soapenv:Envelope",
              XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/' AS "xmlns:soapenv",
                          'http://www.oracle.com/retail/rms/integration/services/AllocationService/v1' AS "xmlns:v1",
                          'http://www.oracle.com/retail/integration/base/bo/XAllocDesc/v1' AS "xmlns:v11"
                      ),
              XMLELEMENT ("soapenv:Header"),
                  XMLELEMENT("soapenv:Body",
                  --XMLELEMENT("v1:createXAllocDesc",
                  XMLELEMENT(EVALNAME DECODE(I_message_type,
                                             'XAllocCre','v1:createXAllocDesc',
                                             'XAllocDtlCre','v1:createDetailXAllocDesc'
                                             ),
                  XMLELEMENT("v11:XAllocDesc",
                  XMLAGG(
                              XMLELEMENT("v11:XAlloc",
                              XMLELEMENT("v11:alloc_no",  hd.alloc_no),
                              XMLELEMENT("v11:alloc_desc", hd.alloc_desc),
                              XMLELEMENT("v11:item", hd.item),
                              XMLELEMENT("v11:from_loc", hd.from_loc),
                              XMLELEMENT("v11:release_date", to_char(hd.release_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                              XMLELEMENT("v11:origin_ind", hd.origin_ind),
                              (SELECT XMLAGG (
                                     XMLELEMENT ("v11:XAllocDtl",
                                                               XMLFOREST (to_loc                AS "v11:to_loc",
                                                                          to_loc_type           AS "v11:to_loc_type",
                                                                          qty_allocated         AS "v11:qty_allocated",
                                                                          to_char(in_store_date,'YYYY-MM-DD"T"HH24:MI:SS') AS "v11:in_store_date"
                                                                          )
                                                             )
                                                 )
                                     FROM TABLE(cast(hd.XALLOCDTL_TBL as "RIB_XAllocDtl_TBL")) dt
                                  )
                                                  )

                  )
                  )
                  )
                      )
                      )xml_message
        FROM  TABLE(cast(L_message.XALLOC_TBL as "RIB_XAlloc_TBL") ) hd;
BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_XAllocDesc_REC");

    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_ALLOC_CREATE_XML';

    IF L_count = 0 THEN
      O_error_message := 'NO_RECORDS_TO_PROCESS';
      RETURN FALSE;
   END IF;

   OPEN C_ALLOC_CREATE_XML;
   FETCH C_ALLOC_CREATE_XML INTO O_xml_payload;
   CLOSE C_ALLOC_CREATE_XML;

    --

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_XALLOCDESC_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XITEMREF_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev,Naik    16-NOV-2017         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_XITEMREF_REC(O_error_message   IN OUT   VARCHAR2,
                               O_xml_payload     OUT      XMLTYPE,
                               I_message         IN       RIB_OBJECT,
                               I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XITEMREF_REC';
    L_message               "RIB_XItemRef_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
       SELECT
            XMLELEMENT ("XItemRef",
                         XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XItemRef/v1' AS "xmlns"),
                         XMLELEMENT("item",L_message.item))
        FROM DUAL;
BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_XItemRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XITEMREF_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_INVADJ_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev,Naik    16-NOV-2017         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_INVADJ_REC(O_error_message   IN OUT   VARCHAR2,
                               O_xml_payload     OUT      XMLTYPE,
                               I_message         IN       RIB_OBJECT,
                               I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_INVADJ_REC';
    L_message               "RIB_InvAdjustDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("InvAdjustDesc",
                                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/InvAdjustDesc/v1' AS xmlns),
                                    XMLELEMENT ( "dc_dest_id" , l_message.dc_dest_id),
                                   ( SELECT (XMLAGG(
                                    XMLELEMENT ("InvAdjustDtl",
                                    XMLELEMENT ("item_id", item_id),
                                    XMLELEMENT ("adjustment_reason_code", adjustment_reason_code),
                                    XMLELEMENT ("transshipment_nbr", transshipment_nbr),
                                    XMLELEMENT ("unit_qty", unit_qty),
                                    XMLELEMENT ("from_disposition", from_disposition),
                                    XMLELEMENT ("to_disposition", to_disposition),
                                    XMLELEMENT ("from_trouble_code", from_trouble_code),
                                    XMLELEMENT ("to_trouble_code", to_trouble_code),
                                    XMLELEMENT ("from_wip_code", from_wip_code),
                                    XMLELEMENT ("to_wip_code", to_wip_code),
                                    XMLELEMENT ("transaction_code", transaction_code),
                                    XMLELEMENT ("user_id", user_id),
                                    XMLELEMENT ("create_date" , to_char(create_date, 'YYYY-MM-DD"T"HH24:MI:SS')),
                                    XMLELEMENT ("po_nbr", po_nbr),
                                    XMLELEMENT ("doc_type", doc_type),
                                    XMLELEMENT ("aux_reason_code", aux_reason_code)

                                    )
                                    ))FROM TABLE(cast(L_message.INVADJUSTDTL_TBL as "RIB_InvAdjustDtl_TBL"))
                                    ))

     xml_message from dual;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_InvAdjustDesc_REC");

    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_INVADJ_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XITEMLOCDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* Pradeep,G ,INFOSYS     14-AUG-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_XITEMLOCDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                 O_xml_payload     OUT      XMLTYPE,
                                 I_message         IN       RIB_OBJECT,
                                 I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XITEMLOCDESC_REC';
    L_message               "RIB_XItemLocDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("XItemLocDesc",
                                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XItemLocDesc/v1' AS xmlns),
                                    XMLELEMENT ( "item" , l_message.item),
                                    XMLELEMENT ( "hier_level" , l_message.hier_level),
                                   ( SELECT (XMLAGG(
                                    XMLELEMENT ("XItemLocDtl",
                                    XMLELEMENT ("hier_value", hier_value),
                                    XMLELEMENT ("primary_supp", primary_supp),
                                    XMLELEMENT ("primary_cntry", primary_cntry),
                                    XMLELEMENT ("local_item_desc", local_item_desc),
                                    XMLELEMENT ("status", status),
                                    XMLELEMENT ("store_ord_mult", store_ord_mult),
                                    XMLELEMENT ("receive_as_type", receive_as_type),
                                    XMLELEMENT ("taxable_ind", taxable_ind),
                                    XMLELEMENT ("ti", ti),
                                    XMLELEMENT ("hi", hi),
                                    XMLELEMENT ("daily_waste_pct", daily_waste_pct),
                                    XMLELEMENT ("local_short_desc", local_short_desc)
                                    )
                                    ))FROM TABLE(cast(L_message.XITEMLOCDTL_TBL as "RIB_XItemLocDtl_TBL"))
                                    ))

     xml_message from dual;
BEGIN
    L_message := TREAT(I_MESSAGE AS "RIB_XItemLocDesc_REC" );

    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XITEMLOCDESC_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XDIFFGRPDTLDEL_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev,Naik    16-NOV-2017         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_XDIFFGRPDTLDEL_REC(O_error_message   IN OUT   VARCHAR2,
                                   O_xml_payload     OUT      XMLTYPE,
                                   I_message         IN       RIB_OBJECT,
                                   I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_XDIFFGRPDTLDEL_REC';
    L_message               "RIB_XDiffGrpRef_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
       SELECT XMLELEMENT ("soapenv:Envelope",
              XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/' AS "xmlns:soapenv",
                          'http://www.oracle.com/retail/rms/integration/services/DiffManagementService/v1' AS "xmlns:v1",
                          'http://www.oracle.com/retail/integration/base/bo/XDiffGrpColRef/v1' AS "xmlns:v11",
                          'http://www.oracle.com/retail/integration/base/bo/XDiffGrpRef/v1' AS "xmlns:v12"
                      ),
              XMLELEMENT ("soapenv:Header"),
                  XMLELEMENT("soapenv:Body",
                  XMLELEMENT("v1:deleteDiffGrpDtl",
                  XMLELEMENT("v11:XDiffGrpColRef",
                  XMLELEMENT("v11:collection_size",'1'),
                  XMLELEMENT("v12:XDiffGrpRef",
                  XMLELEMENT("v12:diff_group_id" ,L_message.diff_group_id),
                  XMLELEMENT("v12:XDiffGrpDtlRef" ,
                  XMLELEMENT("v12:diff_id" ,L_message.XDiffGrpDtlRef_TBL(1).diff_id)
                            )
                  )
                  )
                      )
                      ))xml_message
        FROM  DUAL;
BEGIN
DBMS_OUTPUT.PUT_LINE('Inside RIS_BUILD_XML.BUILD_XDIFFGRPDTLDEL_REC');
    L_message := TREAT(I_MESSAGE AS "RIB_XDiffGrpRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XDIFFGRPDTLDEL_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XDIFFIDDEL_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev,Naik    16-NOV-2017         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_XDIFFIDDEL_REC(O_error_message   IN OUT   VARCHAR2,
                                   O_xml_payload     OUT      XMLTYPE,
                                   I_message         IN       RIB_OBJECT,
                                   I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_XDIFFIDDEL_REC';
    L_message               "RIB_XDiffIDRef_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("soapenv:Envelope",
              XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/' AS "xmlns:soapenv",
                          'http://www.oracle.com/retail/rms/integration/services/DiffManagementService/v1' AS "xmlns:v1",
                          'http://www.oracle.com/retail/integration/base/bo/XDiffIDColRef/v1' AS "xmlns:v11",
                          'http://www.oracle.com/retail/integration/base/bo/XDiffIDRef/v1' AS "xmlns:v12"
                      ),
              XMLELEMENT ("soapenv:Header"),
                  XMLELEMENT("soapenv:Body",
                  XMLELEMENT("v1:deleteDiffId",
                  XMLELEMENT("v11:XDiffIDColRef",
                  XMLELEMENT("v11:collection_size",1),
                  XMLELEMENT("v12:XDiffIDRef",
                  XMLELEMENT("v12:diff_id" ,L_message.diff_id)
                  )
                  )
                      )
                      ))xml_message
        FROM  DUAL;
BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_XDiffIDRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XDIFFIDDEL_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_RECEIPTDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev,Naik    16-NOV-2017         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_RECEIPTDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                   O_xml_payload     OUT      XMLTYPE,
                                   I_message         IN       RIB_OBJECT,
                                   I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_RECEIPTDESC_REC';
    L_message               "RIB_ReceiptDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("ReceiptDesc",
                                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/ReceiptDesc/v1' AS "xmlns",
                                    'http://www.w3.org/2001/XMLSchema-instance' AS "xmlns:xsi",
                                    'http://www.oracle.com/retail/integration/base/bo/ReceiptDesc/v1 http://www.oracle.com/retail/integration/base/bo/ReceiptDesc/v1/ReceiptDesc.xsd' AS "xsi:schemaLocation"
                                    ),
                                    XMLELEMENT ( "schedule_nbr" , L_message.schedule_nbr),
                                    XMLELEMENT ("appt_nbr" ,L_message.appt_nbr),
                                    (SELECT XMLAGG(
                                    XMLELEMENT ("Receipt",
                                                        XMLELEMENT ("dc_dest_id",dc_dest_id),
                                                        XMLELEMENT ("po_nbr",po_nbr),
                                                        XMLELEMENT("cust_order_nbr",cust_order_nbr  ),
                                                        XMLELEMENT("fulfill_order_nbr",fulfill_order_nbr),
                                                        XMLELEMENT("document_type",document_type),
                                                        XMLELEMENT("ref_doc_no",ref_doc_no),
                                                        XMLELEMENT("asn_nbr",asn_nbr),
                                                        (SELECT XMLAGG(
                                                                       XMLELEMENT ("ReceiptDtl",
                                                                       XMLELEMENT ("item_id" ,item_id),
                                                                       XMLELEMENT ("unit_qty",unit_qty),
                                                                       XMLELEMENT ("receipt_xactn_type",receipt_xactn_type),
                                                                       XMLELEMENT ("receipt_date",to_char(receipt_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                                                                       XMLELEMENT ("dest_id" ,dest_id),
                                                                       XMLELEMENT ("container_id",container_id),
                                                                       XMLELEMENT ("ref_container_id",ref_container_id),
                                                                       XMLELEMENT ("distro_nbr" ,distro_nbr),
                                                                       XMLELEMENT ("distro_doc_type",distro_doc_type),
                                                                       XMLELEMENT ("to_disposition",NVL(to_disposition,'ATS')),
                                                                       XMLELEMENT ("from_disposition" ,from_disposition),
                                                                       XMLELEMENT ("to_wip",to_wip),
                                                                       XMLELEMENT ("from_wip",from_wip),
                                                                       XMLELEMENT ("to_trouble" ,to_trouble),
                                                                       XMLELEMENT ("from_trouble",from_trouble),
                                                                       XMLELEMENT ("user_id",user_id),
                                                                       XMLELEMENT ("dummy_carton_ind",dummy_carton_ind),
                                                                       XMLELEMENT ("tampered_carton_ind",tampered_carton_ind),
                                                                       XMLELEMENT ("unit_cost",unit_cost),
                                                                       XMLELEMENT ("shipped_qty",shipped_qty)
                                                                                  )
                                                                      ) FROM TABLE(CAST(d.RECEIPTDTL_TBL AS "RIB_ReceiptDtl_TBL"))
                                                        )
                                            ))FROM TABLE(cast(L_message.RECEIPT_TBL  AS "RIB_Receipt_TBL") )d )) from dual;
BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_ReceiptDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_RECEIPTDESC_REC;
/* **********************************************************************************************************************
* FUNCTION          :   BUILD_ASNOUTDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS               16-NOV-2017          1.0
************************************************************************************************************************/
FUNCTION  BUILD_ASNOUTDESC_REC(O_error_message   IN OUT   VARCHAR2,
                               O_xml_payload     OUT      XMLTYPE,
                               I_message         IN       RIB_OBJECT,
                               I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_ASNOUTDESC_REC';
    L_message               "RIB_ASNOutDesc_REC";
    L_mark                  VARCHAR2(100);
    --30 Apr
    /* CURSOR C_ASNOUT_CREATE_XML
    IS
       SELECT
              XMLELEMENT ("ASNOutDesc",
                         XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/ASNOutDesc/v1' AS "xmlns"),
                         XMLELEMENT("auto_receive" ,'N'),
                         XMLELEMENT("to_location"  ,L_message.to_location),
                         XMLELEMENT("to_loc_type"  ,L_message.to_loc_type),
                         XMLELEMENT("to_store_type"  ,L_message.to_store_type),
                         XMLELEMENT("to_stockholding_ind"  ,L_message.to_stockholding_ind),
                         XMLELEMENT("from_location",L_message.from_location),
                         XMLELEMENT("from_loc_type",L_message.from_loc_type),
                         XMLELEMENT("from_store_type",L_message.from_store_type),
                         XMLELEMENT("from_stockholding_ind",L_message.from_stockholding_ind),
                         XMLELEMENT("asn_nbr" ,L_message.asn_nbr),
                         XMLELEMENT("asn_type",L_message.asn_type),
                         XMLELEMENT("bol_nbr" ,L_message.bol_nbr),
                         XMLELEMENT("shipment_date",to_char(L_message.shipment_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                         XMLELEMENT("est_arr_date" ,to_char(L_message.est_arr_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                         (SELECT XMLAGG( XMLELEMENT("ASNOutDistro",
                            XMLELEMENT("distro_nbr",dist.distro_nbr),
                            XMLELEMENT("distro_doc_type",dist.distro_doc_type),
                            XMLELEMENT("cust_order_nbr",null),
                            XMLELEMENT("fulfill_order_nbr",null),
                                      ( SELECT XMLAGG(XMLELEMENT ("ASNOutCtn",
                                               XMLELEMENT ("final_location", L_message.to_location ) ,
                                               XMLELEMENT ("container_id",   cs.container_id ),
                                               XMLELEMENT ("in_store_date",  to_char(cs.in_store_date, 'YYYY-MM-DD"T"HH24:MI:SS') ),
                                        (SELECT XMLAGG(XMLELEMENT ("ASNOutItem",
                                                XMLELEMENT ( "item_id",itm.item_id),
                                                XMLELEMENT ("unit_qty",itm.unit_qty),
                                                XMLELEMENT ("comments",  null)))
                                              FROM TABLE(CAST(cs.ASNOutItem_TBL as risgap.RIB_ASNOutItem_TBL)) itm)))
                                           FROM TABLE(CAST(dist.ASNOutCtn_TBL as risgap.RIB_ASNOutCtn_TBL))  cs))
                          ) FROM TABLE(CAST(L_message.ASNOutDistro_TBL AS risgap.RIB_ASNOutDistro_TBL)) dist),
            xmlelement("comments",null),
            xmlelement("carrier_code" ,L_message.carrier_code))
        FROM dual; */

   CURSOR C_ASNOUT_CREATE_XML
    IS
       SELECT
              XMLELEMENT ("ASNOutDesc",
                         XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/ASNOutDesc/v1' AS "xmlns"),
                         XMLELEMENT("auto_receive" ,'N'),
                         XMLELEMENT("to_location"  ,L_message.to_location),
                         XMLELEMENT("to_loc_type"  ,L_message.to_loc_type),
                         XMLFOREST(L_message.to_store_type AS "to_store_type",
                                   L_message.to_stockholding_ind AS  "to_stockholding_ind"),
                         XMLELEMENT("from_location",L_message.from_location),
                         XMLELEMENT("from_loc_type",L_message.from_loc_type),
                         XMLFOREST(L_message.from_store_type AS "from_store_type",
                                   L_message.from_stockholding_ind AS "from_stockholding_ind"),
                         XMLELEMENT("asn_nbr" ,L_message.asn_nbr),
                         XMLELEMENT("asn_type",L_message.asn_type),
                         XMLELEMENT("bol_nbr" ,L_message.bol_nbr),
                         XMLELEMENT("shipment_date",to_char(L_message.shipment_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                         XMLFOREST( to_char(L_message.est_arr_date,'YYYY-MM-DD"T"HH24:MI:SS') AS "est_arr_date"),
                         (SELECT XMLAGG( XMLELEMENT("ASNOutDistro",
                            XMLELEMENT("distro_nbr",dist.distro_nbr),
                                   XMLELEMENT("distro_doc_type",dist.distro_doc_type),
                            --XMLFOREST("cust_order_nbr",null),
                            --XMLFOREST("fulfill_order_nbr",null),
                                      ( SELECT XMLAGG(XMLELEMENT ("ASNOutCtn",
                                                    XMLELEMENT ("final_location", L_message.to_location ) ,
                                           XMLELEMENT ("container_id",   cs.container_id ),
                                                      XMLFOREST  (to_char(cs.in_store_date, 'YYYY-MM-DD"T"HH24:MI:SS') AS "in_store_date"),
                                        (SELECT XMLAGG(XMLELEMENT ("ASNOutItem",
                                                XMLELEMENT ( "item_id",itm.item_id),
                                                XMLELEMENT ("unit_qty",itm.unit_qty),
                                                XMLELEMENT ("comments",  null)))
                                              FROM TABLE(CAST(cs.ASNOutItem_TBL as "RIB_ASNOutItem_TBL")) itm)))
                                           FROM TABLE(CAST(dist.ASNOutCtn_TBL as "RIB_ASNOutCtn_TBL"))  cs))
                          ) FROM TABLE(CAST(L_message.ASNOutDistro_TBL AS "RIB_ASNOutDistro_TBL")) dist),
            --XMLFOREST("comments",null),
            xmlelement("carrier_code" ,L_message.carrier_code))
        FROM dual;
BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_ASNOutDesc_REC");

    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_ASNOUT_CREATE_XML';

    --
    OPEN C_ASNOUT_CREATE_XML;
      FETCH C_ASNOUT_CREATE_XML INTO O_xml_payload;
    CLOSE C_ASNOUT_CREATE_XML;


    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD_ASNOUTDESC_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_AVCOST_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev Naik  05-Jun-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_AVCOST_REC(O_error_message   IN  OUT  VARCHAR2,
                                O_xml_payload    OUT      XMLTYPE,
                                I_message        IN       RIB_OBJECT,
                                I_message_type   IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_AVCOST_REC';
    L_message               "RIB_ItLocAgCstColDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
       SELECT XMLELEMENT ("soapenv:Envelope",
              XMLATTRIBUTES('http://schemas.xmlsoap.org/soap/envelope/' AS "xmlns:soapenv",
                          'http://www.oracle.com/retail/rms/integration/services/AverageCostService/v1' AS "xmlns:v1",
                          'http://www.oracle.com/retail/integration/base/bo/ItLocAgCstColDesc/v1' AS "xmlns:v11",
                          'http://www.oracle.com/retail/integration/base/bo/ItLocAgCstDesc/v1' AS "xmlns:v12"
                      ),
              XMLELEMENT ("soapenv:Header"),
                  XMLELEMENT("soapenv:Body",
                  XMLELEMENT("v1:modifyAvgCost",
                  XMLELEMENT("v11:ItLocAgCstColDesc",
                  XMLELEMENT("v11:collection_size",L_message.collection_size),
                (SELECT XMLAGG( XMLELEMENT("v12:ItLocAgCstDesc",
                                XMLELEMENT ("v12:item" ,item),
                                XMLELEMENT ("v12:loc",loc),
                                XMLELEMENT ("v12:loc_type",loc_type),
                                XMLELEMENT ("v12:av_cost",av_cost)
                                )
                  ) FROM TABLE(cast(L_message.ItLocAgCstDesc_TBL AS "RIB_ItLocAgCstDesc_TBL"))
                  )
                      ))))xml_message
        FROM  DUAL;

BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_ItLocAgCstColDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
    OPEN C_CREATE_XML;
     FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;
NULL;
    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_AVCOST_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XSTOREDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Sarfraz Ali  05-Jun-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_XSTOREDESC_REC(O_error_message   IN  OUT  VARCHAR2,
                                O_xml_payload    OUT      XMLTYPE,
                                I_message        IN       RIB_OBJECT,
                                I_message_type   IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_XSTOREDESC_REC';
    L_message               "RIB_XStoreDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("XStoreDesc",
        XMLELEMENT ( "store" , l_message.store),
        XMLELEMENT ( "store_name" , l_message.store_name),
        XMLELEMENT ( "store_name10" , l_message.store_name10),
        XMLELEMENT ( "store_name3" , l_message.store_name3),
        XMLELEMENT ( "store_type" , l_message.store_type),
        XMLELEMENT ( "store_class" , l_message.store_class),
        XMLELEMENT ( "store_mgr_name" , l_message.store_mgr_name),
        XMLELEMENT ( "store_open_date" , to_char(l_message.store_open_date, 'YYYY-MM-DD"T"HH24:MI:SS')),
        XMLELEMENT ( "store_close_date" , to_char(l_message.store_close_date, 'YYYY-MM-DD"T"HH24:MI:SS')),
        XMLELEMENT ( "acquired_date" , to_char(l_message.acquired_date, 'YYYY-MM-DD"T"HH24:MI:SS')),
        XMLELEMENT ( "remodel_date" , to_char(l_message.remodel_date, 'YYYY-MM-DD"T"HH24:MI:SS')),
        XMLELEMENT ( "fax_number" , l_message.fax_number),
        XMLELEMENT ( "phone_number" , l_message.phone_number),
        XMLELEMENT ( "email" , l_message.email),
        XMLELEMENT ( "total_square_ft" , l_message.total_square_ft),
        XMLELEMENT ( "selling_square_ft" , l_message.selling_square_ft),
        XMLELEMENT ( "linear_distance" , l_message.linear_distance),
        XMLELEMENT ( "stockholding_ind" , l_message.stockholding_ind),
        XMLELEMENT ( "channel_id" , l_message.channel_id),
        XMLELEMENT ( "store_format" , l_message.store_format),
        XMLELEMENT ( "mall_name" , l_message.mall_name),
        XMLELEMENT ( "district" , l_message.district),
        XMLELEMENT ( "promo_zone" , l_message.promo_zone),
        XMLELEMENT ( "transfer_zone" , l_message.transfer_zone),
        XMLELEMENT ( "default_wh" , l_message.default_wh),
        XMLELEMENT ( "stop_order_days" , l_message.stop_order_days),
        XMLELEMENT ( "start_order_days" , l_message.start_order_days),
        XMLELEMENT ( "currency_code" , l_message.currency_code),
        XMLELEMENT ( "lang" , l_message.lang),
        XMLELEMENT ( "integrated_pos_ind" , l_message.integrated_pos_ind),
        XMLELEMENT ( "iso_code" , l_message.iso_code),
        XMLELEMENT ( "integrated_pos_ind" , l_message.integrated_pos_ind),
        XMLELEMENT ( "duns_number" , l_message.duns_number),
        XMLELEMENT ( "duns_loc" , l_message.duns_loc),
        XMLELEMENT ( "copy_dlvry_ind" , l_message.copy_dlvry_ind),
        XMLELEMENT ( "copy_activity_ind" , l_message.copy_activity_ind),
        XMLELEMENT ( "price_store" , l_message.price_store),
        XMLELEMENT ( "cost_location" , l_message.cost_location),
        XMLELEMENT ( "vat_include_ind" , l_message.vat_include_ind),
        XMLELEMENT ( "vat_region" , l_message.vat_region),
        XMLELEMENT ( "like_store" , l_message.like_store),
        XMLELEMENT ( "copy_repl_ind" , l_message.copy_repl_ind),
        XMLELEMENT ( "transfer_entity" , l_message.transfer_entity),
        XMLELEMENT ( "sister_store" , l_message.sister_store),
        XMLELEMENT ( "tran_no_generated" , l_message.tran_no_generated),
        XMLELEMENT ( "county" , l_message.county),
        ( SELECT (XMLAGG(
        XMLELEMENT ("XStoreWT",
        XMLFOREST   (walk_through_store as "walk_through_store")
        )
        ))FROM TABLE(cast(l_message.XStoreWT_TBL as "RIB_XStoreWT_TBL"))
        )
        ,
        ( SELECT (XMLAGG(
        XMLELEMENT ("AddrDesc",
        XMLFOREST   (addr as "addr"),
        XMLFOREST  (city_id as "city_id"),
        XMLFOREST  (state_name as "state_name"),
        XMLFOREST  (country_name as "country_name"),
        XMLFOREST  (addr_type as "addr_type"),
        XMLFOREST  (primary_addr_type_ind as "primary_addr_type_ind"),
        XMLFOREST  (primary_addr_ind as "primary_addr_ind"),
        XMLFOREST  (add_1 as "add_1"),
        XMLFOREST  (add_2 as "add_2"),
        XMLFOREST  (add_3 as "add_3"),
        XMLFOREST  (city as "city"),
        XMLFOREST  (state as "state"),
        XMLFOREST  (country_id as "country_id"),
        XMLFOREST  (post as "post"),
        XMLFOREST  (contact_name as "contact_name")
        )
        ))FROM TABLE(cast(L_message.AddrDesc_TBL as "RIB_AddrDesc_TBL"))
        ),
        XMLELEMENT ( "timezone_name" , l_message.timezone_name),
        XMLELEMENT ( "wf_customer_id" , l_message.wf_customer_id),
        XMLELEMENT ( "org_unit_id" , l_message.org_unit_id),
        XMLELEMENT ( "store_name_secondary" , l_message.store_name_secondary)
        ) xml_message from dual;

BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_XStoreDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
    OPEN C_CREATE_XML;
     FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XSTOREDESC_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_XSTOREREF_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev Naik  05-Jun-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_XSTOREREF_REC(O_error_message   IN  OUT  VARCHAR2,
                                O_xml_payload    OUT      XMLTYPE,
                                I_message        IN       RIB_OBJECT,
                                I_message_type   IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_XSTOREREF_REC';
    L_message               "RIB_XStoreRef_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("XStoreRef",
             XMLELEMENT ( "store" , l_message.store),
                        (SELECT (XMLAGG(XMLELEMENT ("XStoreWT",
                                                    XMLFOREST(walk_through_store as "walk_through_store")
                                                    )
                                        )
                                )FROM TABLE(cast(l_message.XStoreWT_TBL as "RIB_XStoreWT_TBL"))
                        )
                        ) FROM DUAL;

BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_XStoreRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
    OPEN C_CREATE_XML;
     FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;
NULL;
    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_XSTOREREF_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_ORGHIERDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Sarfraz Ali  19-Apr-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_ORGHIERDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                O_xml_payload     OUT      XMLTYPE,
                                I_message         IN       RIB_OBJECT,
                                I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_ORGHIERDESC_REC';
    L_message               risgap."RIB_XOrgHrDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("XOrgHrDesc",
                                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XOrgHrDesc/v1' AS "xmlns"),
                                    XMLELEMENT ( "hier_value", L_message.hier_value),
                                    XMLELEMENT ("hier_desc",   L_message.hier_desc),
                                    XMLELEMENT ("hier_level",  L_message.hier_level),
                                    XMLELEMENT ("parent_id",   L_message.parent_id),
                                    XMLELEMENT ("currency_code",   L_message.currency_code),
                                    XMLELEMENT ("XOrgHrLocTrt",
                                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XOrgHrLocTrt/v1' AS "xmlns"),
                                    (SELECT XMLELEMENT (hier_trait_id, tbl.hier_trait_id)
                                        FROM TABLE(CAST(L_message.XOrgHrLocTrt_TBL AS risgap."RIB_XOrgHrLocTrt_TBL")) tbl)))
                    FROM DUAL;


BEGIN

    L_message := TREAT(I_MESSAGE AS risgap."RIB_XOrgHrDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
    OPEN C_CREATE_XML;
     FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_ORGHIERDESC_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_ORGHIERREF_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Sarfraz Ali  19-Apr-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_ORGHIERREF_REC(O_error_message   IN  OUT  VARCHAR2,
                                O_xml_payload    OUT      XMLTYPE,
                                I_message        IN       RIB_OBJECT,
                                I_message_type   IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD_ORGHIERREF_REC';
    L_message               risgap."RIB_XOrgHrRef_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
      SELECT XMLELEMENT ("XOrgHrRef",
                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XOrgHrRef/v1' AS "xmlns"),
                    XMLELEMENT ( "hier_value" , L_message.hier_value),
                    XMLELEMENT ("hier_level" ,  L_message.hier_level),
                     XMLELEMENT ("XOrgHrLocTrt",
                    XMLATTRIBUTES('http://www.oracle.com/retail/integration/base/bo/XOrgHrLocTrt/v1' AS "xmlns"),
                    (SELECT XMLELEMENT (hier_trait_id, tbl.hier_trait_id)
                        FROM TABLE(CAST(L_message.XOrgHrLocTrt_TBL as risgap."RIB_XOrgHrLocTrt_TBL")) tbl)))
            FROM DUAL;

BEGIN

    L_message := TREAT(I_MESSAGE AS risgap."RIB_XOrgHrRef_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';

    --
    OPEN C_CREATE_XML;
     FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;

    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_ORGHIERREF_REC;

/* **********************************************************************************************************************
* FUNCTION          :   BUILD_CURRRATEDESC_REC
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS, Rajeev,Naik    07-JUN-2018         1.0
****************************************************************************************************************************/
FUNCTION  BUILD_CURRRATEDESC_REC(O_error_message   IN OUT   VARCHAR2,
                                 O_xml_payload     OUT      XMLTYPE,
                                 I_message         IN       RIB_OBJECT,
                                 I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS

    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)   := 'RIS_BUILD_XML.BUILD_CURRRATEDESC_REC';
    L_message               "RIB_CurrRateDesc_REC";
    L_mark                  VARCHAR2(100);
    L_count                 NUMBER(10);

    CURSOR C_CREATE_XML
    IS
       SELECT
            XMLELEMENT ("CurrRateDesc",
                        XMLELEMENT("from_currency",L_message.from_currency),
                        XMLELEMENT("to_currency",L_message.to_currency),
                        XMLELEMENT("conversion_date",TO_CHAR(L_message.conversion_date,'YYYY-MM-DD"T"HH24:MI:SS')),
                        XMLELEMENT("conversion_rate",L_message.conversion_rate),
                        XMLELEMENT("user_conversion_type",L_message.user_conversion_type)
                    )
        FROM DUAL;
BEGIN

    L_message := TREAT(I_MESSAGE AS "RIB_CurrRateDesc_REC");
    --
    L_mark := 'Validate the rib object';
    --
    IF L_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    L_mark := 'Open Fetch Close C_CREATE_XML';
    --
     OPEN C_CREATE_XML;
    FETCH C_CREATE_XML INTO O_xml_payload;
    CLOSE C_CREATE_XML;
    --
    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := substr('PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name,1,450);
      RETURN FALSE;
END BUILD_CURRRATEDESC_REC;

-------------------------------------------------------------------------------------------------------
   -- PUBLIC PROCEDURE
-------------------------------------------------------------------------------------------------------
/* **********************************************************************************************************************
* FUNCTION          :   BUILD
* PURPOSE           :
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS,              19-JAN-2017             1.0
************************************************************************************************************************/
FUNCTION  BUILD(O_error_message   IN OUT   VARCHAR2,
                O_xml_payload     OUT      XMLTYPE,
                I_message         IN       RIB_OBJECT,
                I_message_type    IN       VARCHAR2)
    RETURN BOOLEAN IS
    PROGRAM_ERROR           EXCEPTION;
    L_program_name          VARCHAR2(50)        := 'RIS_BUILD_XML.BUILD';
    L_ref_message           "RIB_XOrderRef_REC";
    L_message_type          VARCHAR2(50)        := LOWER(I_message_type);
    L_mark                  VARCHAR2(100);

BEGIN

    --
    L_mark := 'Validate the rib object';
    --
    IF I_message IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE', '@INVALID MESSAGE@Message object is NULL - L_mark: '||L_mark, L_program_name, NULL);
        RAISE PROGRAM_ERROR;
    END IF;
    --
    IF LOWER(L_message_type) IN (LOWER(LP_xorder_cre_type), LOWER(LP_xorder_mod_type), LOWER(LP_xorder_dtl_cre_type), LOWER(LP_xorder_dtl_mod_type)) THEN
        IF BUILD_XORDERDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xorder_dtl_del_type)) THEN
        IF BUILD_XORDERREF_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xitem_cre_type),LOWER(LP_xitem_mod_type),LOWER(LP_xitem_sup_cre_type),LOWER(LP_xitem_sup_cnt_cre_type),LOWER(LP_xitem_reclass)) THEN
        IF BUILD_ITEMDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xalloc_cre_type),LOWER(LP_xalloc_dtl_cre_type)) THEN
        IF BUILD_XALLOCDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xcost_change_mod_type)) THEN
        IF BUILD_XCOSTCHGDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xdiffid_cre_type),LOWER(LP_xdiffid_mod_type)) THEN
        IF BUILD_XDIFFIDDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xdiffgrpdtl_cre_type)) THEN
        IF BUILD_XDIFFGRPDETDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
     ELSIF LOWER(L_message_type) IN (LOWER(LP_xtsf_cre_type)) THEN
        IF BUILD_XTSF_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
     ELSIF LOWER(L_message_type) IN (LOWER(LP_xreclass_type)) THEN
        IF BUILD_XRECLASS_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
     ELSIF LOWER(L_message_type) IN (LOWER(LP_xreclass_dtl_del_type)) THEN
        IF BUILD_XRECLASS_DTL_DEL_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_xitem_del_type)) THEN
        IF BUILD_XITEMREF_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_Invadj_Cre_type)) THEN
        IF BUILD_INVADJ_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_xdiffgrpdtldel)) THEN
        IF BUILD_XDIFFGRPDTLDEL_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_xdiffiddel)) THEN
        IF BUILD_XDIFFIDDEL_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_receiptcre)) THEN
        IF BUILD_RECEIPTDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_asnout_cre_type)) THEN
        IF BUILD_ASNOUTDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_CostMod)) THEN
        IF BUILD_AVCOST_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_XStoreCre),LOWER(L_XStoreMod),LOWER(L_XStoreWTCre)) THEN
        IF BUILD_XSTOREDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_XStoreDel),LOWER(L_XStoreWTDel)) THEN
        IF BUILD_XSTOREREF_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_xorghrcre), LOWER(L_xorghrmod)) THEN
        IF BUILD_ORGHIERDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_xorghrdel)) THEN
        IF BUILD_ORGHIERREF_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(LP_curratecre_type)) THEN
        IF BUILD_CURRRATEDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSIF LOWER(L_message_type) IN (LOWER(L_XItemLocCre)) THEN
        IF BUILD_XITEMLOCDESC_REC(O_error_message,O_xml_payload,I_MESSAGE,I_message_type) = FALSE THEN
            RAISE PROGRAM_ERROR;
        END IF;
    ELSE
      O_error_message := SQL_LIB.CREATE_MSG('INVALID MESSAGE TYPE', NVL(I_message_type, 'NULL'));
      RAISE PROGRAM_ERROR;
    END IF;
    --
    RETURN TRUE;
    --

EXCEPTION
   WHEN PROGRAM_ERROR THEN
       RETURN FALSE;
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END BUILD;


END RIS_BUILD_XML;
/
