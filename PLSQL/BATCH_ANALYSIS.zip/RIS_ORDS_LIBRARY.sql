CREATE OR REPLACE PACKAGE        RIS_ORDS_LIBRARY AS
-----------------------------------------------------------------------------------------------------------------------------
-- Package Name :  RIS_ORDS_LIBRARY
-- Purpose      :  Ords library package
-----------------------------------------------------------------------------------------------------------------------------
LP_vdate                         DATE                 := GET_VDATE;
LP_user_id                       VARCHAR2(30)         := USER;
JSON_STATUS       CONSTANT       VARCHAR2(10)         :='status';
JSON_ERROR        CONSTANT       VARCHAR2(10)         :='errors';
JSON_SUC_CODE     CONSTANT       NUMBER(3)            := 200;

-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  WRITE_JSON
-- Purpose      :  Write the input ref-cursor to JSON object
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION WRITE_JSON(O_error_message         IN OUT         VARCHAR2,
                    I_jobj_name             IN             VARCHAR2,
                    I_data_cursor           IN OUT         SYS_REFCURSOR)
RETURN BOOLEAN;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  WRITE_ERROR
-- Purpose      :  Write errors captured in RIS_ORDS_ERROR_TBL to JSON object
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION WRITE_ERROR(O_error_message         IN OUT         VARCHAR2,
                     I_error_tbl             IN             RIS_ORDS_ERROR_TBL,
                     I_jobj_name             IN             VARCHAR2,
                     I_jeobj_name            IN             VARCHAR2)
RETURN BOOLEAN;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  GET_INSTANCE
-- Purpose      :  Get database instance
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION GET_INSTANCE(O_error_message         IN OUT         VARCHAR2,
                      O_instance                 OUT         VARCHAR2)
   RETURN BOOLEAN;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  CONV_BLOB_TO_CLOB
-- Purpose      :  Convert Blob To Clob
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION CONV_BLOB_TO_CLOB(O_error_message         IN OUT            VARCHAR2,
                           I_input_blob            IN                BLOB,
                           O_output_clob           IN OUT NOCOPY     CLOB)
RETURN BOOLEAN;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  CHECK_RMS_BATCH
-- Purpose      :  Function to validate RMS batch is running. This function will be called by all the ORDS services to check
--                 if RMS batch is running and return an error back to calling application.
-----------------------------------------------------------------------------------------------------------------------------
/*FUNCTION CHECK_RMS_BATCH(O_error_message         IN OUT         VARCHAR2)
   RETURN BOOLEAN;
*/
END RIS_ORDS_LIBRARY;
/


CREATE OR REPLACE PACKAGE BODY        RIS_ORDS_LIBRARY AS
-----------------------------------------------------------------------------------------------------------------------------
-- Package Name :  RIS_ORDS_LIBRARY
-- Purpose      :  Library functions for ORDS service
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  WRITE_JSON
-- Purpose      :  Write the input ref-cursor to JSON object
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION WRITE_JSON(O_error_message        IN OUT         VARCHAR2,
                    I_jobj_name            IN             VARCHAR2,
                    I_data_cursor          IN OUT         SYS_REFCURSOR)
RETURN BOOLEAN IS
   L_program_name             VARCHAR2(100)        := 'RIS_ORDS_LIBRARY.WRITE_JSON';
BEGIN
   --
   APEX_JSON.OPEN_OBJECT;
   APEX_JSON.WRITE(JSON_STATUS,JSON_SUC_CODE);
   APEX_JSON.WRITE(I_jobj_name, I_data_cursor);
   APEX_JSON.WRITE(JSON_ERROR, '', TRUE);
   APEX_JSON.CLOSE_OBJECT;
   --
   RETURN TRUE;
   --
EXCEPTION
   WHEN OTHERS
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      --
      RETURN FALSE;
      --
END WRITE_JSON;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  WRITE_ERROR
-- Purpose      :  Write errors captured in RIS_ORDS_ERROR_TBL to JSON object
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION WRITE_ERROR(O_error_message         IN OUT         VARCHAR2,
                     I_error_tbl             IN             RIS_ORDS_ERROR_TBL,
                     I_jobj_name             IN             VARCHAR2,
                     I_jeobj_name            IN             VARCHAR2)
RETURN BOOLEAN IS
   L_program_name             VARCHAR2(100)        :='RIS_ORDS_LIBRARY.WRITE_ERROR';
   L_error_code               NUMBER(10)           := 400;
   L_error_refcur             SYS_REFCURSOR;
BEGIN

   --
   OPEN L_error_refcur FOR
      SELECT /*+ cardinality(t,10) */ t.error_code     AS "message",
             t.error_desc   AS "detailedMessage"
        FROM TABLE(CAST(I_error_tbl AS RIS_ORDS_ERROR_TBL)) t;
   --

   --
   APEX_JSON.OPEN_OBJECT;
   APEX_JSON.WRITE(JSON_STATUS,L_error_code);
   APEX_JSON.WRITE(I_jobj_name, '', TRUE);
   APEX_JSON.WRITE(I_jeobj_name, L_error_refcur);
   APEX_JSON.CLOSE_OBJECT;
   --
   RETURN TRUE;
   --
EXCEPTION
   WHEN OTHERS
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      --
      RETURN FALSE;
      --
END WRITE_ERROR;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  CONV_BLOB_TO_CLOB
-- Purpose      :  Convert Blob To Clob
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION CONV_BLOB_TO_CLOB(O_error_message         IN OUT            VARCHAR2,
                           I_input_blob            IN                BLOB,
                           O_output_clob           IN OUT NOCOPY     CLOB)
RETURN BOOLEAN IS
   L_program_name             VARCHAR2(100)        :='RIS_ORDS_LIBRARY.CONV_BLOB_TO_CLOB';
   L_error_code               NUMBER(10)           := 400;
   L_file_size                INTEGER              := DBMS_LOB.LOBMAXSIZE;
   L_dest_offset              INTEGER              := 1;
   L_src_offset               INTEGER              := 1;
   L_blob_csid                NUMBER               := DBMS_LOB.DEFAULT_CSID;
   L_lang_context             NUMBER               := DBMS_LOB.DEFAULT_LANG_CTX;
   L_warning                  INTEGER;
   L_file_clob                CLOB;
   L_error_refcur             SYS_REFCURSOR;

BEGIN
   --
   IF I_input_blob IS NULL
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            'INPUT_BLOB_IS_NULL',
                                            L_program_name,
                                            NULL);
      --
      RETURN FALSE;
      --
   END IF;
   --
   DBMS_LOB.CREATETEMPORARY(O_output_clob,
                            TRUE);
   --
   DBMS_LOB.CONVERTTOCLOB(O_output_clob,
                          I_input_blob,
                          L_file_size,
                          L_dest_offset,
                          L_src_offset,
                          L_blob_csid,
                          L_lang_context,
                          L_warning);

   --
   IF (O_output_clob IS NULL)
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            'OUTPUT_CLOB_IS_NULL',
                                            L_program_name,
                                            NULL);
      --
      RETURN FALSE;
      --
   END IF;
   --
   RETURN TRUE;
   --
EXCEPTION
   WHEN OTHERS
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      --
      RETURN FALSE;
      --
END CONV_BLOB_TO_CLOB;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  GET_INSTANCE
-- Purpose      :  Get database instance
-----------------------------------------------------------------------------------------------------------------------------
FUNCTION GET_INSTANCE(O_error_message         IN OUT         VARCHAR2,
                      O_instance                 OUT         VARCHAR2)
   RETURN BOOLEAN IS
   --
   L_program_name          VARCHAR2(200)        := 'RIS_ORDS_LIBRARY.GET_INSTANCE';
   --

   --
   CURSOR C_GET_INSTANCE
   IS
      SELECT cd_nm
        FROM INTF_CNFG_PARM_T
       WHERE pgm_nm = 'GAP_INSTANCE';
   --
BEGIN
   --
    OPEN C_GET_INSTANCE;
   FETCH C_GET_INSTANCE INTO O_instance;
   CLOSE C_GET_INSTANCE;
   --

   --
   IF O_instance IS NULL
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            'INSTANCE_NULL_FETCH_INTF',
                                            L_program_name,
                                            NULL);
      --
      RETURN FALSE;
      --
   END IF;
   --
   RETURN TRUE;
   --
EXCEPTION
   WHEN OTHERS
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      --
      RETURN FALSE;
      --
END GET_INSTANCE;
-----------------------------------------------------------------------------------------------------------------------------
-- Function Name:  CHECK_RMS_BATCH
-- Purpose      :  Function to validate RMS batch is running. This function will be called by all the ORDS services to check
--                 if RMS batch is running and return an error back to calling application.
-----------------------------------------------------------------------------------------------------------------------------
/*FUNCTION CHECK_RMS_BATCH(O_error_message         IN OUT         VARCHAR2)
   RETURN BOOLEAN IS
   --
   L_program_name          VARCHAR2(200)        := 'RIS_ORDS_LIBRARY.CHECK_RMS_BATCH';
   L_batch_run_ind         VARCHAR2(2);
   --

   --
   CURSOR C_GET_RMS_BATCH_IND
   IS
      SELECT batch_running_ind
        FROM rms_batch_status;
   --
BEGIN

   --
    OPEN C_GET_RMS_BATCH_IND;
   FETCH C_GET_RMS_BATCH_IND INTO L_batch_run_ind;
   CLOSE C_GET_RMS_BATCH_IND;
   --

   --
   IF L_batch_run_ind IS NULL
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            'BATCH_INDICATOR_IS_NULL',
                                            L_program_name,
                                            NULL);
      --
      RETURN FALSE;
      --
   ELSIF L_batch_run_ind = 'Y'
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            'RMS batch is running, cannot call the service now. Please try after sometime.',
                                            L_program_name,
                                            NULL);
      --
      RETURN FALSE;
      --
   END IF;
   --
   RETURN TRUE;
   --
EXCEPTION
   WHEN OTHERS
   THEN
      --
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      --
      RETURN FALSE;
      --
END CHECK_RMS_BATCH;*/
END RIS_ORDS_LIBRARY;
/
