CREATE OR REPLACE PACKAGE        RIS_PROCESS_PO
IS
    STATUS0                 CONSTANT NUMBER         := 0;
    STATUS1                 CONSTANT NUMBER         := 1;
    STATUS2                 CONSTANT NUMBER         := 2;
    STATUS3                 CONSTANT NUMBER         := 3;
    STATUS4                 CONSTANT NUMBER         := 4;
    STATUS5                 CONSTANT NUMBER         := 5;
    STATUS6                 CONSTANT NUMBER         := 6;
    STATUS7                 CONSTANT NUMBER         := 7;
    STATUS8                 CONSTANT NUMBER         := 8;
    STATUS9                 CONSTANT NUMBER         := 9;
    STATUS10                CONSTANT NUMBER         := 10;
    DPO_CREATE              CONSTANT VARCHAR2(20)   := 'DPO_CREATE';
    DPO_UPDATE              CONSTANT VARCHAR2(20)   := 'DPO_UPDATE';
    DPO_CANCEL              CONSTANT VARCHAR2(20)   := 'DPO_CANCEL';
    DPO_COMPLETE            CONSTANT VARCHAR2(20)   := 'DPO_COMPLETE';
    DPO_DELETE              CONSTANT VARCHAR2(20)   := 'DPO_DELETE ';
    COMPLETE_STATUS         CONSTANT VARCHAR2(2)    := 'C';
    PROCESSED_STATUS        CONSTANT VARCHAR2(2)    := 'P';
    ERROR_STATUS            CONSTANT VARCHAR2(2)    := 'E';
    WEB_SERVICE_SUCCESS     CONSTANT VARCHAR2(2)    := 'W';
    WEB_SERVICE_ERROR       CONSTANT VARCHAR2(2)    := 'WE';
    COST_CHANGE_SUCCESS     CONSTANT VARCHAR2(2)    := 'S';
    COST_CHANGE_ERROR       CONSTANT VARCHAR2(2)    := 'SE';
    VALIDATED               CONSTANT VARCHAR2(2)    := 'V';
    VALIDATION_ERROR        CONSTANT VARCHAR2(2)    := 'VE';
    RIS_INBOUND_ERROR       CONSTANT VARCHAR2(2)    := 'IE';
    RIS_INBOUND_SUCCESS     CONSTANT VARCHAR2(2)    := 'I';
    NEW_STATUS              CONSTANT VARCHAR2(2)    := 'N';
    INPROGRESS_STATUS       CONSTANT VARCHAR2(2)    := 'I';
    DPO_DELETE_NEW_STATUS   CONSTANT VARCHAR2(2)    := 'DN';
    DPO_DELETE_ERROR_STATUS CONSTANT VARCHAR2(2)    := 'DE';
    DPO_DELETED             CONSTANT VARCHAR2(10)   := 'DELETED';
    DPO_CANCELLED           CONSTANT VARCHAR2(10)   := 'CANCELLED';

/* *********************************************************************************************************
* Function          : PROCESS_ORDER_WEBSERVICE
* Purpose           : Public function to call Order Webservice

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION PROCESS_ORDER_WEBSERVICE(O_error_message    IN OUT   VARCHAR2,
                                  I_message_id       IN       NUMBER)
    RETURN BOOLEAN;

/* *********************************************************************************************************
* Function          : PROCESS_ORDER
* Purpose           :

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION PROCESS_ORDER(O_error_message       IN OUT         VARCHAR2,
                       I_event_status        IN OUT         NUMBER,
                       I_event_id            IN             NUMBER)
    RETURN BOOLEAN;

/* *********************************************************************************************************
* Function          : PROCESS_DPO_DELETE
* Purpose           : process DPO_DELETE msgs in batch

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 06-MAY-2018   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION PROCESS_DPO_DELETE(O_error_message       IN OUT         VARCHAR2)
    RETURN BOOLEAN;

/* *********************************************************************************************************
* Function          : UPDATE_CURRENT_DPO_STATUS
* Purpose           : gets the latest DPO status from Repository and updates the staging table

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 05-MAY-2018   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION UPDATE_CURRENT_DPO_STATUS(O_error_message       IN OUT         VARCHAR2)
    RETURN BOOLEAN;


--following functions be used for unit testing only


FUNCTION INSERT_TO_STAGE(O_error_message       IN OUT         VARCHAR2,
                         O_po_hdr_msg_id       IN OUT         NUMBER,
                         O_rms_order_no        IN OUT         NUMBER,
                         I_event_id            IN             NUMBER)
    RETURN BOOLEAN;
FUNCTION POPULATE_RECORDS_FROM_RMS (O_error_message             IN OUT VARCHAR2,
                                    I_rms_order_no              IN     NUMBER,
                                    I_event_id                  IN     NUMBER,
                                    I_entity_id                 IN     VARCHAR2,
                                    I_update_resp_to_stage_flag IN     VARCHAR2 DEFAULT 'Y')
    RETURN BOOLEAN;

FUNCTION POPULATE_RECORDS_FROM_STAGE(O_error_message       IN OUT         VARCHAR2,
                                     I_message_id          IN             NUMBER,
                                     I_rms_order_no        IN             NUMBER,
                                     I_event_type          IN             VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN;

END RIS_PROCESS_PO;
/


CREATE OR REPLACE PACKAGE BODY                             RIS_PROCESS_PO
IS
    LP_instance_id                          NUMBER                      := 1;
    LP_message_family                       VARCHAR2(100)               := 'ORDER';
    LP_SYSDATE                              DATE                        := SYSDATE;
    LP_USER                                 VARCHAR2(100)               := USER;
    EVENT_STATUS_4_0        CONSTANT        NUMBER(10,2)                := 4.0;
    L_dbg_object            CONSTANT        debug_cfg.dbg_object%TYPE   := 'RIS_PROCESS_PO';
    LP_vdate                                DATE                        := GET_VDATE;
    CURSOR C_GET_ENTITY_HEADER(I_event_id NUMBER)
        IS
            SELECT message_id ,
                   message_type ,
                   legacy_order_no,
                   proc_status,
                   inbound_ref_id,
                   rms_order_no
              FROM ris_po_hdr_stage reh
             WHERE message_id = I_event_id
               AND message_type IN (RIS_INBOUND_EVENT_PROCESS.DPOCOMPLETE,RIS_INBOUND_EVENT_PROCESS.DPOCANCEL,RIS_INBOUND_EVENT_PROCESS.DPOCREATE,RIS_INBOUND_EVENT_PROCESS.DPOUPDATE, RIS_INBOUND_EVENT_PROCESS.DPODELETE);

    CURSOR C_GET_PO_XREF (I_entity_id VARCHAR2)
        IS
            SELECT xref.rms_ord_nbr
              FROM poorx_po_xref_t xref
             WHERE SUBSTR(I_entity_id,1,5) = xref.po_pfx_nbr
               AND SUBSTR(I_entity_id,6,1) = xref.po_dc_id
               AND SUBSTR(I_entity_id,7,1) = xref.po_dlvr_id;

   CURSOR C_GET_PO_XREF_CONV (I_entity_id VARCHAR2)
   IS
      SELECT xref.rms_ord_nbr
        FROM risxrf.poorx_po_xref_t xref
       WHERE SUBSTR(I_entity_id,1,5) = xref.po_pfx_nbr
         AND SUBSTR(I_entity_id,6,1) = xref.po_dc_id
         AND xref.po_dlvr_id        IS NULL;

   CURSOR C_GET_DEFAULTS
   IS
      SELECT rownum     rnum,
             attribute1 default_supp_country,
             attribute5 default_NAD_reset_days
        FROM intf_cnfg_parm_t
       WHERE pgm_nm = 'RIS_ITEM_INJECTOR'
         AND cd_nm  = 'DEFAULTS';

   L_default_rec     C_GET_DEFAULTS%ROWTYPE;

/* ******************************************************************************
* Procedure         : UPDATE_STATUS                                            *
* Purpose           : Update status to stage                                   *
*                                                                              *
* Author               Date                 Ver                                *
* -------  ---------  -----------------    ---------   ----------------------- *
* Sobu                23-FEB-2017          1.0                                 *
*******************************************************************************/
FUNCTION UPDATE_STATUS(O_error_message         IN OUT         VARCHAR2,
                       I_message_id            IN             NUMBER,
                       I_status                IN             VARCHAR2)
    RETURN BOOLEAN IS
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.UPDATE_STATUS';
    L_mark                 VARCHAR2(4000);
BEGIN
   --
   L_mark := 'Updating ris_po_hdr_stage';
    UPDATE ris_po_hdr_stage
        SET proc_status       = I_status,
            error_message     = O_error_message,
            lst_updt_user_id  = LP_USER,
            lst_updt_dttm     = sysdate
      WHERE inbound_ref_id    = I_message_id;
    --
    RETURN TRUE;
    --
EXCEPTION
   WHEN OTHERS
   THEN
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                           SQLERRM || '@ ' || L_mark,
                                           L_program_name,
                                           TO_CHAR(SQLCODE));
      RETURN FALSE;
END UPDATE_STATUS;

/* *********************************************************************************************************
* Function          : RIS_STAGE_STATUS_UPD
* Purpose           :

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION RIS_STAGE_STATUS_UPD(O_error_message       IN OUT         VARCHAR2,
                              I_message_id          IN             VARCHAR2,
                              I_status              IN             VARCHAR2 DEFAULT NULL,
                              I_message_type        IN             VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN
IS
    --
    L_program_name          VARCHAR2(1000)          :='RIS_PROCESS_PO.RIS_STAGE_STATUS_UPD';
    --
BEGIN
    --
    UPDATE ris_po_hdr_stage
       SET proc_status       = NVL(I_status,proc_status),
           error_message     = O_error_message,
           lst_updt_user_id  = LP_USER,
           lst_updt_dttm     = sysdate
     WHERE message_id        = I_message_id
       AND message_type      = NVL(I_message_type,message_type);
    --
    RETURN TRUE;
EXCEPTION
    WHEN OTHERS
    THEN
      O_error_message := SQL_LIB.CREATE_MSG ('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR (SQLCODE));

      RETURN FALSE;
END RIS_STAGE_STATUS_UPD;


/* **********************************************************************************************************************
* FUNCTION          :   GET_XOrderRef_REC
* PURPOSE           :   create "RIB_XOrderRef_REC" from order staging table
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS,              19-JAN-2017             1.0
************************************************************************************************************************/
FUNCTION GET_XOrderRef_REC(O_error_message                   IN OUT   VARCHAR2,
                           O_stage_order_object              OUT      "RIB_XOrderRef_REC",
                           I_message_id                      IN       NUMBER,
                           I_message_type                    IN       VARCHAR2
                          )
   RETURN BOOLEAN IS
    --
    L_program_name                  VARCHAR2(200)                               := 'GAP_RMS_ORDER_WEBSERVICE.GET_XOrderRef_REC';
    L_rib_business_obj              ris_message_inbound.business_object_id%TYPE;
    L_inbound_message_id            ris_message_inbound.message_id%TYPE;
    L_message_type                  ris_po_hdr_stage.message_type%TYPE;
    L_stage_order_object            "RIB_XOrderRef_REC";
    L_mark                          VARCHAR2(1000);
    --
    CURSOR C_DELETE_DETAIL
        IS
           SELECT "RIB_XOrderRef_REC"(1,
                                    hdr.rms_order_no,
                                    CAST(MULTISET(SELECT "RIB_XOrderDtlRef_REC"(1,
                                                                              item,
                                                                              location,
                                                                              NULL)
                                            FROM ris_po_dtl_stage dtl
                                           WHERE dtl.message_id   = hdr.message_id
                                             AND dtl.message_type = hdr.message_type)AS "RIB_XOrderDtlRef_TBL"),
                                    'RMS'
                                    )
            FROM ris_po_hdr_stage  hdr
           WHERE message_id     = I_message_id
             AND message_type   = I_message_type;
BEGIN
   --
     OPEN C_DELETE_DETAIL;
    FETCH C_DELETE_DETAIL INTO O_stage_order_object;
    CLOSE C_DELETE_DETAIL;
   RETURN TRUE;
   --
EXCEPTION
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END GET_XOrderRef_REC;

/* **********************************************************************************************************************
* FUNCTION          :   GET_XOrderDesc_REC
* PURPOSE           :   create "RIB_XOrderDesc_REC" from order staging table
* AUTHOR                DATE                 VER
* -------               -----------          ----  ------------------------------
* INFOSYS,              19-JAN-2017             1.0
************************************************************************************************************************/
FUNCTION GET_XOrderDesc_REC(O_error_message                   IN OUT   VARCHAR2,
                            O_stage_order_object              OUT      "RIB_XOrderDesc_REC",
                            I_message_id                      IN       NUMBER,
                            I_message_type                    IN       VARCHAR2
                            )

   RETURN BOOLEAN IS
    --
    L_program_name                  VARCHAR2(200)                               := 'GAP_RMS_ORDER_WEBSERVICE.GET_XOrderDesc_REC';
    L_mark                          VARCHAR2(1000);
    --
    CURSOR C_GET_PO_STAGE_HEADER
        IS
              SELECT "RIB_XOrderDesc_REC"(1,
                                        rms_order_no,
                                        supplier,
                                        currency_code,
                                        terms,
                                        CASE
                                           WHEN not_before_date <= LP_vdate
                                           THEN LP_vdate + 1
                                           ELSE not_before_date
                                        END, --not_before_date
                                        not_after_date,
                                        otb_eow_date,
                                        dept,
                                        DECODE(I_message_type,RIS_INBOUND_EVENT_PROCESS.DPOCOMPLETE,'C',RIS_INBOUND_EVENT_PROCESS.DPOCANCEL,'C',RIS_INBOUND_EVENT_PROCESS.DPODELETE,'C',status),
                                        exchange_rate,--exchange_rate_,
                                        include_on_ord_ind,--include_on_ord_ind_
                                        written_date,--written_date_
                                        CAST(MULTISET(SELECT "RIB_XOrderDtl_REC"(1,
                                                                               item,
                                                                               location,
                                                                               unit_cost,
                                                                               ref_item,--ref_item,
                                                                               NVL(L_default_rec.default_supp_country,origin_country_id), --pr8s9p2 confirm from abhijith
                                                                               supp_pack_size,--supp_pack_size
                                                                               quantity ,--qty_ordered,
                                                                               loc_type,--location_type,
                                                                               cancel_ind,--cancel_ind,
                                                                               reinstate_ind,--reinstate_ind_ ,
                                                                               delivery_date--delivery_date_ ,
                                                                               )--custFlexAttriVo_ TBL_OBJ_CUSTFLEXATTRIVO
                                                        FROM ris_po_dtl_stage dtl
                                                       WHERE dtl.message_id =  hdr.message_id AND dtl.message_type = hdr.message_type
                                                         AND ((I_message_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE AND quantity  > 0) OR (I_message_type <> RIS_INBOUND_EVENT_PROCESS.DPOCREATE )))AS "RIB_XOrderDtl_TBL"),
                                        NULL,--XORDSKUDTL_TBL                 RIB_XOrdSkuDtl_TBL
                                        orig_ind,--orig_ind_
                                        edi_po_ind,--edi_po_ind_
                                        pre_mark_ind,--pre_mark_ind_
                                        orig_approval_id,--user_id_
                                        comment_desc,--comment_desc_
                                        'RMS')--attempt_rms_load_
              FROM ris_po_hdr_stage hdr WHERE message_id  =  I_message_id AND message_type = I_message_type ;

BEGIN
   --
   L_mark := 'C_GET_PO_STAGE_HEADER';
     OPEN C_GET_PO_STAGE_HEADER;
    FETCH C_GET_PO_STAGE_HEADER INTO O_stage_order_object;
    CLOSE C_GET_PO_STAGE_HEADER;
   --
   RETURN TRUE;
   --

EXCEPTION
   WHEN OTHERS
   THEN
      O_error_message := 'PACKAGE_ERROR'|| SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK,1,3000) || '@' || L_mark || L_program_name;
      RETURN FALSE;
END GET_XOrderDesc_REC;


/* *********************************************************************************************************
* Function          : INSERT_RIS_INBOUND
* Purpose           : Insert order xml message to ris_message_inbound table

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION INSERT_RIS_INBOUND(O_error_message             IN OUT         VARCHAR2,
                            O_ris_message_id            IN OUT         NUMBER,
                            I_message_id                IN             VARCHAR2,
                            I_stage_message_type        IN             VARCHAR2,
                            I_rms_order_no              IN             NUMBER)
    RETURN BOOLEAN
IS
    --
    L_program_name              VARCHAR2(1000)          :='RIS_PROCESS_PO.INSERT_RIS_INBOUND';
    L_stage_order_ref_obj       "RIB_XOrderRef_REC";
    L_stage_order_desc_obj      "RIB_XOrderDesc_REC";
    L_rib_object                RIB_OBJECT;
    L_xml_payload               XMLTYPE;
    L_mark                      VARCHAR2(1000);
    L_rib_message_type          VARCHAR2(100) := CASE
                                                    WHEN I_stage_message_type IN( RIS_INBOUND_EVENT_PROCESS.DPOCREATE,RIS_INBOUND_EVENT_PROCESS.DPOUPDATE)
                                                    THEN RIS_BUILD_XML.LP_xorder_cre_type
                                                    WHEN I_stage_message_type IN ( RIS_INBOUND_EVENT_PROCESS.DPOCOMPLETE,RIS_INBOUND_EVENT_PROCESS.DPOCANCEL,RIS_INBOUND_EVENT_PROCESS.DPODELETE)
                                                    THEN RIS_BUILD_XML.LP_xorder_mod_type
                                                    ELSE I_stage_message_type
                                                  END;

    --
BEGIN
    --build the rib object for the message type
    IF I_stage_message_type = RIS_BUILD_XML.LP_xorder_dtl_del_type THEN
        --
        L_mark := 'CALL GET_XOrderRef_REC';
        --RIB_OrderRef_REC rib object for deleting the detail records
        IF GET_XOrderRef_REC(O_error_message,
                             L_stage_order_ref_obj,
                             I_message_id,
                             I_stage_message_type
                            ) = FALSE THEN
            RETURN FALSE;
        END IF;
        L_rib_object:= L_stage_order_ref_obj;
        --
    ELSE
    --
        L_mark := 'CALL GET_XOrderDesc_REC';
        ----RIB_OrderDesc_REC rib object for actions other than line detail delete
        IF GET_XOrderDesc_REC(O_error_message,
                              L_stage_order_desc_obj,
                              I_message_id,
                              I_stage_message_type
                              ) = FALSE THEN
            RETURN FALSE;
        END IF;
        L_rib_object:= L_stage_order_desc_obj;
    --
    END IF;
    --
    L_mark := 'CALL RIS_BUILD_XML.BUILD';
    --build the XML message for ris_message_inbound
    IF RIS_BUILD_XML.BUILD(O_error_message,
                           L_xml_payload,
                           L_rib_object,
                           L_rib_message_type)   = FALSE THEN
        RETURN FALSE;
    END IF;
    --
    -- Insert input message into RIS Inbound table for processing
    L_mark := 'Call : RIS_CONSUMER_SERVICE.INSERT_RIS_INBOUND';
    --
    IF NOT RIS_CONSUMER_SERVICE.INSERT_RIS_INBOUND( O_error_message,                        -- error_message
                                                    RIS_BUILD_XML.LP_xorder_family,         -- family
                                                    L_rib_message_type,                     -- message_type
                                                    I_rms_order_no,                         -- business_object_id
                                                    L_xml_payload,                          -- xml_payload
                                                    NULL,                                   -- raw_payload
                                                    LP_instance_id,                         -- instance_id
                                                    O_ris_message_id,                       -- ris_message_id
                                                    'RIS_PROCESS_PO'
                                                )
    THEN
        RETURN FALSE;
    END IF;
    --
    L_mark := 'Update inbound ref ID in ris_app_export_routing';
    --
    --update the staging table with the message id of the ris_message_inbound data
    UPDATE ris_po_hdr_stage
       SET inbound_ref_id   = O_ris_message_id,
           lst_updt_dttm    = sysdate,
           lst_updt_user_id = LP_USER
     WHERE message_id       = I_message_id
       AND message_type     = I_stage_message_type;
    --
    RETURN TRUE;
    --
EXCEPTION
    WHEN OTHERS
    THEN
      O_error_message := SQL_LIB.CREATE_MSG ('PACKAGE_ERROR',
                                            SQLERRM,
                                            L_program_name,
                                            TO_CHAR (SQLCODE));

      RETURN FALSE;
END INSERT_RIS_INBOUND;

/* *********************************************************************************************************
* Function          : VALIDATE_STAGE_RECORDS
* Purpose           : validate order staging records

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/

FUNCTION VALIDATE_STAGE_RECORDS(O_error_message       IN OUT         VARCHAR2,
                                IO_proc_status        IN OUT         VARCHAR2,
                                I_po_hdr_msg_id       IN             NUMBER,
                                I_message_type        IN             VARCHAR2)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name          VARCHAR2(200)        := 'RIS_PROCESS_PO.VALIDATE_STAGE_RECORDS';
    L_val                   VARCHAR2(300);
    L_vdate                 DATE;
    VALID_ORD               EXCEPTION;
    L_mark                  VARCHAR2(200);
    l_exists                NUMBER;

    --
    CURSOR C_GET_VDATE
        IS
            SELECT vdate FROM das_wv_period;

    CURSOR C_VALIDATE_PO
        IS
            WITH loc AS (SELECT wh  location     FROM das_wv_wh    WHERE physical_wh    <>  wh
                            UNION
                         SELECT store location FROM das_wv_store WHERE L_vdate BETWEEN store_open_date AND NVL(store_close_date,L_vdate)
                        ),
             dtl_loc AS (SELECT distinct dtl.location  location
                           FROM ris_po_dtl_stage dtl
                          WHERE NOT EXISTS (SELECT 1 FROM loc WHERE loc.location = dtl.location)
                            AND message_id     = I_po_hdr_msg_id
                            AND message_type   = I_message_type
                        )
              SELECT * FROM (SELECT CASE
                                         WHEN stg.legacy_order_no IS NULL
                                         THEN '@LEGACY_ORDER_NO_CANNOT_BE_BLANK@'
                                         WHEN NOT EXISTS (SELECT 1
                                                            FROM das_wv_sups sups
                                                           WHERE sups.supplier     = stg.supplier
                                                             AND sups.sup_status   = 'A')
                                         THEN '@INVALID_SUPPLIER@'||stg.supplier
                                         WHEN NOT EXISTS (SELECT 1
                                                            FROM das_wv_terms_head trm
                                                           WHERE trm.terms = stg.terms)
                                         THEN '@INVALID_TERMS@'||stg.terms
                                         WHEN NOT EXISTS (SELECT 1
                                                            FROM das_wv_deps deps
                                                           WHERE deps.dept = stg.dept)
                                         THEN '@INVALID_DEPT@'||stg.dept
                                        /*  WHEN not_before_date  <= L_vdate
                                         THEN '@INVALID_NOT_BEFORE_DATE@'||not_before_date
                                         WHEN not_after_date  <= L_vdate
                                         THEN '@INVALID_NOT_AFTER_DATE@'||not_after_date */
                                         /* WHEN not_after_date < not_before_date
                                         THEN 'NOT AFTER DATE SHOULD ALWAYS BE GREATER THAN NOT BEFORE DATE' */
                                         WHEN I_message_type=RIS_INBOUND_EVENT_PROCESS.DPOUPDATE AND (otb_eow_date <= L_vdate OR otb_eow_date < not_after_date)
                                         THEN '@END_OF_WEEK_DATE_SHOULD_BE_GREATER_THAN_NOT_AFTER_DATE_AND_SHOULD_ALWAYS_BE_IN_FUTURE@'
                                         WHEN  EXISTS (SELECT 1
                                                         FROM dtl_loc
                                                         )
                                         THEN '@INVALID_LOCATION@'||(SELECT LISTAGG(location, ', ') WITHIN GROUP (ORDER BY location) "LIST" FROM dtl_loc)
                                         WHEN I_message_type=RIS_INBOUND_EVENT_PROCESS.DPOCREATE AND NOT EXISTS (SELECT 1
                                                                                                                   FROM ris_po_dtl_stage dtl
                                                                                                                  WHERE message_id      = stg.message_id
                                                                                                                    AND message_type    = stg.message_type
                                                                                                                    AND NVl(quantity,0) > 0)
                                         THEN '@ORDER_NOT_PROCESSED_DUE_TO_NO_DETAILS@'
                                     END error_message
                               FROM ris_po_hdr_stage stg
                              WHERE message_id     = I_po_hdr_msg_id
                                AND message_type   = I_message_type
                                AND stg.proc_status     IN (NEW_STATUS,VALIDATION_ERROR) )
                      WHERE error_message IS NOT NULL;


BEGIN
    --
     OPEN C_GET_VDATE;
    FETCH C_GET_VDATE INTO L_vdate;
    CLOSE C_GET_VDATE;
    --
    --
     OPEN C_VALIDATE_PO;
    FETCH C_VALIDATE_PO INTO O_error_message;
    CLOSE C_VALIDATE_PO;
    --

    IF  O_error_message LIKE '%ORDER_NOT_PROCESSED_DUE_TO_NO_DETAILS%' THEN
        IO_proc_status := RIS_LIBRARY.STATUS_COMPLETE;
    ELSIF O_error_message IS NOT NULL THEN
        IO_proc_status := VALIDATION_ERROR;
        RETURN FALSE;
    ELSE
        IO_proc_status := VALIDATED;
    END IF;
    --
    RETURN TRUE;
EXCEPTION
   WHEN VALID_ORD THEN
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            L_val,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END VALIDATE_STAGE_RECORDS;



/* *********************************************************************************************************
* Function          : POPULATE_RECORDS_FROM_RMS
* Purpose           :

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 22-Aug-2017   0.0    Infosys                 Initial Version
*
***********************************************************************************************************/
FUNCTION POPULATE_RECORDS_FROM_RMS (O_error_message             IN OUT VARCHAR2,
                                    I_rms_order_no              IN     NUMBER,
                                    I_event_id                  IN     NUMBER,
                                    I_entity_id                 IN     VARCHAR2,
                                    I_update_resp_to_stage_flag IN     VARCHAR2 DEFAULT 'Y')
    RETURN BOOLEAN
IS
    --
    L_program_name       VARCHAR2 (1000)                                    := 'RIS_PROCESS_PO.POPULATE_RECORDS_FROM_RMS';
    L_response           CLOB;
    L_user               VARCHAR2 (25)                                      := NULL;
    L_password           VARCHAR2 (25)                                      := NULL;
    L_wallet_path        VARCHAR2 (25)                                      := NULL;
    L_wallet_pwd         VARCHAR2 (25)                                      := NULL;
    L_retcode            VARCHAR2(4000);
    L_retmessage         VARCHAR2(4000);
    L_url                VARCHAR2(4000);
    L_message_type       VARCHAR2(100)                                      := 'ORDER';
    L_mark               VARCHAR2(500)                                      := 'DECLARE' ;
    L_order_arr          JSON_ARRAY_T;
    L_first_item         JSON_ELEMENT_T;
    L_order_obj          JSON_OBJECT_T;
    L_order_id           das_wv_ordhead.order_no%TYPE := NULL;
    --
BEGIN
   --
   L_mark := 'DELETE ris_po_hdr_rms_gtt';
   --
   DELETE ris_po_hdr_rms_gtt WHERE message_id = I_event_id;
   DELETE ris_po_dtl_rms_gtt WHERE message_id = I_event_id;
   --
   L_mark := 'UPDATE REST service call start time';
   --
   UPDATE ris_po_hdr_stage
      SET service_call_start_time         = SYSTIMESTAMP
    WHERE message_id                      = I_event_id
      AND I_update_resp_to_stage_flag     = 'Y';
   --
   -- call the webs service to check id the order exists in rms
   L_mark := 'CALL RIS_APEX_SERVICE.GET_REST_RESPONSE';
    IF RIS_APEX_SERVICE.GET_REST_RESPONSE(O_error_message,
                                          L_response,
                                          I_rms_order_no,
                                          RIS_APEX_SERVICE.APEX_GET_SERVICE,
                                          LP_instance_id,
                                          L_message_type,
                                          LP_message_family) = FALSE
    THEN
        O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                              O_error_message,
                                              L_program_name,
                                              NULL);
        RETURN FALSE;
    END IF;
    --
   DBG_SQL.MSG(L_dbg_object,I_event_id||':L_response='||SUBSTR(L_response,1,3550));
    /*IF UPPER(SUBSTR(L_response,1,4000)) like '%REQUEST%FAILED%' THEN
        L_mark := '%REQUEST%FAILED%';
        RETURN TRUE;
    ELSIF UPPER(SUBSTR(L_response,1,4000)) like '%NOT%FOUND%' THEN
        L_mark := '%NOT%FOUND%';
        O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                              'JSON RESPONSE RETRIEVAL UNSUCCESSFUL FOR RMS ORDER:'||I_rms_order_no||' ERROR:'||SUBSTR(L_response,1,4000),
                                              L_program_name,
                                              NULL);
        RETURN FALSE;
    END IF;
    */
    --check if the response is json or xml
    L_mark := 'CHECK_JSON_IN_RESPONSE';
    IF RIS_APEX_SERVICE.CHECK_JSON_IN_RESPONSE(O_error_message,
                                               L_response) = FALSE THEN
       O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                              'JSON RESPONSE RETRIEVAL UNSUCCESSFUL FOR RMS ORDER:'||I_rms_order_no||' ERROR:'||O_error_message,
                                              L_program_name,
                                              NULL);
        RETURN FALSE;

    END IF;
    /*
    --check if the response has  orderNo element populated
    L_mark := 'APEX_JSON.get_varchar2';
    IF APEX_JSON.get_varchar2(p_path=>'[%d].orderNo',p0 => 1) IS  NULL THEN
       O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                              'ORDER NUMBER NOT FOUND IN RESPONSE FOR order='||I_rms_order_no,
                                              L_program_name,
                                              NULL);
        RETURN FALSE;
    END IF;
    --
    */
    /*L_mark := 'Validate whether the order exists in the response';
    L_order_arr := JSON_ARRAY_T(L_response);
    FOR j IN 1..L_order_arr.GET_SIZE()
    LOOP
       L_first_item := L_order_arr.get(j-1);
       L_order_obj  := JSON_OBJECT_T(L_first_item);
       L_order_id   := L_order_obj.get_string('orderNo');
       IF L_order_id IS NULL THEN
            RETURN TRUE;
       END IF;
    END LOOP;*/

    BEGIN
       L_mark := 'Validate whether the item exists in the response';
       L_order_arr := JSON_ARRAY_T(L_response);
       FOR j IN 1..L_order_arr.GET_SIZE()
       LOOP
          L_first_item := L_order_arr.get(j-1);
          L_order_obj := JSON_OBJECT_T(L_first_item);
          L_order_id := L_order_obj.get_string('orderNo');
          IF L_order_id IS  NULL THEN
             DBG_SQL.MSG(L_dbg_object,I_event_id||':'||L_program_name||' RESPONSE FOR RMS ORDER='||I_rms_order_no||' '||SUBSTR(L_response,1,3500));
             RETURN TRUE;
          END IF;
          --
          UPDATE ris_po_hdr_stage
             SET oracle_rest_response           = L_response,
                 service_call_end_time          = SYSTIMESTAMP
           WHERE message_id                     = I_event_id
             AND I_update_resp_to_stage_flag    = 'Y';
       END LOOP;
    EXCEPTION
    WHEN OTHERS
    THEN
       RETURN TRUE;
    END;
    --
    L_mark := 'INSERT ris_po_hdr_rms_gtt';
    INSERT
        INTO ris_po_hdr_rms_gtt(message_id       ,
                                order_no         ,
                                legacy_order_no  ,
                                supplier         ,
                                currency_code    ,
                                terms            ,
                                not_before_date  ,
                                not_after_date   ,
                                dept             ,
                                status           ,
                                --exchange_rate    ,
                                written_date     ,
                                orig_ind         ,
                               --edi_po_ind       ,
                               --pre_mark_ind     ,
                               --orig_approval_id ,
                               --comment_desc     ,
                                crt_updt_dttm    ,
                                crt_updt_user_id ,
                                lst_updt_dttm    ,
                                lst_updt_user_id ,
                                proc_status)
                         SELECT I_event_id,
                                order_no       ,
                                I_entity_id    ,
                                supplier       ,
                                currency_code  ,
                                terms          ,
                                TRUNC(to_date('19700101', 'YYYYMMDD') + ( 1 / 24 / 60 / 60 / 1000) * not_before_date),
                                TRUNC(to_date('19700101', 'YYYYMMDD') + ( 1 / 24 / 60 / 60 / 1000) * not_after_date),
                                dept           ,
                                status         ,
                                --exchange_rate  ,
                                TRUNC(to_date('19700101', 'YYYYMMDD') + ( 1 / 24 / 60 / 60 / 1000) * written_date)    ,
                                orig_ind       ,
                                --edi_po_ind     ,
                                --pre_mark_ind   ,
                                --user_id        ,
                                --comment_desc,
                                sysdate,
                                LP_USER,
                                sysdate,
                                LP_USER,
                                NEW_STATUS
                           FROM JSON_TABLE(L_response, '$[*]' COLUMNS ( order_no          NUMBER              PATH '$.orderNo' ,
                                                                        supplier          NUMBER              PATH '$.supplier',
                                                                        currency_code     VARCHAR2(200 CHAR)  PATH '$.currencyCode',
                                                                        terms             VARCHAR2(200 CHAR)  PATH '$.terms',
                                                                        not_before_date   VARCHAR2(200 CHAR)  PATH '$.notBeforeDate',
                                                                        not_after_date    VARCHAR2(200 CHAR)  PATH '$.notAfterDate',
                                                                        dept              NUMBER              PATH '$.dept',
                                                                        status            VARCHAR2(200 CHAR)  PATH '$.status',
                                                                        written_date      VARCHAR2(200 CHAR)  PATH '$.writtenDate',
                                                                        orig_ind          VARCHAR2(200 CHAR)  PATH '$.origInd'
                                                                        ));
    DBG_SQL.MSG(L_dbg_object,I_event_id||':ris_po_hdr_rms_gtt insert rowcount='||SQL%ROWCOUNT);
    --
    L_mark := 'INSERT ris_po_dtl_rms_gtt';
    INSERT
        INTO ris_po_dtl_rms_gtt(message_id    ,
                                order_no      ,
                                item          ,
                                location      ,
                                unit_cost     ,
                                ref_item      ,
                                quantity      ,
                                qty_ordered   ,
                                qty_cancelled ,
                                qty_received  ,
                                loc_type      ,
                                estimate_instock_date,
                                origin_country_id,
                                crt_updt_dttm    ,
                                crt_updt_user_id ,
                                lst_updt_dttm    ,
                                lst_updt_user_id   )
                         SELECT I_event_id,
                                I_rms_order_no,
                                ol.item          ,
                                location,
                                unit_cost     ,
                                ref_item          ,
                                DECODE((SELECT status FROM ris_po_hdr_rms_gtt WHERE message_id = I_event_id),RIS_LIBRARY.STATUS_COMPLETE,qty_ordered+NVL(qty_cancelled,0),qty_ordered ) quantity   ,
                                NVL(qty_ordered,0),
                                NVL(qty_cancelled,0),
                                NVL(qty_received,0),
                                location_type ,
                                TRUNC(to_date('19700101', 'YYYYMMDD') + ( 1 / 24 / 60 / 60 / 1000) * estimated_instock_date),
                                origin_country_id,
                                sysdate,
                                LP_USER,
                                sysdate,
                                LP_USER
                           FROM JSON_TABLE(L_response, '$[*].poItemTbl[*]' COLUMNS ( item            VARCHAR2(200 CHAR)  PATH '$.item',
                                                                                     location        NUMBER              PATH '$.location',
                                                                                     unit_cost       NUMBER(10,4)        PATH '$.unitCost',
                                                                                     ref_item        VARCHAR2(200 CHAR)  PATH '$.refItem',
                                                                                     qty_ordered     NUMBER(10,4)        PATH '$.qtyOrdered',
                                                                                     qty_cancelled   NUMBER(10,4)        PATH '$.qtyCancelled',
                                                                                     qty_Received    NUMBER(10,4)        PATH '$.qtyReceived',
                                                                                     location_type   VARCHAR2(1)         PATH '$.locType',
                                                                                     estimated_instock_date   VARCHAR2(200 CHAR)  PATH '$.estimatedInstockDate',
                                                                                     origin_country_id            VARCHAR2(200 CHAR)  PATH '$.originCountryId') ) ol;
     DBG_SQL.MSG(L_dbg_object,I_event_id||':ris_po_dtl_rms_gtt insert rowcount='||SQL%ROWCOUNT);
     --
     RETURN TRUE;
     --
EXCEPTION
    WHEN OTHERS
    THEN
        --
        O_error_message := SQL_LIB.CREATE_MSG ('PACKAGE_ERROR',
                                             SQLERRM|| '@' || L_mark,
                                             L_program_name,
                                             TO_CHAR (SQLCODE));
      RETURN FALSE;
END POPULATE_RECORDS_FROM_RMS;

/* *********************************************************************************************************
* Function          : INSERT_TO_STAGE
* Purpose           : For testing purpose only

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/

FUNCTION INSERT_TO_STAGE(O_error_message       IN OUT         VARCHAR2,
                         O_po_hdr_msg_id       IN OUT         NUMBER,
                         O_rms_order_no        IN OUT         NUMBER,
                         I_event_id            IN             NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.INSERT_TO_STAGE';
    L_mark                 VARCHAR2(200);
    I_json_data            CLOB;
    L_message_type         ris_po_hdr_stage.message_type%TYPE;
    CURSOR C_GET_PO_JSON
        IS
            SELECT JSON_DATA,event_type
              FROM ris_event_header
             WHERE event_id =   I_event_id;

BEGIN
    --
     OPEN C_GET_PO_JSON;
    FETCH C_GET_PO_JSON INTO  I_json_data,L_message_type;
    CLOSE C_GET_PO_JSON;

    O_po_hdr_msg_id := NVL(O_po_hdr_msg_id,GAP_ORDER_MSG_ID_SEQ.NEXTVAL);
    O_rms_order_no  := NVL(O_rms_order_no,gap_order_seq.NEXTVAL);
    L_mark:=  'RIS_PO_HDR_STAGE';

     INSERT INTO ris_po_hdr_stage (event_id,
                                   message_id          ,
                                   message_type        ,
                                   legacy_order_no     ,
                                   currency_code       ,
                                   supplier            ,
                                   dept                ,
                                   not_before_date     ,
                                   not_after_date      ,
                                   otb_eow_date        ,
                                   pickup_date         ,
                                   purchase_type       ,
                                   ship_method         ,
                                   ship_pay_method     ,
                                   freight_terms       ,
                                   agent               ,
                                   fob_trans_res       ,
                                   fob_trans_res_desc  ,
                                   fob_title_pass      ,
                                   fob_title_pass_desc ,
                                   lading_port         ,
                                   discharge_port      ,
                                   buyer_id            ,
                                   status              ,
                                   terms               ,
                                   duty_rate           ,
                                   orig_approval_id    ,
                                   freight_comp_id     ,
                                   comment_desc        ,
                                   run_id              ,
                                   chunk_id            ,
                                   proc_status         ,
                                   error_message       ,
                                   crt_updt_dttm       ,
                                   crt_updt_user_id    ,
                                   lst_updt_dttm       ,
                                   lst_updt_user_id    )
                            SELECT I_event_id,
                                   I_event_id,
                                   L_message_type,
                                   order_Number,
                                   currency_code,
                                   supplier,
                                   dept,
                                   TO_DATE(not_before_date,'YYYY-MM-DD'),
                                   TO_DATE(not_after_date,'YYYY-MM-DD'),
                                   NULL,
                                   TO_DATE(earliest_ship_date,'YYYY-MM-DD'),
                                   purchase_type,
                                   ship_method,
                                   NULL,
                                   freight_terms,
                                   agent,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   'A',
                                   terms,
                                   NULL,
                                   LP_USER,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL
                              FROM JSON_TABLE(I_json_data, '$[*]'
                                              COLUMNS ( order_Number            VARCHAR2(200 CHAR) PATH '$.orderNumber' ,
                                                        po_Type                 VARCHAR2(200 CHAR) PATH '$.poType',
                                                        order_Type              VARCHAR2(200 CHAR) PATH '$.orderType',
                                                        created_Date            VARCHAR2(200 CHAR) PATH '$.createdDate',
                                                        supplier                VARCHAR2(200 CHAR) PATH '$.manufacturingVendor.number',
                                                        dept                    VARCHAR2(200 CHAR) PATH '$.merchandiseHierarchy.universalHierarchy.departmentNumber',
                                                        not_before_date         VARCHAR2(200 CHAR) PATH '$.deliveryDates.doNotShipBeforeDate',
                                                        not_after_date          VARCHAR2(200 CHAR) PATH '$.deliveryDates.shipCancelDate',
                                                        earliest_ship_date      VARCHAR2(200 CHAR) PATH '$.deliveryDates.doNotShipBeforeDate',
                                                        latest_ship_date        VARCHAR2(200 CHAR) PATH '$.deliveryDates.shipCancelDate',
                                                        terms                   VARCHAR2(200 CHAR) PATH '$.paymentInformation.paymentTerm',
                                                        freight_terms           VARCHAR2(200 CHAR) PATH '$.paymentInformation.freightPaidBy',
                                                        payment_method          VARCHAR2(200 CHAR) PATH '$.paymentInformation.paymentMethod',
                                                        ship_method             VARCHAR2(200 CHAR) PATH '$.shippingInfo.shipMethod',
                                                        purchase_type           VARCHAR2(200 CHAR) PATH '$.paymentInformation.termOfSale',
                                                        orig_approval_date      VARCHAR2(200 CHAR) PATH '$.createdDate',
                                                        import_country_id       VARCHAR2(200 CHAR) PATH '$.shippingInfo.destination.countryCode',
                                                        orig_country_code       VARCHAR2(200 CHAR) PATH '$.shippingInfo.origin.countryCode',
                                                        agent                   VARCHAR2(200 CHAR) PATH '$.agent.number' ,
                                                        currency_code           VARCHAR2(200 CHAR) PATH '$.style.avgFirstCost.currency'
                                                      )
                                             ) jt;

     L_mark:=  'RIS_PO_DTL_STAGE';

     INSERT INTO RIS_PO_DTL_STAGE (event_id              ,
                                   message_id            ,
                                   message_type          ,
                                   item                  ,
                                   location              ,
                                   loc_type              ,
                                   --order_no              ,
                                   estimate_instock_date ,
                                   origin_country_id     ,
                                   unit_cost             ,
                                   quantity              ,
                                   crt_updt_dttm         ,
                                   crt_updt_user_id      ,
                                   lst_updt_dttm         ,
                                   lst_updt_user_id)

         WITH loc AS (SELECT wh location, physical_wh physical_location   FROM das_wv_wh WHERE stockholding_ind='Y'
                       UNION
                      SELECT store location, store physical_location FROM das_wv_store
                     ),
              SKUS AS (SELECT *
                         FROM JSON_TABLE(I_json_data, '$[*]'
                                         COLUMNS ( order_Number            VARCHAR2(200 CHAR) PATH '$.orderNumber' , --reqd
                                                   origin_country_id       VARCHAR2(200 CHAR) PATH '$.shippingInfo.origin.countryCode',--reqd
                                                   loc                     VARCHAR2(200 CHAR) PATH '$.shippingInfo.destination.locationNumber', --reqd
                                                   loc_type                VARCHAR2(200 CHAR) PATH '$.shippingInfo.destination.locationType',   --reqd
                                                   estimate_instock_date   VARCHAR2(200 CHAR) PATH '$.deliveryDates.deliveryDate', --reqd
                                                   NESTED PATH '$.skus[*]' COLUMNS (item               VARCHAR2(200 CHAR) PATH '$.universalSkuNumber',
                                                                                    sku_qty            VARCHAR2(200 CHAR) PATH '$.size.unitsInBulk',
                                                                                    cc_number          VARCHAR2(200 CHAR) PATH '$.universalCustomerChoiceNumber'
                                                                                    ),
                                                   NESTED PATH '$.prepacks[*]' COLUMNS (prepack        VARCHAR2(200 CHAR) PATH '$.prepackNumber',
                                                                                        ppk_qty        VARCHAR2(200 CHAR) PATH '$.quantity'
                                                                                        )
                                                 )
                                       ) AS "JT",loc
                        WHERE DECODE(TO_NUMBER(JT.loc),20,30) = loc.physical_location
                      ),
                CC AS (SELECT jt.*
                         FROM JSON_TABLE(I_json_data, '$[*]'
                                         COLUMNS (
                                                   NESTED PATH '$.customerChoices[*]' COLUMNS (NESTED PATH '$.customerChoice.retailTicketPrices[*]'
                                                                                                               COLUMNS (unit_retail   VARCHAR2(200 CHAR) PATH '$.value'),
                                                                                               unit_cost       VARCHAR2(200 CHAR) PATH '$.customerChoice.estimatedLandedCost.value',
                                                                                               unit_cost_init  VARCHAR2(200 CHAR) PATH '$.customerChoice.estimatedLandedCost.value',
                                                                                               cc_number varchar2(200) PATH '$.customerChoice.universalCustomerChoiceNumber'
                                                                                               )
                                                 )
                                        ) AS "JT"
                      )
                      SELECT I_event_id,
                             I_event_id,
                             L_message_type,
                             NVL(item,prepack),
                             location,
                             DECODE(loc_type,'DC','W'),
                             --O_rms_order_no,
                             TO_DATE(estimate_instock_date,'YYYY-MM-DD'),
                             origin_country_id,
                             unit_cost,
                             NVL(sku_qty,ppk_qty),
                             sysdate,
                             LP_USER,
                             sysdate,
                             LP_USER
                        FROM SKUS,CC
                       WHERE SKUS.cc_number=CC.cc_number(+);

    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END INSERT_TO_STAGE;

/* *********************************************************************************************************
* Function          : POPULATE_RECORDS_FROM_STAGE
* Purpose           : populate gtts table for records from staging table

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION POPULATE_RECORDS_FROM_STAGE(O_error_message       IN OUT         VARCHAR2,
                                     I_message_id          IN             NUMBER,
                                     I_rms_order_no        IN             NUMBER,
                                     I_event_type          IN             VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.POPULATE_RECORDS_FROM_STAGE';
    L_object_response      VARCHAR2(4000);
    L_mark                 VARCHAR2(200);
    --
BEGIN
    --
    DELETE ris_po_hdr_stage_gtt WHERE message_id = I_message_id;
    DELETE ris_po_dtl_stage_gtt WHERE message_id = I_message_id;
    INSERT
        INTO ris_po_hdr_stage_gtt(message_id         ,
                                  order_no           ,
                                  legacy_order_no    ,
                                  currency_code      ,
                                  supplier           ,
                                  dept               ,
                                  not_before_date    ,
                                  not_after_date     ,
                                  otb_eow_date       ,
                                  pickup_date        ,
                                  purchase_type      ,
                                  ship_method        ,
                                  ship_pay_method    ,
                                  freight_terms      ,
                                  agent              ,
                                  fob_trans_res      ,
                                  fob_trans_res_desc ,
                                  fob_title_pass     ,
                                  fob_title_pass_desc,
                                  lading_port        ,
                                  discharge_port     ,
                                  buyer_id           ,
                                  status             ,
                                  terms              ,
                                  duty_rate          ,
                                  orig_approval_id   ,
                                  freight_comp_id    ,
                                  comment_desc       ,
                                  inbound_ref_id     ,
                                  run_id             ,
                                  chunk_id           ,
                                  proc_status        ,
                                  parent_message_id  ,
                                  message_type       ,
                                  event_inbound_message_type,
                                  include_on_ord_ind ,
                                  written_date       ,
                                  orig_ind           ,
                                  edi_po_ind         ,
                                  pre_mark_ind       ,
                                  exchange_rate      ,
                                  error_message      ,
                                  crt_updt_dttm      ,
                                  crt_updt_user_id   ,
                                  lst_updt_dttm      ,
                                  lst_updt_user_id)
                           SELECT hdr.message_id         ,
                                  rms_order_no       ,
                                  legacy_order_no    ,
                                  currency_code      ,
                                  supplier           ,
                                  dept               ,
                                  not_before_date    ,
                                  not_after_date     ,
                                  otb_eow_date       ,
                                  pickup_date        ,
                                  purchase_type      ,
                                  ship_method        ,
                                  ship_pay_method    ,
                                  freight_terms      ,
                                  agent              ,
                                  fob_trans_res      ,
                                  fob_trans_res_desc ,
                                  fob_title_pass     ,
                                  fob_title_pass_desc,
                                  lading_port        ,
                                  discharge_port     ,
                                  buyer_id           ,
                                  hdr.status             ,
                                  terms              ,
                                  duty_rate          ,
                                  orig_approval_id   ,
                                  freight_comp_id    ,
                                  comment_desc       ,
                                  inbound_ref_id     ,
                                  hdr.run_id             ,
                                  chunk_id           ,
                                  proc_status        ,
                                  parent_message_id  ,
                                  hdr.message_type   ,
                                  rei.message_type   ,
                                  include_on_ord_ind ,
                                  written_date       ,
                                  orig_ind           ,
                                  edi_po_ind         ,
                                  pre_mark_ind       ,
                                  exchange_rate      ,
                                  error_message      ,
                                  sysdate            ,
                                  LP_USER            ,
                                  sysdate            ,
                                  LP_USER
                             FROM ris_po_hdr_stage hdr,
                                  ris_event_inbound rei
                            WHERE hdr.message_id     =  I_message_id
                              AND hdr.message_type   =  NVL(I_event_type,hdr.message_type)
                              AND hdr.message_id =  rei.message_id;
    DBG_SQL.MSG(L_dbg_object,I_message_id||':ris_po_hdr_stage_gtt insert rowcount='||SQL%ROWCOUNT);
    --
    INSERT
        INTO ris_po_dtl_stage_gtt(message_id            ,
                                  item                  ,
                                  location              ,
                                  loc_type              ,
                                  order_no              ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  ref_item              ,
                                  crt_updt_dttm         ,
                                  crt_updt_user_id      ,
                                  lst_updt_dttm         ,
                                  lst_updt_user_id)
                           SELECT message_id            ,
                                  item                  ,
                                  location              ,
                                  loc_type              ,
                                  I_rms_order_no        ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  ref_item              ,
                                  sysdate               ,
                                  LP_USER               ,
                                  sysdate               ,
                                  LP_USER
                             FROM ris_po_dtl_stage stg
                            WHERE message_id     =  I_message_id
                              AND message_type   =  NVL(I_event_type,message_type)
                              AND ((I_event_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE AND quantity  > 0)
                                    OR
                                   (quantity  > 0 OR (EXISTS (SELECT 1
                                                                FROM ris_po_dtl_rms_gtt rms
                                                               WHERE rms.message_id =   I_message_id
                                                                 AND rms.item       =   stg.item
                                                                 AND rms.location   =   stg.location
                                                             )
                                                      )
                                   )
                                  );
    DBG_SQL.MSG(L_dbg_object,I_message_id||':ris_po_dtl_stage_gtt insert rowcount='||SQL%ROWCOUNT);
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END POPULATE_RECORDS_FROM_STAGE;


/* *********************************************************************************************************
* Function          : INSERT_MODIFY_HDR_TO_STAGE
* Purpose           : hdr mod

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION INSERT_MODIFY_HDR_TO_STAGE(O_error_message          IN OUT         VARCHAR2,
                                    I_event_id               IN             NUMBER,
                                    I_xref_rms_ord_nbr       IN             NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name          VARCHAR2(200)           := 'RIS_PROCESS_PO.INSERT_MODIFY_HDR_TO_STAGE';
    L_mark                  VARCHAR2(200);
    L_ris_message_id        ris_message_inbound.message_id%TYPE;
    L_row_count             NUMBER;

    --
BEGIN
    --insert to stage for  records that qualify for hdr mod
    INSERT INTO ris_po_hdr_stage (event_id            ,
                                  message_id          ,
                                  rms_order_no        ,
                                  legacy_order_no     ,
                                  currency_code       ,
                                  supplier            ,
                                  dept                ,
                                  not_before_date     ,
                                  not_after_date      ,
                                  otb_eow_date        ,
                                  pickup_date         ,
                                  purchase_type       ,
                                  ship_method         ,
                                  ship_pay_method     ,
                                  freight_terms       ,
                                  agent               ,
                                  fob_trans_res       ,
                                  fob_trans_res_desc  ,
                                  fob_title_pass      ,
                                  fob_title_pass_desc ,
                                  lading_port         ,
                                  discharge_port      ,
                                  buyer_id            ,
                                  status              ,
                                  terms               ,
                                  duty_rate           ,
                                  orig_approval_id    ,
                                  freight_comp_id     ,
                                  comment_desc        ,
                                  inbound_ref_id      ,
                                  run_id              ,
                                  chunk_id            ,
                                  proc_status         ,
                                  error_message       ,
                                  crt_updt_dttm       ,
                                  crt_updt_user_id    ,
                                  lst_updt_dttm       ,
                                  lst_updt_user_id    ,
                                  message_type,
                                  parent_message_id,
                                  include_on_ord_ind,
                                  written_date,
                                  orig_ind,
                                  edi_po_ind,
                                  pre_mark_ind)
                           SELECT stg.message_id          ,
                                  stg.message_id          ,
                                  rms.order_no            ,
                                  rms.legacy_order_no     ,
                                  rms.currency_code       ,
                                  rms.supplier            ,
                                  rms.dept                ,
                                  stg.not_before_date     ,
                                  stg.not_after_date      ,
                                  rms.otb_eow_date        ,
                                  rms.pickup_date         ,
                                  rms.purchase_type       ,
                                  rms.ship_method         ,
                                  rms.ship_pay_method     ,
                                  rms.freight_terms       ,
                                  rms.agent               ,
                                  rms.fob_trans_res       ,
                                  rms.fob_trans_res_desc  ,
                                  rms.fob_title_pass      ,
                                  rms.fob_title_pass_desc ,
                                  rms.lading_port         ,
                                  rms.discharge_port      ,
                                  rms.buyer_id            ,
                                  DECODE(rms.status,
                                         RIS_LIBRARY.STATUS_COMPLETE, RIS_LIBRARY.STATUS_APPROVED,
                                         rms.status)    ,
                                  rms.terms               ,
                                  rms.duty_rate           ,
                                  rms.orig_approval_id    ,
                                  rms.freight_comp_id     ,
                                  rms.comment_desc        ,
                                  rms.inbound_ref_id      ,
                                  rms.run_id              ,
                                  rms.chunk_id            ,
                                  NEW_STATUS  ,
                                  rms.error_message       ,
                                  rms.crt_updt_dttm       ,
                                  rms.crt_updt_user_id    ,
                                  rms.lst_updt_dttm       ,
                                  rms.lst_updt_user_id    ,
                                  RIS_BUILD_XML.LP_xorder_mod_type,
                                  rms.parent_message_id,
                                  rms.include_on_ord_ind,
                                  rms.written_date,
                                  rms.orig_ind,
                                  rms.edi_po_ind,
                                  rms.pre_mark_ind
                             FROM ris_po_hdr_rms_gtt rms,
                                  ris_po_hdr_stage_gtt stg
                            WHERE (--rms.not_before_date <> stg.not_before_date OR
                                   --rms.not_after_date  <> stg.not_after_date  OR
                                  rms.status          =  RIS_LIBRARY.STATUS_COMPLETE) AND
                                  rms.message_id      =  I_event_id AND
                                  stg.message_id      =  I_event_id
                              /*AND NOT EXISTS  (SELECT 1
                                                 FROM ris_po_hdr_stage stg1
                                                WHERE stg1.message_id   = stg.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_mod_type)*/;
    L_row_count:= SQL%ROWCOUNT;
    DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_MODIFY_HDR_TO_STAGE ris_po_hdr_stage insert rowcount='||L_row_count);
    --return back if no records that qualify for hdr mod
    IF L_row_count = 0 THEN
        RETURN TRUE;
    END IF;

    --build xml message from stage and insert to ris message inbound table
    IF INSERT_RIS_INBOUND(O_error_message ,
                          L_ris_message_id,
                          I_event_id     ,
                          RIS_BUILD_XML.LP_xorder_mod_type,
                          I_xref_rms_ord_nbr) = FALSE THEN
        RETURN FALSE;
    END IF;
    --
    --update the qty_ordered and qty_Received in case of reinstating PO from CLOSED status
    UPDATE ris_po_dtl_rms_gtt dtl
       SET qty_ordered   = (qty_ordered + NVL(qty_cancelled,0)),
           qty_cancelled = 0
     WHERE message_id    = I_event_id
       AND EXISTS (SELECT 1 FROM ris_po_hdr_rms_gtt hdr WHERE hdr.status = RIS_LIBRARY.STATUS_COMPLETE);
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END INSERT_MODIFY_HDR_TO_STAGE;


/* *********************************************************************************************************
* Function          : INSERT_CREATE_DTL_TO_STAGE
* Purpose           :  dtl cre messages

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/

FUNCTION INSERT_CREATE_DTL_TO_STAGE(O_error_message          IN OUT         VARCHAR2,
                                    I_event_id               IN             NUMBER,
                                    I_xref_rms_ord_nbr       IN             NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name          VARCHAR2(200)           := 'RIS_PROCESS_PO.INSERT_CREATE_DTL_TO_STAGE';
    L_mark                  VARCHAR2(200);
    L_ris_message_id        ris_message_inbound.message_id%TYPE;
    L_count                 NUMBER;
    --
    CURSOR CHECK_DETAIL
        IS
           SELECT count(1)
            FROM ris_po_dtl_stage_gtt stg
           WHERE (item ,location) NOT IN (SELECT item ,location FROM ris_po_dtl_rms_gtt gtt WHERE gtt.message_id =  I_event_id)
             AND stg.message_id       =  I_event_id
             AND stg.quantity         > 0;
BEGIN
     OPEN CHECK_DETAIL;
    FETCH CHECK_DETAIL INTO L_count;
    CLOSE CHECK_DETAIL;

    --return if no records qualify for dtl cre
    IF L_count = 0 THEN
        RETURN TRUE;
    END IF;

    --check if any PO Detail records qualify for dtl cre
    INSERT INTO ris_po_hdr_stage (event_id            ,
                                  message_id          ,
                                  rms_order_no        ,
                                  legacy_order_no     ,
                                  currency_code       ,
                                  supplier            ,
                                  dept                ,
                                  not_before_date     ,
                                  not_after_date      ,
                                  otb_eow_date        ,
                                  pickup_date         ,
                                  purchase_type       ,
                                  ship_method         ,
                                  ship_pay_method     ,
                                  freight_terms       ,
                                  agent               ,
                                  fob_trans_res       ,
                                  fob_trans_res_desc  ,
                                  fob_title_pass      ,
                                  fob_title_pass_desc ,
                                  lading_port         ,
                                  discharge_port      ,
                                  buyer_id            ,
                                  status              ,
                                  terms               ,
                                  duty_rate           ,
                                  orig_approval_id    ,
                                  freight_comp_id     ,
                                  comment_desc        ,
                                  inbound_ref_id      ,
                                  run_id              ,
                                  chunk_id            ,
                                  proc_status         ,
                                  error_message       ,
                                  crt_updt_dttm       ,
                                  crt_updt_user_id    ,
                                  lst_updt_dttm       ,
                                  lst_updt_user_id    ,
                                  message_type,
                                  parent_message_id,
                                  include_on_ord_ind,
                                  written_date,
                                  orig_ind,
                                  edi_po_ind,
                                  pre_mark_ind)
                           SELECT message_id              ,
                                  message_id              ,
                                  rms.order_no            ,
                                  rms.legacy_order_no     ,
                                  rms.currency_code       ,
                                  rms.supplier            ,
                                  rms.dept                ,
                                  rms.not_before_date     ,
                                  rms.not_after_date      ,
                                  rms.otb_eow_date        ,
                                  rms.pickup_date         ,
                                  rms.purchase_type       ,
                                  rms.ship_method         ,
                                  rms.ship_pay_method     ,
                                  rms.freight_terms       ,
                                  rms.agent               ,
                                  rms.fob_trans_res       ,
                                  rms.fob_trans_res_desc  ,
                                  rms.fob_title_pass      ,
                                  rms.fob_title_pass_desc ,
                                  rms.lading_port         ,
                                  rms.discharge_port      ,
                                  rms.buyer_id            ,
                                  DECODE(rms.status,
                                         RIS_LIBRARY.STATUS_COMPLETE, RIS_LIBRARY.STATUS_APPROVED,
                                         rms.status)      ,
                                  rms.terms               ,
                                  rms.duty_rate           ,
                                  rms.orig_approval_id    ,
                                  rms.freight_comp_id     ,
                                  rms.comment_desc        ,
                                  rms.inbound_ref_id      ,
                                  rms.run_id              ,
                                  rms.chunk_id            ,
                                  NEW_STATUS         ,
                                  rms.error_message       ,
                                  rms.crt_updt_dttm       ,
                                  rms.crt_updt_user_id    ,
                                  rms.lst_updt_dttm       ,
                                  rms.lst_updt_user_id    ,
                                  RIS_BUILD_XML.LP_xorder_dtl_cre_type,
                                  rms.parent_message_id,
                                  rms.include_on_ord_ind,
                                  rms.written_date,
                                  rms.orig_ind,
                                  rms.edi_po_ind,
                                  rms.pre_mark_ind
                             FROM ris_po_hdr_rms_gtt rms
                            WHERE rms.message_id = I_event_id
                           /* WHERE NOT EXISTS  (SELECT 1
                                                 FROM ris_po_hdr_stage stg1
                                                WHERE stg1.message_id   = rms.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_dtl_cre_type) */;
    DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_CREATE_DTL_TO_STAGE ris_po_hdr_stage insert rowcount='||SQL%ROWCOUNT);
    --
    INSERT INTO RIS_PO_DTL_STAGE (event_id              ,
                                  message_id            ,
                                  message_type          ,
                                  item                  ,
                                  location              ,
                                  loc_type              ,
                                  --order_no              ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  crt_updt_dttm         ,
                                  crt_updt_user_id      ,
                                  lst_updt_dttm         ,
                                  lst_updt_user_id)
                           SELECT message_id            ,
                                  message_id            ,
                                  RIS_BUILD_XML.LP_xorder_dtl_cre_type,
                                  item                  ,
                                  location              ,
                                  loc_type              ,
                                  --order_no              ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  crt_updt_dttm         ,
                                  crt_updt_user_id      ,
                                  lst_updt_dttm         ,
                                  lst_updt_user_id
                             FROM ris_po_dtl_stage_gtt stg
                            WHERE (item ,location) NOT IN (SELECT item ,location FROM ris_po_dtl_rms_gtt gtt WHERE gtt.message_id = I_event_id)
                              AND stg.message_id     = I_event_id
                              AND stg.quantity       > 0;
                            /*  AND NOT EXISTS  (SELECT 1
                                                 FROM ris_po_dtl_stage stg1
                                                WHERE stg1.message_id   = stg.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_dtl_cre_type
                                                  AND stg1.item         = stg.item
                                                  AND stg1.location     = stg.location) */
    DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_CREATE_DTL_TO_STAGE ris_po_dtl_stage insert rowcount='||SQL%ROWCOUNT);
    --build xml message from stage and insert to ris message inbound table
    IF INSERT_RIS_INBOUND(O_error_message ,
                          L_ris_message_id,
                          I_event_id     ,
                          RIS_BUILD_XML.LP_xorder_dtl_cre_type,
                          I_xref_rms_ord_nbr) = FALSE THEN
        RETURN FALSE;
    END IF;
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END INSERT_CREATE_DTL_TO_STAGE;

/* *********************************************************************************************************
* Function          : INSERT_DELETE_DTL_TO_STAGE
* Purpose           : dtl del msgs

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION INSERT_DELETE_DTL_TO_STAGE(O_error_message          IN OUT         VARCHAR2,
                                    I_event_id               IN             NUMBER,
                                    I_xref_rms_ord_nbr       IN             NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name          VARCHAR2(200)           := 'RIS_PROCESS_PO.INSERT_DELETE_DTL_TO_STAGE';
    L_exists                VARCHAR2(1);
    L_vdate                 DATE;
    VALID_ORD               EXCEPTION;
    L_mark                  VARCHAR2(200);
    L_stage_order_object    "RIB_XOrderRef_REC";
    L_xml_payload           XMLTYPE;
    L_ris_message_id        ris_message_inbound.message_id%TYPE;
    L_count                 NUMBER;
    --
    CURSOR CHECK_DETAIL
        IS
           SELECT count(1)
            FROM ris_po_dtl_rms_gtt rms
           WHERE (rms.item ,rms.location) NOT IN (SELECT item ,location FROM ris_po_dtl_stage_gtt gtt WHERE gtt.message_id = I_event_id)
             AND rms.message_id      = I_event_id
             AND (NVL(rms.qty_ordered,0)-NVL(rms.qty_Received,0))  > 0;--cancellable qty
BEGIN
     OPEN CHECK_DETAIL;
    FETCH CHECK_DETAIL INTO L_count;
    CLOSE CHECK_DETAIL;

    --return if no records qualify for dtl del
    IF L_count = 0 THEN
        RETURN TRUE;
    END IF;

    --check if any PO Detail records qualify for dtl del
    INSERT INTO ris_po_hdr_stage (event_id            ,
                                  message_id          ,
                                  rms_order_no        ,
                                  legacy_order_no     ,
                                  currency_code       ,
                                  supplier            ,
                                  dept                ,
                                  not_before_date     ,
                                  not_after_date      ,
                                  otb_eow_date        ,
                                  pickup_date         ,
                                  purchase_type       ,
                                  ship_method         ,
                                  ship_pay_method     ,
                                  freight_terms       ,
                                  agent               ,
                                  fob_trans_res       ,
                                  fob_trans_res_desc  ,
                                  fob_title_pass      ,
                                  fob_title_pass_desc ,
                                  lading_port         ,
                                  discharge_port      ,
                                  buyer_id            ,
                                  status              ,
                                  terms               ,
                                  duty_rate           ,
                                  orig_approval_id    ,
                                  freight_comp_id     ,
                                  comment_desc        ,
                                  inbound_ref_id      ,
                                  run_id              ,
                                  chunk_id            ,
                                  proc_status         ,
                                  error_message       ,
                                  crt_updt_dttm       ,
                                  crt_updt_user_id    ,
                                  lst_updt_dttm       ,
                                  lst_updt_user_id    ,
                                  message_type,
                                  parent_message_id,
                                  include_on_ord_ind,
                                  written_date,
                                  orig_ind,
                                  edi_po_ind,
                                  pre_mark_ind)
                           SELECT message_id              ,
                                  message_id              ,
                                  rms.order_no            ,
                                  rms.legacy_order_no     ,
                                  rms.currency_code       ,
                                  rms.supplier            ,
                                  rms.dept                ,
                                  rms.not_before_date     ,
                                  rms.not_after_date      ,
                                  rms.otb_eow_date        ,
                                  rms.pickup_date         ,
                                  rms.purchase_type       ,
                                  rms.ship_method         ,
                                  rms.ship_pay_method     ,
                                  rms.freight_terms       ,
                                  rms.agent               ,
                                  rms.fob_trans_res       ,
                                  rms.fob_trans_res_desc  ,
                                  rms.fob_title_pass      ,
                                  rms.fob_title_pass_desc ,
                                  rms.lading_port         ,
                                  rms.discharge_port      ,
                                  rms.buyer_id            ,
                                  DECODE(rms.status,
                                         RIS_LIBRARY.STATUS_COMPLETE, RIS_LIBRARY.STATUS_APPROVED,
                                         rms.status)      ,
                                  rms.terms               ,
                                  rms.duty_rate           ,
                                  rms.orig_approval_id    ,
                                  rms.freight_comp_id     ,
                                  rms.comment_desc        ,
                                  rms.inbound_ref_id      ,
                                  rms.run_id              ,
                                  rms.chunk_id            ,
                                  NEW_STATUS  ,
                                  rms.error_message       ,
                                  rms.crt_updt_dttm       ,
                                  rms.crt_updt_user_id    ,
                                  rms.lst_updt_dttm       ,
                                  rms.lst_updt_user_id    ,
                                  RIS_BUILD_XML.LP_xorder_dtl_del_type,
                                  rms.parent_message_id,
                                  rms.include_on_ord_ind,
                                  rms.written_date,
                                  rms.orig_ind,
                                  rms.edi_po_ind,
                                  rms.pre_mark_ind
                             FROM ris_po_hdr_rms_gtt rms
                             WHERE rms.message_id = I_event_id
                           /* WHERE NOT EXISTS  (SELECT 1
                                                 FROM ris_po_hdr_stage stg1
                                                WHERE stg1.message_id   = stg.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_dtl_del_type) */;
    DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_DELETE_DTL_TO_STAGE ris_po_hdr_stage insert rowcount='||SQL%ROWCOUNT);
    --
    INSERT INTO RIS_PO_DTL_STAGE (event_id              ,
                                  message_id            ,
                                  message_type          ,
                                  item                  ,
                                  location              ,
                                  loc_type              ,
                                  --order_no              ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  crt_updt_dttm         ,
                                  crt_updt_user_id      ,
                                  lst_updt_dttm         ,
                                  lst_updt_user_id)
                           SELECT message_id            ,
                                  message_id            ,
                                  RIS_BUILD_XML.LP_xorder_dtl_del_type,
                                  stg.item                  ,
                                  stg.location              ,
                                  loc_type              ,
                                  --order_no              ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  crt_updt_dttm         ,
                                  crt_updt_user_id      ,
                                  lst_updt_dttm         ,
                                  lst_updt_user_id
                             FROM ris_po_dtl_rms_gtt stg
                            WHERE (stg.item ,stg.location) NOT IN (SELECT item ,location FROM ris_po_dtl_stage_gtt gtt WHERE gtt.message_id = I_event_id )
                              AND stg.message_id     = I_event_id
                              AND (NVL(stg.qty_ordered,0)-NVL(stg.qty_Received,0))  > 0--cancellable qty
                              /*AND NOT EXISTS  (SELECT 1
                                                 FROM ris_po_dtl_stage stg1
                                                WHERE stg1.message_id   = stg.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_dtl_del_type
                                                  AND stg1.item         = stg.item
                                                  AND stg1.location     = stg.location) */;
     DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_DELETE_DTL_TO_STAGE ris_po_dtl_stage insert rowcount='||SQL%ROWCOUNT);
     --build xml message from stage and insert to ris message inbound table
     IF INSERT_RIS_INBOUND(O_error_message ,
                           L_ris_message_id,
                            I_event_id     ,
                            RIS_BUILD_XML.LP_xorder_dtl_del_type,
                            I_xref_rms_ord_nbr) = FALSE THEN
        RETURN FALSE;
    END IF;
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END INSERT_DELETE_DTL_TO_STAGE;


/* *********************************************************************************************************
* Function          : INSERT_MODIFY_DTL_TO_STAGE
* Purpose           :

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION INSERT_MODIFY_DTL_TO_STAGE(O_error_message          IN OUT         VARCHAR2,
                                    I_event_id               IN             NUMBER,
                                    I_xref_rms_ord_nbr       IN             NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name          VARCHAR2(200)           := 'RIS_PROCESS_PO.INSERT_MODIFY_DTL_TO_STAGE';
    L_mark                  VARCHAR2(200);
    L_ris_message_id        ris_message_inbound.message_id%TYPE;
    L_count                 NUMBER;
    L_is_dpo_complete       VARCHAR2(1)             := 'N';
    --
    CURSOR CHECK_DETAIL
        IS
           SELECT count(1)
            FROM ris_po_dtl_rms_gtt rd,
                 ris_po_dtl_stage_gtt sd
           WHERE rd.item         =  sd.item
             AND rd.location     =  sd.location
             AND (((rd.quantity   <> sd.quantity OR
                   (rd.unit_cost  <> sd.unit_cost AND rd.quantity <> sd.quantity) OR
                   (rd.unit_cost  <> sd.unit_cost AND rd.quantity = sd.quantity AND sd.quantity <> 0)) AND
                    L_is_dpo_complete = 'N')
                   OR
                   (L_is_dpo_complete = 'Y' AND
                    (rd.qty_ordered-rd.qty_received)>0
                   )
                 )
             AND rd.message_id   =  I_event_id
             AND sd.message_id   =  I_event_id;
    --
    CURSOR CHECK_IF_DPO_COMPLETE
        IS
            SELECT 'Y'
              FROM ris_po_hdr_stage_gtt
             WHERE message_id                   = I_event_id
               AND event_inbound_message_type   = RIS_INBOUND_EVENT_PROCESS.DPOCOMPLETE;
BEGIN
    --
    L_mark := 'OPEN CHECK_DETAIL';
     OPEN CHECK_IF_DPO_COMPLETE;
    FETCH CHECK_IF_DPO_COMPLETE INTO L_is_dpo_complete;
    CLOSE CHECK_IF_DPO_COMPLETE;
    --
    L_mark := 'OPEN CHECK_DETAIL';
     OPEN CHECK_DETAIL;
    FETCH CHECK_DETAIL INTO L_count;
    CLOSE CHECK_DETAIL;
    --

    --return back if no records qualify for dtl mod
    IF L_count = 0  THEN
        RETURN TRUE;
    END IF;

    --check if any detail records qualify for dtl mod and insert them to staging table
    INSERT INTO ris_po_hdr_stage (event_id            ,
                                  message_id          ,
                                  rms_order_no        ,
                                  legacy_order_no     ,
                                  currency_code       ,
                                  supplier            ,
                                  dept                ,
                                  not_before_date     ,
                                  not_after_date      ,
                                  otb_eow_date        ,
                                  pickup_date         ,
                                  purchase_type       ,
                                  ship_method         ,
                                  ship_pay_method     ,
                                  freight_terms       ,
                                  agent               ,
                                  fob_trans_res       ,
                                  fob_trans_res_desc  ,
                                  fob_title_pass      ,
                                  fob_title_pass_desc ,
                                  lading_port         ,
                                  discharge_port      ,
                                  buyer_id            ,
                                  status              ,
                                  terms               ,
                                  duty_rate           ,
                                  orig_approval_id    ,
                                  freight_comp_id     ,
                                  comment_desc        ,
                                  inbound_ref_id      ,
                                  run_id              ,
                                  chunk_id            ,
                                  proc_status         ,
                                  error_message       ,
                                  crt_updt_dttm       ,
                                  crt_updt_user_id    ,
                                  lst_updt_dttm       ,
                                  lst_updt_user_id    ,
                                  message_type,
                                  parent_message_id,
                                  include_on_ord_ind,
                                  written_date,
                                  orig_ind,
                                  edi_po_ind,
                                  pre_mark_ind)
                           SELECT message_id              ,
                                  message_id              ,
                                  rms.order_no            ,
                                  rms.legacy_order_no     ,
                                  rms.currency_code       ,
                                  rms.supplier            ,
                                  rms.dept                ,
                                  rms.not_before_date     ,
                                  rms.not_after_date      ,
                                  rms.otb_eow_date        ,
                                  rms.pickup_date         ,
                                  rms.purchase_type       ,
                                  rms.ship_method         ,
                                  rms.ship_pay_method     ,
                                  rms.freight_terms       ,
                                  rms.agent               ,
                                  rms.fob_trans_res       ,
                                  rms.fob_trans_res_desc  ,
                                  rms.fob_title_pass      ,
                                  rms.fob_title_pass_desc ,
                                  rms.lading_port         ,
                                  rms.discharge_port      ,
                                  rms.buyer_id            ,
                                  DECODE(rms.status,
                                         RIS_LIBRARY.STATUS_COMPLETE, RIS_LIBRARY.STATUS_APPROVED,
                                         rms.status)      ,
                                  rms.terms               ,
                                  rms.duty_rate           ,
                                  rms.orig_approval_id    ,
                                  rms.freight_comp_id     ,
                                  rms.comment_desc        ,
                                  rms.inbound_ref_id      ,
                                  rms.run_id              ,
                                  rms.chunk_id            ,
                                  NEW_STATUS  ,
                                  rms.error_message       ,
                                  rms.crt_updt_dttm       ,
                                  rms.crt_updt_user_id    ,
                                  rms.lst_updt_dttm       ,
                                  rms.lst_updt_user_id    ,
                                  RIS_BUILD_XML.LP_xorder_dtl_mod_type,
                                  rms.parent_message_id,
                                  rms.include_on_ord_ind,
                                  rms.written_date,
                                  rms.orig_ind,
                                  rms.edi_po_ind,
                                  rms.pre_mark_ind
                             FROM ris_po_hdr_stage_gtt rms
                            WHERE rms.message_id = I_event_id
                            /*WHERE NOT EXISTS  (SELECT 1
                                                 FROM ris_po_hdr_stage stg1
                                                WHERE stg1.message_id   = stg.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_dtl_mod_type) */;
    DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_MODIFY_DTL_TO_STAGE ris_po_hdr_stage insert rowcount='||SQL%ROWCOUNT);
    --
    INSERT INTO RIS_PO_DTL_STAGE (event_id              ,
                                  message_id            ,
                                  message_type          ,
                                  item                  ,
                                  location              ,
                                  loc_type              ,
                                  --order_no            ,
                                  estimate_instock_date ,
                                  origin_country_id     ,
                                  unit_cost             ,
                                  quantity              ,
                                  supp_pack_size        ,
                                  cancel_ind            ,
                                  reinstate_ind         ,
                                  delivery_date         ,
                                  crt_updt_dttm         ,
                                  crt_updt_user_id      ,
                                  lst_updt_dttm         ,
                                  lst_updt_user_id)
                           SELECT rd.message_id         ,
                                  rd.message_id         ,
                                  RIS_BUILD_XML.LP_xorder_dtl_mod_type,
                                  rd.item                  ,
                                  rd.location              ,
                                  rd.loc_type              ,
                                  --rd.order_no              ,
                                  rd.estimate_instock_date ,
                                  rd.origin_country_id     ,
                                  DECODE(sd.unit_cost,0,DECODE(sd.quantity,0,rd.unit_cost,sd.unit_cost),sd.unit_cost),
                                  sd.quantity              ,
                                  rd.supp_pack_size        ,
                                  rd.cancel_ind,
                                  rd.reinstate_ind         ,
                                  rd.delivery_date         ,
                                  rd.crt_updt_dttm         ,
                                  rd.crt_updt_user_id      ,
                                  rd.lst_updt_dttm         ,
                                  rd.lst_updt_user_id
                             FROM ris_po_dtl_rms_gtt rd,
                                  ris_po_dtl_stage_gtt sd
                            WHERE rd.message_id   = I_event_id
                              AND sd.message_id   = I_event_id
                              AND rd.item         = sd.item
                              AND rd.location     = sd.location
                              AND (((rd.quantity   <> sd.quantity) OR
                                   (rd.unit_cost  <> sd.unit_cost AND rd.quantity <> sd.quantity) OR
                                   (rd.unit_cost  <> sd.unit_cost AND rd.quantity = sd.quantity AND sd.quantity <> 0))
                                    OR
                                    (L_is_dpo_complete = 'Y' AND
                                     (rd.qty_ordered-rd.qty_received)>0
                                    )
                                  )
                              AND NOT EXISTS  (SELECT 1
                                                 FROM ris_po_dtl_stage stg1
                                                WHERE stg1.message_id   = rd.message_id
                                                  AND stg1.message_type = RIS_BUILD_XML.LP_xorder_dtl_mod_type
                                                  AND stg1.item         = rd.item
                                                  AND stg1.location     = rd.location) ;
    DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_MODIFY_DTL_TO_STAGE ris_po_dtl_stage insert rowcount='||SQL%ROWCOUNT);
    --build xml message from stage and insert to ris message inbound table
    IF INSERT_RIS_INBOUND(O_error_message ,
                          L_ris_message_id,
                          I_event_id     ,
                          RIS_BUILD_XML.LP_xorder_dtl_mod_type,
                          I_xref_rms_ord_nbr) = FALSE THEN
        RETURN FALSE;
    END IF;
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END INSERT_MODIFY_DTL_TO_STAGE;

/* *********************************************************************************************************
* Function          : CHECK_IF_PO_CAN_BE_MODIFIED
* Purpose           : Check if PO cannot be modified or not.

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 29-OCT-2018   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION CHECK_IF_PO_CAN_BE_MODIFIED(O_error_message        IN OUT         VARCHAR2,
                                     IO_po_can_be_modified  IN OUT         VARCHAR2,
                                     I_event_id             IN             NUMBER,
                                     I_converted_order      IN             VARCHAR2)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name                 VARCHAR2(200)        := 'RIS_PROCESS_PO.CHECK_IF_PO_CAN_BE_MODIFIED';
    L_mark                         VARCHAR2(200)        := 'DECLARE';
    L_qty_cancelled                NUMBER;
    L_event_inbound_message_type   ris_event_inbound.message_type%TYPE;
    L_qty_received                 NUMBER;
    L_rms_order_status             VARCHAR2(2);
    CURSOR C_CHK_QTY_CANCEL
    IS
       SELECT SUM(NVL(qty_cancelled,0))
         FROM ris_po_hdr_rms_gtt hdr,
              ris_po_dtl_rms_gtt dtl
        WHERE hdr.message_id    =   I_event_id
          AND dtl.message_id    =   hdr.message_id
          AND hdr.status        =   RIS_LIBRARY.STATUS_COMPLETE;--closed and hence should be fully received

    CURSOR C_CHK_PARTIALLY_RECEIVED
    IS
       SELECT SUM(NVL(qty_received,0))
         FROM ris_po_dtl_rms_gtt dtl
        WHERE dtl.message_id    =   I_event_id ;

    CURSOR C_CHK_RMS_ORDER_STATUS
    IS
        SELECT status
          FROM ris_po_hdr_rms_gtt hdr
         WHERE hdr.message_id    =   I_event_id;

    CURSOR C_CHK_EVENT_INBOUND_MSG_TYPE
    IS
        SELECT event_inbound_message_type
          FROM ris_po_hdr_stage_gtt hdr
         WHERE hdr.message_id    =   I_event_id;
BEGIN
    L_mark := 'OPEN C_CHK_QTY_CANCEL';
     OPEN C_CHK_QTY_CANCEL;
    FETCH C_CHK_QTY_CANCEL into L_qty_cancelled;
    CLOSE C_CHK_QTY_CANCEL;
    --
    L_mark := 'OPEN C_CHK_PARTIALLY_RECEIVED';
     OPEN C_CHK_PARTIALLY_RECEIVED;
    FETCH C_CHK_PARTIALLY_RECEIVED into L_qty_received;
    CLOSE C_CHK_PARTIALLY_RECEIVED;

    --
    L_mark := 'OPEN C_CHK_EVENT_INBOUND_MSG_TYPE';
     OPEN C_CHK_EVENT_INBOUND_MSG_TYPE;
    FETCH C_CHK_EVENT_INBOUND_MSG_TYPE into L_event_inbound_message_type;
    CLOSE C_CHK_EVENT_INBOUND_MSG_TYPE;

    --
    --cannot reinstate the converted order which is closed in RMS.

        L_mark := 'OPEN C_CHK_PARTIALLY_RECEIVED';
         OPEN C_CHK_RMS_ORDER_STATUS;
        FETCH C_CHK_RMS_ORDER_STATUS into L_rms_order_status;
        CLOSE C_CHK_RMS_ORDER_STATUS;

    --
    --closed orders can be reinstated only when they have a positive cancelled qty
    --Also we cannot modify a partialy received order
    --Also we cannot reinstate the converted order which is closed in RMS.
    IF L_event_inbound_message_type <> RIS_INBOUND_EVENT_PROCESS.DPOCOMPLETE THEN
        IF (L_rms_order_status = 'C' AND L_qty_cancelled = 0) OR L_qty_received >0  OR (I_converted_order = 'Y' AND L_rms_order_status = 'C')
        THEN

            IO_po_can_be_modified := 'N';
        ELSE

            IO_po_can_be_modified := 'Y';
        END IF;
    ELSE
        IF I_converted_order = 'Y' AND L_rms_order_status = 'C' THEN
            IO_po_can_be_modified := 'N';
        ELSE

            IO_po_can_be_modified := 'Y';
        END IF;
    END IF;
    --
    IF I_converted_order = 'Y' AND L_rms_order_status = 'C'
    THEN
        -- Not using SQLLIB to trap whole RSE error message.
        O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                              '@CANNOT_REINSTATE_CLOSED_CONVERTED_ORDER@',
                                              L_program_name,
                                              NULL);
    ELSIF L_qty_received >0  AND L_event_inbound_message_type <> DPO_COMPLETE
    THEN
        -- Not using SQLLIB to trap whole RSE error message.
        O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                              '@CANNOT_MODIFY_A_PARTIALY_RECEIVED_ORDER@',
                                              L_program_name,
                                              NULL);
        --RETURN FALSE;
    ELSIF (L_rms_order_status = 'C' AND L_qty_cancelled = 0)
    THEN
        -- Not using SQLLIB to trap whole RSE error message.
        O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                              '@CANNOT_REINSTATE_CLOSED_ORDER_WITH_ZERO_CANCEL_QTY@',
                                              L_program_name,
                                              NULL);
    END IF;
    --

    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END CHECK_IF_PO_CAN_BE_MODIFIED;

/* *********************************************************************************************************
* Function          : MODIFY_ORDER
* Purpose           : order mod

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION MODIFY_ORDER(O_error_message       IN OUT         VARCHAR2,
                      I_xref_rms_ord_nbr    IN OUT         NUMBER,
                      O_proc_status         IN OUT         VARCHAR2,
                      I_entity_id           IN             VARCHAR2,
                      I_event_id            IN             NUMBER,
                      I_event_type          IN             VARCHAR2,
                      I_converted_order     IN             VARCHAR2
                      )


    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name              VARCHAR2(200)        := 'RIS_PROCESS_PO.MODIFY_ORDER';
    L_mark                      VARCHAR2(200);
    L_po_can_be_modified         VARCHAR2(1)          := 'Y';
    --
    CURSOR C_GET_ORDER_REC
        IS
            SELECT message_id ,
                   inbound_ref_id,
                   message_type,
                   DECODE(message_type,
                          RIS_BUILD_XML.LP_xorder_mod_type, 1,
                          RIS_BUILD_XML.LP_xorder_dtl_cre_type,2,
                          RIS_BUILD_XML.LP_xorder_dtl_mod_type,3,
                          RIS_BUILD_XML.LP_xorder_dtl_del_type,4) rnk
              FROM ris_po_hdr_stage
             WHERE message_id     = I_event_id
               AND message_type   IN (RIS_BUILD_XML.LP_xorder_mod_type,
                                      RIS_BUILD_XML.LP_xorder_dtl_cre_type,
                                      RIS_BUILD_XML.LP_xorder_dtl_mod_type,
                                      RIS_BUILD_XML.LP_xorder_dtl_del_type)
              AND proc_status     <> RIS_LIBRARY.STATUS_COMPLETE
              ORDER BY rnk;
   L_order_status_rec           C_GET_ORDER_REC%ROWTYPE;

BEGIN
    --update rms order no to staging table
    IF O_proc_status IN ( NEW_STATUS ) THEN
        L_mark := 'UPDATE ris_po_hdr_stage';
        UPDATE ris_po_hdr_stage
           SET rms_order_no = I_xref_rms_ord_nbr
         WHERE message_id   = I_event_id
           AND message_type = I_event_type
           AND proc_status  = NEW_STATUS;
        IF SQL%FOUND THEN
            COMMIT;
        END IF;
    END IF;
    --
    L_mark := 'VALIDATE_STAGE_RECORDS';
    IF O_proc_status IN ( NEW_STATUS, VALIDATION_ERROR) THEN
        --validate the staging records
        IF VALIDATE_STAGE_RECORDS(O_error_message,O_proc_status,I_event_id,I_event_type) = FALSE THEN
                --O_proc_status := VALIDATION_ERROR;
                COMMIT;
                RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':VALIDATE_STAGE_RECORDS COMPLETED');
        --O_proc_status := VALIDATED;
        COMMIT;
    END IF;
    --
    IF O_proc_status IN ( VALIDATED, RIS_INBOUND_ERROR) THEN
        --
        L_mark := 'CALL POPULATE_RECORDS_FROM_RMS';
        --populate records from rms table to gtt tables
        --pr8s9p2 revert this comment
        IF POPULATE_RECORDS_FROM_RMS(O_error_message,I_xref_rms_ord_nbr,I_event_id,I_entity_id) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':POPULATE_RECORDS_FROM_RMS COMPLETED');
        L_mark := 'CALL POPULATE_RECORDS_FROM_STAGE';
        --populate records from staging table to gtt tables
        IF POPULATE_RECORDS_FROM_STAGE(O_error_message,I_event_id,I_xref_rms_ord_nbr,I_event_type) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':POPULATE_RECORDS_FROM_STAGE COMPLETED');
        --
        --check if order can be modified
        L_mark := 'CALL CHECK_PO_CANT_REINSTATE';
        IF CHECK_IF_PO_CAN_BE_MODIFIED(O_error_message,L_po_can_be_modified,I_event_id,I_converted_order) = FALSE
        THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        --
        IF L_po_can_be_modified = 'N'
        THEN
            RETURN TRUE;
        END IF;
        --
        --
        L_mark := 'CALL INSERT_MODIFY_HDR_TO_STAGE';
        --compare the  stage and rms gtt records and insert hdr mod  if any present
        IF INSERT_MODIFY_HDR_TO_STAGE(O_error_message,I_event_id,I_xref_rms_ord_nbr) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_MODIFY_HDR_TO_STAGE COMPLETED');
        --
        L_mark := 'CALL INSERT_CREATE_DTL_TO_STAGE';
        --compare the  stage and rms gtt records and insert detail create records  if any present
        IF INSERT_CREATE_DTL_TO_STAGE(O_error_message,I_event_id,I_xref_rms_ord_nbr) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_CREATE_DTL_TO_STAGE COMPLETED');
        --
        L_mark := 'CALL INSERT_MODIFY_DTL_TO_STAGE';
        --compare the  stage and rms gtt records and insert detail mod records  if any present
        IF INSERT_MODIFY_DTL_TO_STAGE(O_error_message,I_event_id,I_xref_rms_ord_nbr) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_MODIFY_DTL_TO_STAGE COMPLETED');
        --
        -- Commented out because detail delete messages are not processed in RMS.Detail cancel is enough.
        L_mark := 'CALL INSERT_DELETE_DTL_TO_STAGE';
        --compare the  stage and rms gtt records and insert detail delete records  if any present
        --also cannot be done for converted orders
        IF I_converted_order = 'N' THEN
            IF INSERT_DELETE_DTL_TO_STAGE(O_error_message,I_event_id,I_xref_rms_ord_nbr) = FALSE THEN
                O_proc_status := RIS_INBOUND_ERROR;
                RETURN FALSE;
            END IF;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_DELETE_DTL_TO_STAGE COMPLETED');
        --
        COMMIT;
        O_proc_status := RIS_INBOUND_SUCCESS;
    ELSE
        IF POPULATE_RECORDS_FROM_RMS(O_error_message,I_xref_rms_ord_nbr,I_event_id,I_entity_id,'N') = FALSE THEN
            RETURN FALSE;
        END IF;
    END IF;

    --
    IF O_proc_status IN (WEB_SERVICE_ERROR, RIS_INBOUND_SUCCESS) THEN
        --call web service for hdr mod, detail delete, insert detail and detail mod  records if any
        FOR rec IN C_GET_ORDER_REC
        LOOP
            IF rec.inbound_ref_id IS NOT NULL --only call consume for those records that have entry in the ris_message_inbound table
            THEN

                IF NOT RIS_CONSUMER_SERVICE.CONSUME (O_error_message,
                                                     rec.inbound_ref_id)
                THEN
                    O_proc_status := WEB_SERVICE_ERROR;
                    O_error_message := rec.message_type||':'||O_error_message;
                    RETURN FALSE;
                --
                END IF;
                DBG_SQL.MSG(L_dbg_object,I_event_id||':RIS_CONSUMER_SERVICE.CONSUME COMPLETED');
                --
                IF rec.message_type = RIS_BUILD_XML.LP_xorder_mod_type THEN
                --set lgcy_dlt_ind to N from Y, when Reinstating closed order
                    L_mark := 'UPDATE risgap.poorx_po_xref_t';
                    UPDATE poorx_po_xref_t
                       SET lgcy_dlt_ind = 'N',
                           lst_updt_dttm = SYSDATE,
                           lst_updt_user_id = USER
                     WHERE rms_ord_nbr  = I_xref_rms_ord_nbr
                       AND EXISTS (SELECT order_no FROM ris_po_hdr_rms_gtt WHERE status = RIS_LIBRARY.STATUS_COMPLETE AND message_id = I_event_id);
                END IF;
                --
                COMMIT;
                --
            END IF;
        END LOOP;
    END IF;
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END MODIFY_ORDER;


/* *********************************************************************************************************
* Function          : INSERT_TO_PO_XREF
* Purpose           : insert order to xref

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION INSERT_TO_PO_XREF(O_error_message       IN OUT         VARCHAR2,
                           I_entity_id           IN             VARCHAR2,
                           O_rms_order_no        IN OUT         NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.INSERT_TO_PO_XREF';
    L_object_response      OBJ_INVOCATIONSUCCESS;
    L_mark                 VARCHAR2(200);
    --

BEGIN

    INSERT
        INTO         poorx_po_xref_t(rms_ord_nbr     ,
                                     po_pfx_nbr      ,
                                     po_dc_id        ,
                                     po_dlvr_id      ,
                                     lgcy_dlt_ind    ,
                                     --rms_ind     ,
                                     crt_updt_dttm   ,
                                     crt_updt_user_id,
                                     lst_updt_dttm   ,
                                     lst_updt_user_id)
                             VALUES (O_rms_order_no,
                                     SUBSTR(I_entity_id,1,5),
                                     SUBSTR(I_entity_id,6,1),
                                     SUBSTR(I_entity_id,7,1),
                                     'N',
                                     --'Y',
                                     sysdate,
                                     LP_USER,
                                     sysdate,
                                     LP_USER
                                    );
    DBG_SQL.MSG(L_dbg_object,I_entity_id||':poorx_po_xref_t insert rowcount='||SQL%ROWCOUNT);

    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END INSERT_TO_PO_XREF;


/* ******************************************************************************
* Procedure         : PROCESS_ORDER_WEBSERVICE
* Purpose           :
*
* Author               Date                 Ver
* -------  ---------  -----------------    ---------   -----------------------
* Pradeep             23-FEB-2017          1.0
*******************************************************************************/
FUNCTION PROCESS_ORDER_WEBSERVICE(O_error_message    IN OUT   VARCHAR2,
                                  I_message_id       IN       NUMBER)
    RETURN BOOLEAN IS
    -- Variable Declarations
    L_program_name                   VARCHAR2(200)                               := 'RIS_PROCESS_PO.PROCESS_ORDER_WEBSERVICE';
    L_object_response                CLOB;
    L_mark                           VARCHAR2(4000);
    L_xml                            XMLTYPE;
    L_status                         VARCHAR2(2);
    --
BEGIN
    --
    L_mark := 'Calling RIS_PROCESS_PO.PROCESS_ORDER_WEBSERVICE';
    --
    --call the rms web service to post staged orders to rms
    IF RIS_APEX_SERVICE.POST_SOAP_REQUEST(O_error_message,
                                          L_object_response     ,
                                          I_message_id  ) = FALSE THEN
        L_status := WEB_SERVICE_ERROR;
    ELSE
        L_status := RIS_LIBRARY.STATUS_COMPLETE;
    END IF;
    --
    DBG_SQL.MSG(L_dbg_object,I_message_id||':RIS_APEX_SERVICE.POST_SOAP_REQUEST COMPLETED');
    --
    L_mark := 'Calling UPDATE_STATUS';
    IF UPDATE_STATUS(O_error_message,
                     I_message_id,
                     L_status
                    ) = FALSE
    THEN
       --
       NULL;
       --
    END IF;
    --
    COMMIT;
    IF L_status = RIS_LIBRARY.STATUS_COMPLETE THEN
         RETURN TRUE;
         DBG_SQL.MSG(L_dbg_object,I_message_id||':PROCESS_ORDER_WEBSERVICE STATUS_COMPLETE');
    ELSE
          DBG_SQL.MSG(L_dbg_object,I_message_id||':PROCESS_ORDER_WEBSERVICE STATUS_FAIL');
         RETURN FALSE;
    END IF;
    --
EXCEPTION
   WHEN OTHERS
   THEN

      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@ ' || L_mark,
                                           L_program_name,
                                           TO_CHAR(SQLCODE));
      RETURN FALSE;
END PROCESS_ORDER_WEBSERVICE;


/* *********************************************************************************************************
* Function          : CREATE_ORDER
* Purpose           : Order Create

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION CREATE_ORDER(O_error_message       IN OUT         VARCHAR2,
                      O_xref_rms_ord_nbr    IN OUT         NUMBER,
                      O_proc_status         IN OUT         VARCHAR2,
                      I_entity_id           IN             VARCHAR2,
                      I_event_id            IN             NUMBER,
                      I_event_type          IN             VARCHAR2,
                      I_inbound_ref_id      IN             NUMBER
                      )
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.CREATE_ORDER';
    L_mark                 VARCHAR2(200);
    L_inbound_ref_id       NUMBER               := I_inbound_ref_id;
    --
    CURSOR CHECK_ORDER_EXISTS_IN_RMS
        IS
            SELECT 'Y'
              FROM ris_po_hdr_rms_gtt gtt
             WHERE gtt.message_id = I_event_id
               AND order_no       = O_xref_rms_ord_nbr;

    L_check VARCHAR2(2) := 'N';
BEGIN
    --
    L_mark:=  'IF O_xref_rms_ord_nbr IS NULL ';

    --FOR NEW RECORDS
    IF O_proc_status IN ( NEW_STATUS ) THEN
        --In case of new records O_xref_rms_ord_nbr is derived from sequence gap_order_seq.
        --in case of restart the O_xref_rms_ord_nbr is derived from ris_po_hdr_stage, which
        --is passed to CREATE_ORDER from main public function PROCESS_ORDER using cursor C_GET_ENTITY_HEADER
        IF NVL(O_xref_rms_ord_nbr,0) = 0 THEN
           L_mark := 'UPDATE ris_po_hdr_stage';
           O_xref_rms_ord_nbr  := gap_order_seq.NEXTVAL;
           UPDATE ris_po_hdr_stage
              SET rms_order_no = O_xref_rms_ord_nbr
            WHERE message_id   = I_event_id
             AND message_type  = I_event_type ;
        END IF;
        COMMIT;
    END IF;
    --
    L_mark := 'VALIDATE_STAGE_RECORDS';
    IF O_proc_status IN ( NEW_STATUS, VALIDATION_ERROR) THEN
        --validate records in staging table
        IF VALIDATE_STAGE_RECORDS(O_error_message,O_proc_status,I_event_id,I_event_type) = FALSE THEN
                --O_proc_status := VALIDATION_ERROR;
                RETURN FALSE;
        END IF;
       -- O_proc_status := VALIDATED;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':VALIDATE_STAGE_RECORDS COMPLETED');
        COMMIT;
    END IF;
    --
    --
    IF O_proc_status IN ( VALIDATED, RIS_INBOUND_ERROR) THEN
        --build xml from stage and insert to ris_message_inbound
        IF INSERT_RIS_INBOUND(O_error_message ,
                              L_inbound_ref_id,
                              I_event_id     ,
                              I_event_type,
                              O_xref_rms_ord_nbr) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_RIS_INBOUND COMPLETED');
        COMMIT;
        O_proc_status := RIS_INBOUND_SUCCESS;
    END IF;
    --

    L_mark := 'Call : RIS_CONSUMER_SERVICE.CONSUME';
    --
    IF O_proc_status IN (WEB_SERVICE_ERROR, RIS_INBOUND_SUCCESS) THEN
        --insert legacy order no and rms order no mapping to xref table
        L_mark := 'INSERT_TO_PO_XREF';
        IF INSERT_TO_PO_XREF(O_error_message,I_entity_id,O_xref_rms_ord_nbr) = FALSE THEN
            O_proc_status := ERROR_STATUS;
            RETURN FALSE;
        END IF;
        COMMIT;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_TO_PO_XREF COMPLETED');
        --
        --call webservice to create PO in rms
        IF NOT RIS_CONSUMER_SERVICE.CONSUME (O_error_message,
                                             L_inbound_ref_id)
        THEN
                    --
            L_mark := 'CALL POPULATE_RECORDS_FROM_RMS:CREATE';
            --populate records from rms table to gtt tables
            IF POPULATE_RECORDS_FROM_RMS(O_error_message,O_xref_rms_ord_nbr,I_event_id,I_entity_id) = FALSE THEN
                O_proc_status := WEB_SERVICE_ERROR;
                RETURN FALSE;
            END IF;
            --
             OPEN CHECK_ORDER_EXISTS_IN_RMS;
            FETCH CHECK_ORDER_EXISTS_IN_RMS INTO L_check;
            CLOSE CHECK_ORDER_EXISTS_IN_RMS;
            IF L_check = 'Y' THEN

                O_proc_status   := WEB_SERVICE_SUCCESS;
                O_error_message := NULL;
            ELSE
                --delete xref entry if order creation is not successfull
                DELETE poorx_po_xref_t
                 WHERE rms_ord_nbr = O_xref_rms_ord_nbr;
                O_proc_status := WEB_SERVICE_ERROR;
            END IF;

        ELSE
            O_proc_status := WEB_SERVICE_SUCCESS;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':RIS_CONSUMER_SERVICE.CONSUME COMPLETED');

        COMMIT;
        IF O_proc_status = WEB_SERVICE_ERROR THEN
            RETURN FALSE;
        END IF;
        --
    END IF;
    --
    --this function checks if the unit cost of order and unit cost of item-supplier-orig_country_code is different.
    --If it is different it would insert it to the cost change staging table for interfacing the item-supp cost change to RMS
    --
    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END CREATE_ORDER;



/* *********************************************************************************************************
* Function          : CANCEL_ORDER
* Purpose           : Cancel Order

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION CANCEL_ORDER(O_error_message       IN OUT         VARCHAR2,
                      O_xref_rms_ord_nbr    IN OUT         NUMBER,
                      O_proc_status         IN OUT         VARCHAR2,
                      I_entity_id           IN             VARCHAR2,
                      I_event_id            IN             NUMBER,
                      I_event_type          IN             VARCHAR2,
                      I_inbound_ref_id      IN             NUMBER
                      )
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name          VARCHAR2(200)        := 'RIS_PROCESS_PO.CANCEL_ORDER';
    L_mark                  VARCHAR2(200);
    L_ris_message_id        NUMBER              := I_inbound_ref_id;
    L_rms_order_status      VARCHAR(1);
    --

    CURSOR C_CHECK_ORDER_CANCELLED IS
        SELECT status
          FROM ris_po_hdr_rms_gtt
         WHERE message_id = I_event_id;
BEGIN
    --

    IF O_proc_status IN ( NEW_STATUS ) THEN
        --update staging table with the RMS order no
        L_mark := 'UPDATE ris_po_hdr_stage';
        UPDATE ris_po_hdr_stage
           SET rms_order_no = O_xref_rms_ord_nbr
         WHERE message_id   = I_event_id
           AND message_type = I_event_type
           AND proc_status  = NEW_STATUS;
        COMMIT;
    END IF;
    --
    L_mark := 'CALL POPULATE_RECORDS_FROM_RMS';
    --check if rms order is already cancelled, in that case we dont need to process anything
    IF POPULATE_RECORDS_FROM_RMS(O_error_message,O_xref_rms_ord_nbr,I_event_id,I_entity_id) = FALSE THEN
        O_proc_status := RIS_INBOUND_ERROR;
        RETURN FALSE;
    ELSE
         OPEN C_CHECK_ORDER_CANCELLED;
        FETCH C_CHECK_ORDER_CANCELLED INTO L_rms_order_status;
        CLOSE C_CHECK_ORDER_CANCELLED;
        --
        IF L_rms_order_status = COMPLETE_STATUS THEN
            RETURN TRUE;

        END IF;
    END IF;
    --
    IF O_proc_status IN ( NEW_STATUS,DPO_DELETE_NEW_STATUS, RIS_INBOUND_ERROR) THEN
        L_mark := 'CALL INSERT_RIS_INBOUND';
        --build xml from stage and insert to ris_message_inbound
        IF INSERT_RIS_INBOUND(O_error_message ,
                              L_ris_message_id,
                              I_event_id     ,
                              I_event_type,
                              O_xref_rms_ord_nbr) = FALSE THEN
            O_proc_status := RIS_INBOUND_ERROR;
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':INSERT_RIS_INBOUND COMPLETED');
        -- Transaction commited. Any error after this will be retried from Inbound frontend.
        COMMIT;
        O_proc_status := RIS_INBOUND_SUCCESS;
        --
    END IF;
    --
    L_mark := 'Call : RIS_CONSUMER_SERVICE.CONSUME';
    --
    IF O_proc_status IN (WEB_SERVICE_ERROR, RIS_INBOUND_SUCCESS) THEN
        --call webservice to create PO in rms
        IF NOT RIS_CONSUMER_SERVICE.CONSUME (O_error_message,
                                             L_ris_message_id)
        THEN
            O_proc_status      := WEB_SERVICE_ERROR;
        ELSE
            L_rms_order_status := COMPLETE_STATUS;
            O_proc_status      := WEB_SERVICE_SUCCESS;
        END IF;
        --
        DBG_SQL.MSG(L_dbg_object,I_event_id||':RIS_CONSUMER_SERVICE.CONSUME COMPLETED');
        IF O_proc_status = WEB_SERVICE_ERROR THEN
            L_mark := 'Call : POPULATE_RECORDS_FROM_RMS:CANCEL';
            --populate records from rms table to gtt tables
            IF POPULATE_RECORDS_FROM_RMS(O_error_message,O_xref_rms_ord_nbr,I_event_id,I_entity_id,'N') = FALSE THEN
                O_proc_status := WEB_SERVICE_ERROR;
                RETURN FALSE;
            END IF;
            --
            L_mark := 'Call : C_CHECK_ORDER_CANCELLED:AFTER';
             OPEN C_CHECK_ORDER_CANCELLED;
            FETCH C_CHECK_ORDER_CANCELLED INTO L_rms_order_status;
            CLOSE C_CHECK_ORDER_CANCELLED;
        END IF;

        --set the legacy delete indicator to Y for Cancelled PO
        IF L_rms_order_status = COMPLETE_STATUS AND I_event_type IN (RIS_INBOUND_EVENT_PROCESS.DPODELETE,RIS_INBOUND_EVENT_PROCESS.DPOCANCEL) THEN
            L_mark := 'UPDATE poorx_po_xref_t:COMPLETE_STATUS';
            UPDATE poorx_po_xref_t
               SET lgcy_dlt_ind        = 'Y',
                   lst_updt_dttm       = SYSDATE,
                   lst_updt_user_id    = USER
             WHERE rms_ord_nbr         = O_xref_rms_ord_nbr;
             O_error_message    := NULL;
        ELSE
            RETURN FALSE;
        END IF;
         --
    END IF;
    --

    RETURN TRUE;
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END CANCEL_ORDER;

/* *********************************************************************************************************
* Function          : GET_REPO_DPO_JSON
* Purpose           : gets the latest DPO JSON and Order status from Repository

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 05-MAY-2018  0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION GET_REPO_DPO_JSON(O_error_message IN OUT VARCHAR2,
                           O_json          IN OUT NOCOPY CLOB,
                           O_order_status  OUT    VARCHAR2,
                           I_url           IN     VARCHAR2,
                           I_message_id    IN     NUMBER)
RETURN BOOLEAN IS

   L_program_name VARCHAR2(200)                            :=   'RIS_PROCESS_PO.GET_REPO_DPO_JSON';
   L_mark         VARCHAR2(200)                            :=   'DECLARE';
   L_json_resp    CLOB;
   L_item_obj     JSON_OBJECT_T;
   L_order_obj    JSON_OBJECT_T;
   L_entity_id    VARCHAR2(10);

BEGIN
    --
    O_json          := NULL;
    O_order_status  := NULL;
    L_mark := 'Invoke the event resource URL';

    IF RIS_APEX_SERVICE.GET_REST_RESPONSE(O_error_message,
                                          L_json_resp,
                                          NULL,
                                          RIS_APEX_SERVICE.APEX_GET_SERVICE,
                                          1,  -- instance ID
                                          RIS_INBOUND_EVENT_PROCESS.DPOEVENT,
                                          RIS_INBOUND_EVENT_PROCESS.L_ORD_FAMILY,
                                          I_url) = FALSE
    THEN
       O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                             O_error_message,
                                             L_program_name,
                                             NULL);

       RETURN FALSE;
    END IF;
    --
    --check if response retrieved is in json format
    L_mark:= 'Call RIS_APEX_SERVICE to CHECK_JSON_IN_RESPONSE';

    IF RIS_APEX_SERVICE.CHECK_JSON_IN_RESPONSE(O_error_message,
                                               L_json_resp) = FALSE
    THEN
       O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                             'JSON RESPONSE UNSUCCESSFUL FOR EVENT ID:'||I_message_id||' URL:'||I_url||' ERROR:'||O_error_message,
                                             L_program_name,
                                             NULL);

       RETURN FALSE;
    END IF;

    L_mark := 'Parse event JSON response message';
    L_order_obj := JSON_OBJECT_T(L_json_resp);

    L_entity_id := L_order_obj.get_string('orderNumber');

    IF L_entity_id IS NULL THEN
       O_error_message := SQL_LIB.CREATE_MSG('WEBSERVICE_ERROR',
                                             'orderNumber  IS NULL FOR EVENT ID:'||I_message_id||' URL:'||I_url||' ERROR:'||O_error_message,
                                             L_program_name,
                                             NULL);

       RETURN FALSE;
    END IF;

    O_json          := L_json_resp;
    O_order_status  := L_order_obj.get_string('status');

    RETURN TRUE;

EXCEPTION
WHEN OTHERS
THEN
   O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                         SQLERRM||'@ '||L_mark,
                                         L_program_name,
                                         TO_CHAR(SQLCODE));
   RETURN FALSE;
END GET_REPO_DPO_JSON;

/* *********************************************************************************************************
* Function          : UPDATE_CURRENT_DPO_STATUS
* Purpose           : gets the latest DPO status from Repository and updates the staging table

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 05-MAY-2018   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION UPDATE_CURRENT_DPO_STATUS(O_error_message       IN OUT         VARCHAR2)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.UPDATE_CURRENT_DPO_STATUS';
    L_mark                 VARCHAR2(200);
    LP_HEADER_REC          C_GET_ENTITY_HEADER%ROWTYPE;
    L_return               BOOLEAN;
    L_rms_ord_nbr          NUMBER;
    L_xref_rms_ord_nbr     NUMBER;
    L_proc_status          VARCHAR2(2);
    L_lgcy_dlt_ind         VARCHAR2(1);
    L_error_status         VARCHAR2(2)          := 'N';
    --
    CURSOR C_GET_DPO_DELETE
        IS
            SELECT *
              FROM (SELECT reh.*,
                           reh.event_type order_status,
                           stg.proc_status,
                           ROW_NUMBER() OVER ( PARTITION BY entity_id ORDER BY reh.event_id desc ) rnk2
                      FROM ris_event_header reh,
                           ris_po_hdr_stage stg
                     WHERE reh.event_message_type  =    RIS_INBOUND_EVENT_PROCESS.DPODELETE
                       AND reh.event_id            =    stg.message_id
                       AND reh.event_message_type  =    stg.message_type
                       AND proc_status             IN   (NEW_STATUS,DPO_DELETE_ERROR_STATUS)
                       AND reh.status              =    STATUS4
                   );
    --
    TYPE l_rec_type IS TABLE OF C_GET_DPO_DELETE%ROWTYPE;
    l_rec  l_rec_type;
BEGIN
     DBG_SQL.MSG(L_dbg_object,L_program_name||':START');
    --get the required details from po hdr stage
    L_mark := 'C_GET_DPO_DELETE';
     OPEN C_GET_DPO_DELETE;
    FETCH C_GET_DPO_DELETE BULK COLLECT INTO l_rec;
    CLOSE C_GET_DPO_DELETE;
    --
    FOR i IN 1..l_rec.COUNT
    LOOP
        l_rec(i).error_msg_txt := NULL;
        IF l_rec(i).rnk2 = 1 THEN
            L_mark := 'GET_REPO_DPO_JSON';
            IF GET_REPO_DPO_JSON(l_rec(i).error_msg_txt,
                                 l_rec(i).json_data,
                                 l_rec(i).order_status,
                                 l_rec(i).url          ,
                                 l_rec(i).event_id) = FALSE THEN
                L_error_status          := 'Y';
            END IF;

            --
            IF l_rec(i).error_msg_txt IS NULL THEN

                IF l_rec(i).order_status = DPO_DELETED THEN

                    l_rec(i).proc_status := DPO_DELETE_NEW_STATUS;

                ELSE

                    l_rec(i).proc_status := COMPLETE_STATUS;

                END IF;
            ELSE

                l_rec(i).proc_status     := DPO_DELETE_ERROR_STATUS;

            END IF;
        ELSE

            l_rec(i).proc_status := COMPLETE_STATUS;

        END IF;
    END LOOP;
    --
    FORALL  i IN 1..l_rec.COUNT
    UPDATE ris_event_header
       SET json_data        =   l_rec(i).json_data
     WHERE event_id         =   l_rec(i).event_id;
    --
    L_mark := 'UPDATE ris_po_hdr_stage';
    FORALL  i IN 1..l_rec.COUNT
    UPDATE ris_po_hdr_stage
       SET proc_status      =   l_rec(i).proc_status,
           error_message    =   l_rec(i).error_msg_txt
     WHERE message_id       =   l_rec(i).event_id
       AND message_type     =   l_rec(i).event_message_type;

    --
    DBG_SQL.MSG(L_dbg_object,L_program_name||':END');
    COMMIT;
    IF L_error_status = 'Y' THEN
        RETURN FALSE;
    ELSE
        RETURN TRUE;
    END IF;
    --
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END UPDATE_CURRENT_DPO_STATUS;




/* *********************************************************************************************************
* Function          : PROCESS_DPO_DELETE
* Purpose           : DPO DELETE

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 06-MAY-2018   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION PROCESS_DPO_DELETE(O_error_message       IN OUT         VARCHAR2)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.PROCESS_DPO_DELETE';
    L_mark                 VARCHAR2(200);
    LP_HEADER_REC          C_GET_ENTITY_HEADER%ROWTYPE;
    L_return               BOOLEAN;
    L_rms_ord_nbr          NUMBER;
    L_xref_rms_ord_nbr     NUMBER;
    L_proc_status          VARCHAR2(2);
    L_lgcy_dlt_ind         VARCHAR2(1);
    L_error_status         VARCHAR2(2)          := 'N';
    --
    CURSOR C_GET_DPO_DELETE
        IS
            SELECT stg.*
              FROM ris_po_hdr_stage stg
             WHERE message_type =   RIS_INBOUND_EVENT_PROCESS.DPODELETE
               AND proc_status  IN  (DPO_DELETE_NEW_STATUS,RIS_INBOUND_ERROR,WEB_SERVICE_ERROR);
    --
    TYPE l_rec_type IS TABLE OF C_GET_DPO_DELETE%ROWTYPE;
    l_rec  l_rec_type;
BEGIN
     DBG_SQL.MSG(L_dbg_object,L_program_name||':START');
    --get defaults
     OPEN C_GET_DEFAULTS;
    FETCH C_GET_DEFAULTS INTO L_default_rec;
    CLOSE C_GET_DEFAULTS;
    IF L_default_rec.rnum IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG ('PACKAGE_ERROR',
                                               'C_GET_DEFAULTS Didnt fetch any records',
                                               L_program_name,
                                               TO_CHAR (SQLCODE));
        RETURN FALSE;
    END IF;
    --get the required details from po hdr stage
    L_mark := 'C_GET_DPO_DELETE';
     OPEN C_GET_DPO_DELETE;
    FETCH C_GET_DPO_DELETE BULK COLLECT INTO l_rec;
    CLOSE C_GET_DPO_DELETE;
    --
    FOR i IN 1..l_rec.COUNT
    LOOP
    l_rec(i).error_message := NULL;
        --update the rms pack no to PO stage
        FOR rec IN (SELECT item, legacy_ppk_nbr
                      FROM ris_item_stage
                     WHERE event_id = l_rec(i).message_id
                       AND pack_ind     = 'Y')
        LOOP
            UPDATE ris_po_dtl_stage
               SET item         = rec.item
             WHERE message_id   = l_rec(i).message_id
               AND item         = rec.legacy_ppk_nbr;
        END LOOP;
        --
        IF CANCEL_ORDER(O_error_message,
                        l_rec(i).rms_order_no,
                        l_rec(i).proc_status,
                        l_rec(i).legacy_order_no,
                        l_rec(i).message_id,
                        l_rec(i).message_type,
                        l_rec(i).inbound_ref_id) = FALSE THEN
            l_rec(i).error_message  := O_error_message;
            L_error_status          := 'Y';
        ELSE
            l_rec(i).proc_status    := COMPLETE_STATUS;
        END IF;
    END LOOP;
    --
    L_mark := 'UPDATE ris_po_hdr_stage';
    FORALL  i IN 1..l_rec.COUNT
    UPDATE ris_po_hdr_stage
       SET proc_status      =   l_rec(i).proc_status,
           error_message    =   l_rec(i).error_message
     WHERE message_id       =   l_rec(i).message_id
       AND message_type     =   l_rec(i).message_type;
    COMMIT;
    --
    DBG_SQL.MSG(L_dbg_object,L_program_name||':END');
    IF L_error_status = 'Y' THEN
        RETURN FALSE;
    ELSE
        RETURN TRUE;
    END IF;
    --
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END PROCESS_DPO_DELETE;

/* *********************************************************************************************************
* Function          : PROCESS_ORDER
* Purpose           :

*
* Date          Ver    Author                 Description
* ====          ===    ======                 ===========
* 17-FEB-2017   0.0    Infosys,Pradeep G      Initial Version
***********************************************************************************************************/
FUNCTION PROCESS_ORDER(O_error_message       IN OUT         VARCHAR2,
                       I_event_status        IN OUT         NUMBER,
                       I_event_id            IN             NUMBER)
    RETURN BOOLEAN
    IS
    -- Variable Declarations
    L_program_name         VARCHAR2(200)        := 'RIS_PROCESS_PO.PROCESS_ORDER';
    L_mark                 VARCHAR2(200);
    LP_HEADER_REC          C_GET_ENTITY_HEADER%ROWTYPE;
    L_return               BOOLEAN;
    L_rms_ord_nbr          NUMBER;
    L_xref_rms_ord_nbr     NUMBER;
    L_proc_status          VARCHAR2(2);
    L_lgcy_dlt_ind         VARCHAR2(1);
    L_converted_order      VARCHAR2(2);
    --

BEGIN
    O_error_message := NULL;
     DBG_SQL.MSG(L_dbg_object,I_event_id||':START');
    --get the required details from po hdr stage
     OPEN C_GET_ENTITY_HEADER(I_event_id);
    FETCH C_GET_ENTITY_HEADER INTO LP_HEADER_REC;
    CLOSE C_GET_ENTITY_HEADER;
    IF LP_HEADER_REC.message_id IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                              'Entity Record does not exist for Event Id:'||I_event_id,
                                              L_program_name,
                                              TO_CHAR(SQLCODE));
        RETURN FALSE;
    END IF;
    --get the rms order no from the xref table
    --this would be NULL for new orders
        L_mark := 'CALL C_GET_PO_XREF';
         OPEN C_GET_PO_XREF(LP_HEADER_REC.legacy_order_no);
        FETCH C_GET_PO_XREF INTO L_xref_rms_ord_nbr;
              IF C_GET_PO_XREF%NOTFOUND
              THEN
                L_mark := 'CALL C_GET_PO_XREF_CONV';
                 OPEN C_GET_PO_XREF_CONV(LP_HEADER_REC.legacy_order_no);
                FETCH C_GET_PO_XREF_CONV INTO L_xref_rms_ord_nbr;
                IF C_GET_PO_XREF_CONV%NOTFOUND THEN
                    L_converted_order := 'N';
                ELSE
                    L_converted_order := 'Y'; --it is converted order which has null delivery id.
                END IF;
                CLOSE C_GET_PO_XREF_CONV;

              ELSE
                 L_converted_order := 'N';
              END IF;
        CLOSE C_GET_PO_XREF;
    --
    IF LP_HEADER_REC.message_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE AND L_xref_rms_ord_nbr IS NOT NULL
    THEN
       LP_HEADER_REC.message_type := RIS_INBOUND_EVENT_PROCESS.DPOUPDATE;
       --
       L_mark := 'Update ris_even_header';
       --
       UPDATE ris_event_header
          SET event_message_type =  LP_HEADER_REC.message_type
        WHERE event_id = I_event_id
          AND event_message_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE;
       --
       L_mark := 'Update ris_po_hdr_stage';
       --
       UPDATE ris_po_hdr_stage
          SET message_type =  LP_HEADER_REC.message_type
        WHERE event_id = I_event_id
          AND message_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE;
       --
       L_mark := 'Update ris_po_dtl_stage';
       --
       UPDATE ris_po_dtl_stage
          SET message_type =  LP_HEADER_REC.message_type
        WHERE event_id = I_event_id
          AND message_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE;
       --
       COMMIT;
    END IF;

    --get defaults
     OPEN C_GET_DEFAULTS;
    FETCH C_GET_DEFAULTS INTO L_default_rec;
    CLOSE C_GET_DEFAULTS;
    IF L_default_rec.rnum IS NULL THEN
        O_error_message := SQL_LIB.CREATE_MSG ('PACKAGE_ERROR',
                                               'C_GET_DEFAULTS Didnt fetch any records',
                                               L_program_name,
                                               TO_CHAR (SQLCODE));
        RETURN FALSE;
    END IF;

    --update the rms pack no to PO stage
    FOR rec IN (SELECT item, legacy_ppk_nbr
                FROM ris_item_stage
               WHERE event_id = I_event_id
                 AND pack_ind     = 'Y')
    LOOP
        UPDATE ris_po_dtl_stage
           SET item         = rec.item
         WHERE message_id   = I_event_id
           AND item         = rec.legacy_ppk_nbr;
    END LOOP;



    IF (LP_HEADER_REC.message_type = RIS_INBOUND_EVENT_PROCESS.DPOCREATE) THEN
        L_mark:=  'CALL CREATE_ORDER';
        L_return:= CREATE_ORDER(O_error_message,
                                LP_HEADER_REC.rms_order_no,
                                LP_HEADER_REC.proc_status,
                                LP_HEADER_REC.legacy_order_no,
                                LP_HEADER_REC.message_id,
                                LP_HEADER_REC.message_type,
                                LP_HEADER_REC.inbound_ref_id);
        DBG_SQL.MSG(L_dbg_object,I_event_id||':CREATE_ORDER COMPLETED');

    ELSIF (LP_HEADER_REC.message_type = RIS_INBOUND_EVENT_PROCESS.DPOUPDATE ) THEN
        L_mark:=  'CALL MODIFY_ORDER';
        L_return:= MODIFY_ORDER(O_error_message,
                                L_xref_rms_ord_nbr,
                                LP_HEADER_REC.proc_status,
                                LP_HEADER_REC.legacy_order_no,
                                LP_HEADER_REC.message_id,
                                LP_HEADER_REC.message_type,
                                L_converted_order);
        DBG_SQL.MSG(L_dbg_object,I_event_id||':MODIFY_ORDER COMPLETED');
    ELSIF LP_HEADER_REC.message_type IN ( RIS_INBOUND_EVENT_PROCESS.DPOCANCEL,RIS_INBOUND_EVENT_PROCESS.DPOCOMPLETE) THEN
        L_mark:=  'CALL CANCEL_ORDER';
        L_return:= CANCEL_ORDER(O_error_message,
                                L_xref_rms_ord_nbr,
                                LP_HEADER_REC.proc_status,
                                LP_HEADER_REC.legacy_order_no,
                                LP_HEADER_REC.message_id,
                                LP_HEADER_REC.message_type,
                                LP_HEADER_REC.inbound_ref_id) ;
                   DBG_SQL.MSG(L_dbg_object,I_event_id||':CANCEL_ORDER COMPLETED');
    ELSIF LP_HEADER_REC.message_type = RIS_INBOUND_EVENT_PROCESS.DPODELETE THEN
        DBG_SQL.MSG(L_dbg_object,I_event_id||':DPO_DELETE COMPLETED');
        COMMIT;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':SUCCESS');
        I_event_status := EVENT_STATUS_4_0;
        RETURN TRUE;
    END IF;

    --

    IF L_return = FALSE THEN
        --revert
        ROLLBACK;
        O_error_message := O_error_message||'@'||L_mark;
        IF RIS_STAGE_STATUS_UPD(O_error_message, I_event_id,LP_HEADER_REC.proc_status,LP_HEADER_REC.message_type) = FALSE
        THEN
            RETURN FALSE;
        END IF;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':FAILED: '||O_error_message);
        COMMIT;
        RETURN FALSE;
    ELSE
        IF RIS_STAGE_STATUS_UPD(O_error_message, I_event_id,RIS_LIBRARY.STATUS_COMPLETE,LP_HEADER_REC.message_type) = FALSE
        THEN
            RETURN FALSE;
        END IF;
        COMMIT;
        DBG_SQL.MSG(L_dbg_object,I_event_id||':SUCCESS');
        I_event_status := EVENT_STATUS_4_0;
        RETURN TRUE;
    END IF;
    --
EXCEPTION
   WHEN OTHERS
   THEN
      -- Not using SQLLIB to trap whole RSE error message.
      O_error_message := SQL_LIB.CREATE_MSG('PACKAGE_ERROR',
                                            SQLERRM || '@' || L_mark,
                                            L_program_name,
                                            TO_CHAR(SQLCODE));
      RETURN FALSE;
END PROCESS_ORDER;


END RIS_PROCESS_PO;
/
