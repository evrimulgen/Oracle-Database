select * from gap_ris_batch_flow_stage_t;
select * from gap_ris_batch_job_stage_t where batch_run_id = 5917;
select * from ris_consumer_config;
select * from ris_sec_config where config_id =;
select distinct message_type from ris_consumer_config;
select * from ris_po_hdr_stage;
select * from ris_po_dtl_stage;
select * from ris_message_inbound;
select * from intf_cnfg_parm_t;



SELECT rcc.service_name               AS jos_process,
                rcc.config_id                  AS config_id
           FROM ris_consumer_config rcc
          WHERE message_type     = 'XOrderCre'
            AND message_family   = 'NIGHTLY_PROCESS';
           
--Web service URL

 SELECT     rsc.url, ---WS URL
            rsc.action,
            rsc.wls_uri,
            rsc.private_key_alias username,
            sys.utl_raw.cast_to_varchar2(rsc.private_key_alias_passwd) password,
            keystore_name                                                                   AS client_id,
            sys.utl_raw.cast_to_varchar2(keystore_passwd)                                   AS client_secret,
            keystore_path                                                                   AS auth_url,
            wallet_path                                                                     AS wallet_path,
            sys.utl_raw.cast_to_varchar2(wallet_password)                                   AS wallet_pwd,
            server                                                                          AS https_host,
            port_name                                                                       AS port_name,
            sys.utl_raw.cast_to_varchar2(sys_account)                                       AS x_api_key
       FROM ris_sec_config rsc
      WHERE config_id         = 2007;
      

 CURSOR C_get_jos_process
      IS
         SELECT service_name
           FROM ris_consumer_config
          WHERE message_type   = 'BATCH'
            AND message_family ='NIGHTLY_PROCESS';
            
 CURSOR C_get_batch_config
      IS
       SELECT TO_NUMBER(cd_val_txt),
              TO_NUMBER(attribute1)
         FROM intf_cnfg_parm_t intf
        WHERE intf.pgm_nm      = 'GAP_BATCH_API'
          AND intf.cd_nm       = 'NIGHTLY_PROCESS'
          AND intf.cnfg_typ_cd = 'END_BATCH_JOB';
